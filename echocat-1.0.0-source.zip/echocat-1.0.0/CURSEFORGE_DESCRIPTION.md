# CurseForge Project Description (Ready to Copy-Paste)

**Short Summary Line (Under 250 Characters — Paste into CurseForge "Summary" Field):**  
Summon Echo, an adorable talking pet cat that repeats what you say in chat and voice—until 5 survival missions slowly twist your loyal companion across 6 atmospheric horror phases. Includes offline AI, custom 3D animations, and full comfort controls!

---

# 🐱 Echo: The Talking Cat
### *Your Adorable Talking Companion... That Slowly Becomes Wrong.*

> ⚠️ **Content & Comfort Notice**: This mod features atmospheric psychological & digital horror, glitch visuals, eerie audio, and optional jumpscares. It includes a built-in **Photosensitive Mode**, a **Horror Intensity slider (1–3)**, a **Jumpscare toggle**, and an instant **`/echo calm` Panic Button** (`K` key) so every player can tailor the experience to their comfort level!

**Echo: The Talking Cat** is a 100% original companion and progressive horror mod for **Minecraft 1.20.1 (Forge)** powered by **GeckoLib 4**.

Craft or summon **Echo**, a warm ginger tabby who follows you, sits on command, and **repeats what you say** with animated jaw/ear movements and a floating 3D speech bubble above its head. At first, Echo is the cutest pet you could ask for. But as you uncover strange components underground and complete **5 progressive missions**, Echo starts saying things you never said...

---

## ✨ Key Features

* **💬 Chat & Optional Push-to-Talk Voice Repetition**: Speak in text chat (or hold **`V`** with your microphone if you enable opt-in Speech-to-Text) within 16 blocks of Echo, and watch Echo repeat your words after a natural pause!
* **🧠 Works 100% Offline Out of the Box (Plus Optional AI Support)**: Includes **50 hand-crafted, context-aware unsettling lines** that react to nighttime, deep caves, low health, and the Nether/End with zero setup required—plus optional support for any OpenAI-compatible API key!
* **📖 5 Survival Missions & Echo's Journal**: Receive **Echo's Journal** on your first summon to track your current mission, survival hints, and progression checklist. Mine glowing **Static Blocks** and deep **Red Crystal Ore**, loot dungeon chests, and assemble **The Remote**.
* **🎭 6 Progressive Phases of Atmospheric Horror**:
  1. **Phase 1 — CUTE**: Warm, loyal, invulnerable to its owner, and repeats everything you say verbatim.
  2. **Phase 2 — WEIRD**: Echo's coat desaturates, its eyes dilate, and it occasionally follows up your chat messages with eerie sentences you never typed.
  3. **Phase 3 — GLITCH**: Echo's voice stutters (`he-he-hello`), its bones twitch, its texture flickers, and RGB-split ghost duplicates appear alongside subtle proximity scanlines.
  4. **Phase 4 — CHAOS**: Echo's dark resonance temporarily corrupts nearby mobs within 24 blocks, causing passive and hostile mobs alike to turn on each other with glowing red eyes (before cleanly returning to normal when you leave!).
  5. **Phase 5 — RED (The Watcher)**: Echo stops following you closely. It watches you from 12–20 blocks away, dissolves into smoke whenever you look directly at it, and slowly stretches into a **2.4-block horror silhouette**.
  6. **Phase 6 — HORROR FINAL**: *[No Spoilers!]* Keep **The Remote** in your hotbar and watch closely for Echo's telegraph! Defeating the final encounter rewards you with **Echo's Heart** and the **Purified Echo Plush Summoner** (which spawns a permanently cute, horror-free Echo!).
* **🛡️ Built for Stability & Shader Compatibility**: Uses pure 2D overlay quads rather than invasive post-processing shaders, ensuring smooth compatibility with **Embeddium, Sodium, Iris, and OptiFine**, plus a dedicated `performanceMode` for low-end PCs.

---

## 📦 Requirements & Installation

1. **Minecraft Java Edition `1.20.1`** with **Minecraft Forge `47.3.0`** (or newer).
2. **Required Dependency**: **[GeckoLib 4 (Forge 1.20.1)](https://www.curseforge.com/minecraft/mc-mods/geckolib)** (`4.4.9` or newer).
3. Drop both `geckolib-forge-1.20.1-4.4.9.jar` and `echocat-1.0.0.jar` into your `.minecraft/mods/` folder and launch the game!

---

## 🔧 Optional AI & Voice Setup Guide (100% Optional)

By default, `apiProvider = "none"` is set so the mod runs **completely offline** using its 50 built-in context-aware lines.
If you want dynamic AI-generated lines or Push-to-Talk voice transcription:
1. Obtain an API key from OpenAI (or any OpenAI-compatible endpoint, including a free local Ollama server).
2. Open `.minecraft/saves/<YourWorld>/serverconfig/echocat-common.toml` (or `.minecraft/config/echocat-client.toml` for client STT):
   * Set `apiProvider = "openai"` and paste your key into `apiKey = "sk-..."`.
3. **Important Privacy & Cost Note**: Your API key is stored only in your local config file (never logged, never shared with other players). Do **not** share your config file publicly! Any API usage fees are billed by your chosen third-party provider to your own account. Microphone capture is strictly opt-in (requires accepting the in-game consent screen on first pressing `V`), only records in memory while holding `V` (max 10s), and never saves audio to disk.

---

## ⌨️ Commands & Panic Button

* **`/echo calm`** *(or press **`K`** — usable by ANY player without cheats!)*: **Instant Panic Button**. Immediately calms your Echo back to Phase 1 (`Cute`), clears all corrupted mobs, and stops all horror effects.
* **Operator / Testing Commands (Permission Level 2)**:
  * `/echo summon` — Gives 1x **Echo Plush Summoner**.
  * `/echo phase get` | `/echo phase set <1-6>` | `/echo phase next` — Inspect or jump to any horror phase.
  * `/echo mission list` | `/echo mission complete <1-5>` — View or complete missions.
  * `/echo give <item|all>` — Spawn mission items or `the_remote`.
  * `/echo debug corrupted` — Check how many nearby mobs are currently corrupted.
  * `/echo reset` — Full reset back to Phase 1 (`Cute`).

---

## ❓ Frequently Asked Questions (FAQ)

* **Q: Will Phase 4 (CHAOS) permanently ruin my villagers, pets, or named mobs?**  
  **A:** Never! Villagers, wandering traders, iron golems, tamed pets, named mobs, and bosses are strictly exempt. Furthermore, corruption on regular mobs is 100% temporary and automatically restores their exact original AI when they leave the 24-block radius, after 90 seconds, or when you reload the world.
* **Q: Does Echo break blocks during the final phase?**  
  **A:** No! Echo never destroys or griefs blocks in your world.
* **Q: Can I play this with friends on a Dedicated Server?**  
  **A:** Yes! Every player has their own bonded Echo and independent phase/mission progression.

---

## 📜 Credits & Legal Disclaimer
* **Author**: `[YOUR_AUTHOR_NAME_HERE]`
* **Animation Library**: Powered by **GeckoLib 4** (MIT License).
* **License**: All Rights Reserved.
* *Not an official Minecraft product. Not approved by or associated with Mojang or Microsoft.*
