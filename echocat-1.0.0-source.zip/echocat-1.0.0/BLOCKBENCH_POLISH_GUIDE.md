# Beginner's Guide to Polishing Echo in Blockbench (`BLOCKBENCH_POLISH_GUIDE.md`)

You do not need any programming knowledge to visually edit Echo's 3D models, textures, or animations! Everything is stored in standard **Blockbench / GeckoLib 4 JSON and PNG files**.

## Step 1: Install Blockbench & the GeckoLib Plugin
1. Go to **[https://www.blockbench.net/](https://www.blockbench.net/)** and download the free **Blockbench Desktop App** for Windows, macOS, or Linux.
2. Open Blockbench and click **File -> Plugins...** in the top menu bar.
3. Click the **Available** tab, type **`GeckoLib`** in the search bar, find **GeckoLib Animation Utils**, and click **Install**.

## Step 2: Open Echo's Cute or Horror Model
1. In Blockbench, click **File -> Open Model...**.
2. Choose either:
   - **Cute Model (Phases 1–5)**: `src/main/resources/assets/echocat/geo/entity/echo.geo.json`
   - **Horror Boss Model (Phases 5–6)**: `src/main/resources/assets/echocat/geo/entity/echo_horror.geo.json`
3. In the bottom-left **Textures** panel, right-click or click the **Import Texture** icon and load the matching PNG from:
   `src/main/resources/assets/echocat/textures/entity/`
   - For `echo.geo.json`: load `echo_cute.png` (or `echo_weird.png`, `echo_glitch.png`, `echo_chaos.png`, `echo_red.png`).
   - For `echo_horror.geo.json`: load `echo_horror.png` (and optionally `echo_horror_glowing.png` to inspect the glowing eye/shard layer).

## Step 3: How to Edit Cubes & Paint Textures
- **Edit Mode (Top-Right Tab: `Edit`)**:
  - Click any cube in the 3D viewport to move, resize, or rotate it.
  - **CRITICAL RULE**: Do **not** rename the bone folders in the right-hand **Outliner** panel (keep names like `head`, `jaw`, `ear_left`, `ear_right`, `jaw_lower`, `glitch_shard_1`, etc. exact so the Java code still finds them!). You can freely add new decorative cubes inside any existing bone folder.
- **Paint Mode (Top-Right Tab: `Paint`)**:
  - Select the **Paintbrush** tool and paint directly onto the 3D cat model in real time!
  - Click the **Save** (floppy disk) icon next to the texture in the left panel to overwrite the `.png` file.

## Step 4: How to Preview & Edit Animations
1. Click the **Animate** tab in the top-right corner of Blockbench.
2. In the left **Animations** panel, click **Import Animations...** and select:
   - `src/main/resources/assets/echocat/animations/entity/echo.animation.json` *(for the Cute model)*
   - `src/main/resources/assets/echocat/animations/entity/echo_horror.animation.json` *(for the Horror model)*
3. Click any animation (e.g., `animation.echo.idle` or `animation.echo_horror.overload_telegraph`) and press the **Play (`▶`)** button above the timeline to watch it loop.

## Step 5: How to Export Back to the Mod
- **Save Geometry**: Press `Ctrl + S` (or **File -> Save Model**) to overwrite the `.geo.json` file in place.
- **Save Animations**: Click the floppy disk icon next to the animation file name in the left **Animations** panel.
- Re-run `.\gradlew.bat build` to package your updated visuals into the `.jar`!

## Top 10 High-Impact Hand-Polish Ideas (Prioritized Checklist)
1. **[ ] Add Cheek Fluff Tufts (`echo.geo.json`)**: Add two angled flat planes or small cubes on the left and right sides of the `head` bone for a softer feline silhouette.
2. **[ ] Hand-Shade the Eyes (`echo_cute.png`)**: In the `Paint` tab, add a 2-tone emerald gradient and a tiny dark pupil slit to Echo's cute eyes.
3. **[ ] Add Paw Pads (`echo_cute.png`)**: Paint pink toe-bean pixels on the bottom faces of `leg_front_left`, `leg_front_right`, `leg_back_left`, and `leg_back_right`.
4. **[ ] Angle Individual Horror Fingers (`echo_horror.geo.json`)**: Slightly rotate each of the 4 finger tip cubes on `hand_left` and `hand_right` so they curl menacingly like claws.
5. **[ ] Asymmetric Spine Spikes (`echo_horror.geo.json`)**: Tilt the 6 cubes inside `spine_ridge` at slightly crooked angles (`-5°` to `+8°` on Z) for a more twisted silhouette.
6. **[ ] Glowing Mouth Interior (`echo_horror_glowing.png`)**: Paint a brighter crimson/cyan core inside the roof of `jaw_upper` and floor of `jaw_lower` so the mouth glows brightly during `overload_telegraph`.
7. **[ ] Ear Twitch Keyframes (`echo.animation.json`)**: Add a quick double-flick keyframe to `ear_left` in `animation.echo.idle`.
8. **[ ] Pounce Anticipation Squash (`echo_horror.animation.json`)**: Lower `hips` by an extra `1.5` units at `t = 0.15s` in `animation.echo_horror.attack_pounce` for a heavier leap wind-up.
9. **[ ] Crack Highlights on `echo_horror.png`**: Paint thin dark-crimson crack lines radiating from the eye sockets down the cheeks.
10. **[ ] Custom 32x32 Item Icon for `the_remote.png`**: Upgrade `the_remote.png` with a glowing animated LED strip if desired.
