# Assets to Replace (`ASSETS_TO_REPLACE.md`)

All assets in Phases 1–4 (`v0.4.0`) are **100% original, procedurally generated, copyright-safe assets** created specifically for **Echo: The Talking Cat**.

| Asset Type | File Path | Current Status & Details | Replacement Notes |
| :--- | :--- | :--- | :--- |
| **Cute 3D Geometry** | `src/main/resources/assets/echocat/geo/entity/echo.geo.json` | 13-bone stylized cat (`64x64` UV). | Editable in Blockbench. |
| **Horror 3D Geometry** | `src/main/resources/assets/echocat/geo/entity/echo_horror.geo.json` | 32-bone, 44-cube 2.4-block hunched horror model (`128x128` UV) with spine ridge, wide jaw with flat teeth, hollow eyes + glowing cores, 2-segment fingers, 6-part split tail, and 4 floating glitch shards. | See `MODEL_SPEC.md` for full bone/UV table. |
| **Horror Animations** | `src/main/resources/assets/echocat/animations/entity/echo_horror.animation.json` | 12 animations (`horror_idle`, `horror_walk`, `horror_run`, `attack_swipe`, `attack_bite`, `attack_pounce`, `teleport_out`, `teleport_in`, `overload_telegraph`, `stunned`, `death`, `jumpscare_pose`). | Editable in Blockbench Animate tab. |
| **Entity Textures** | `src/main/resources/assets/echocat/textures/entity/*.png` | `echo_cute.png`, `echo_weird.png`, `echo_glitch.png`, `echo_chaos.png`, `echo_red.png`, `echo_horror.png` (128x128), `echo_horror_glowing.png` (128x128 glow layer), `echo_red_overlay.png` (128x128 translucent crimson layer). | Optional hand-pixel polish. |
| **Item Textures (10)** | `src/main/resources/assets/echocat/textures/item/*.png` | 16x16 icons for `echo_plush_summoner`, `purified_echo_plush`, `echo_journal`, `echo_circuit`, `glitch_shard`, `corrupted_core`, `red_crystal`, `remote_casing`, `the_remote`, `echo_heart`. | Replace with custom 16x16 PNGs if desired. |
| **Block Textures (2)** | `src/main/resources/assets/echocat/textures/block/*.png` | 16x16 ore textures for `static_block.png` and `red_crystal_ore.png`. | Replace with custom 16x16 PNGs if desired. |
| **Procedural OGG Audio (10)** | `src/main/resources/assets/echocat/sounds/*.ogg` | `echo_glitch_voice.ogg`, `echo_static_burst.ogg`, `echo_stutter.ogg`, `echo_chaos_hum.ogg`, `echo_red_breath.ogg`, `echo_overload_charge.ogg`, `echo_stunned.ogg`, `echo_jumpscare.ogg`, `echo_boss_loop.ogg`, `echo_boss_defeat.ogg`. | Generated via Python + `ffmpeg`; replace with custom studio `.ogg` files if desired. |
