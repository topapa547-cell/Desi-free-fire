# Freelance 3D Modeler & Animator Brief (`MODELER_BRIEF.md`)

Copy and paste the brief below when commissioning a freelance Blockbench / GeckoLib artist (e.g., on Fiverr, Blockbench Discord, or McModels) if you want custom studio-grade hand-crafted models and animations before a commercial/viral launch.

## Project Brief: "Echo: The Talking Cat" (Minecraft 1.20.1 GeckoLib 4 Mod)

### 1. Overview & Style Direction
We have a working, fully coded Minecraft 1.20.1 Forge mod (**Echo: The Talking Cat**) using **GeckoLib 4**. We have procedural Blockbench models and animations already working in-game, and we are hiring an experienced Blockbench/GeckoLib artist to upgrade our two entity models and texture maps to showcase quality while **preserving our exact bone names** so it drops straight into our existing Java codebase.

- **Character Concept**: **Echo** is a 100% original ginger-cream pet cat (must NOT resemble Talking Tom or any copyrighted character). Across 6 horror phases, Echo stretches from a cute, expressive housecat (`0.85` blocks tall) into an eerie, hunched digital-horror entity (`2.4` blocks tall) with hollow glowing eyes, a wide unhinged jaw with small flat teeth, elongated limbs, a whip-like split tail, and 4 floating glitch shards.
- **Tone**: Atmospheric/digital uncanny horror (think *Inscryption* / analog glitch horror) — **no gore, no blood splatters, no exposed organs**.

### 2. Existing Files Provided to You (Drop-in Replacement)
1. **Cute Model & Animations (`64x64` UV)**:
   - `assets/echocat/geo/entity/echo.geo.json` (13 bones: `root`, `body`, `head`, `jaw`, `ear_left`, `ear_right`, `tail_base`, `tail_mid`, `tail_tip`, `leg_front_left`, `leg_front_right`, `leg_back_left`, `leg_back_right`)
   - `assets/echocat/animations/entity/echo.animation.json` (`idle`, `walk`, `sit`, `talk`)
   - 5 Phase Textures (`64x64` PNG): `echo_cute.png`, `echo_weird.png`, `echo_glitch.png`, `echo_chaos.png`, `echo_red.png`
2. **Horror Boss Model & Animations (`128x128` UV)**:
   - `assets/echocat/geo/entity/echo_horror.geo.json` (see `MODEL_SPEC.md` for the exact 32 bone names, including `spine_ridge`, `jaw_upper`, `jaw_lower`, `eye_left`, `eye_right`, `glitch_shard_1..4`)
   - `assets/echocat/animations/entity/echo_horror.animation.json` (12 animations: `horror_idle`, `horror_walk`, `horror_run`, `attack_swipe`, `attack_bite`, `attack_pounce`, `teleport_out`, `teleport_in`, `overload_telegraph`, `stunned`, `death`, `jumpscare_pose`)
   - 3 Horror Textures (`128x128` PNG): `echo_horror.png`, `echo_horror_glowing.png` (emissive mask for GeckoLib `AutoGlowingGeoLayer`), and `echo_red_overlay.png`

### 3. Required Deliverables & Technical Constraints
- **Format**: GeckoLib 4 Bedrock Geometry (`format_version: 1.12.0`) and GeckoLib Animation (`format_version: 1.8.0`).
- **Cube Count Limit**: Under `50` cubes for the Cute model; under `160` cubes for the Horror model.
- **Zero Z-Fighting**: Use clean `inflate` values (`0.01` to `0.05`) on overlapping limb/jaw joints.
- **Bone Names**: Keep all existing top-level bone names identical to `MODEL_SPEC.md` (you may add child sub-bones for individual fingers/whiskers if desired).

### 4. Intellectual Property & License Transfer Wording (Include in Contract)
> *"Artist confirms that all delivered 3D geometry, UV maps, textures, and keyframe animations are 100% original works created specifically for Client, do not copy or derive from any third-party mod or copyrighted character, and assigns full, exclusive worldwide copyright and commercial distribution rights (Work Made for Hire) to Client upon final payment."*

### 5. Fair Market Budget Range (For Requesting Quotes)
- **Option A — Texture Repaint & Animation Polish Only (keeping existing cube geometry)**: `$60 – $120 USD`
- **Option B — Full Custom Horror Model Upgrade + 12 Polished Animations + Hand-Pixelled Textures**: `$150 – $300 USD`
