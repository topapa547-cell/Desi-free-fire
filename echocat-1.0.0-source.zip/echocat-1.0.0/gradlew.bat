@rem Gradle startup script for Windows (Forge 1.20.1 MDK)
@if "%DEBUG%"=="" @echo off
setlocal
set DIRNAME=%~dp0
if "%DIRNAME%"=="" set DIRNAME=.
set WRAPPER_JAR=%DIRNAME%gradle\wrapper\gradle-wrapper.jar
set WRAPPER_URL=https://raw.githubusercontent.com/gradle/gradle/v8.8.0/gradle/wrapper/gradle-wrapper.jar

if not exist "%WRAPPER_JAR%" (
    echo [EchoCat Gradle Wrapper] Downloading gradle-wrapper.jar...
    if not exist "%DIRNAME%gradle\wrapper" mkdir "%DIRNAME%gradle\wrapper"
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri '%WRAPPER_URL%' -OutFile '%WRAPPER_JAR%'"
)

if exist "%WRAPPER_JAR%" (
    java -Xmx64m -Xms64m -classpath "%WRAPPER_JAR%" org.gradle.wrapper.GradleWrapperMain %*
    exit /b %ERRORLEVEL%
) else (
    gradle %*
    exit /b %ERRORLEVEL%
)
