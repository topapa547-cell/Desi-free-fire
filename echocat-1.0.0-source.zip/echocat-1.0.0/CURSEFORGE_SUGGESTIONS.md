# CurseForge Marketing, Titles, Tags, Screenshots & Trailer Guide (`CURSEFORGE_SUGGESTIONS.md`)

## 1. Five Project Title Options
1. **Echo: The Talking Cat (Horror Companion)** *(Recommended — clear, searchable, states both hooks)*
2. **Echo: The Talking Cat — 6-Phase Horror Pet**
3. **Echo: The Talking Cat [Forge 1.20.1 / GeckoLib]**
4. **Echo: The Talking Cat — From Cute Pet to Nightmare**
5. **Echo: The Talking Cat (Voice, Chat & Boss Fight)**

## 2. CurseForge Categories & Tags to Select
- **Primary Category**: `Mobs`
- **Secondary Categories**: `Adventure and RPG`, `Magic`, `ores and Resources`
- **Search Tags**: `Horror`, `Companion`, `Pet`, `Bosses`, `GeckoLib`

## 3. Ten High-Impact Screenshot Ideas (With Exact Setup Commands)
1. **Shot 1 — "Your New Best Friend" (Phase 1 Cute)**:
   - *Setup*: Daytime in a cozy oak house or flower forest. Run `/echo summon`, spawn Echo, right-click so it sits on a carpet, and type `Hello Echo!` in chat.
   - *Capture*: Frame Echo mid-talk animation with the floating `"Hello Echo!"` bubble above its head.
2. **Shot 2 — "Something He Never Said..." (Phase 2 Weird)**:
   - *Setup*: Set time to midnight (`/time set midnight`), run `/echo phase set 2`, and chat `Goodnight Echo`.
   - *Capture*: Capture Echo's dilated amber eyes and the creepy follow-up line in chat (`<Echo> the moon is watching us tonight`).
3. **Shot 3 — "Digital Breakdown" (Phase 3 Glitch)**:
   - *Setup*: Run `/echo phase set 3` inside a dimly lit room and walk within 6 blocks of Echo.
   - *Capture*: Catch Echo mid-RGB-split (showing the red and cyan ghost duplicates) with the subtle scanlines across the HUD.
4. **Shot 4 — "Echo's Journal UI"**:
   - *Setup*: Right-click **Echo's Journal** (`echocat:echo_journal`).
   - *Capture*: Clean screenshot of the gold-bordered Mission Tracker UI showing Mission #2 active and Mission #1 checked off.
5. **Shot 5 — "Mining Static Blocks & Red Crystal Ore"**:
   - *Setup*: Place a small vein of `echocat:static_block` and `echocat:red_crystal_ore` in a deepslate cave (`F1` off, holding an Iron Pickaxe).
   - *Capture*: Show the glowing cyan/magenta and deep crimson ore veins in the cave wall.
6. **Shot 6 — "Fractured Crowd" (Phase 4 Chaos)**:
   - *Setup*: Spawn 4 Zombies and 3 Cows in a plains clearing at night, then run `/echo phase set 4`.
   - *Capture*: Show the glowing outlines, dark smoke, and red eye particles as the corrupted mobs fight each other while Echo watches calmly.
7. **Shot 7 — "The Watcher in the Fog" (Phase 5 Red)**:
   - *Setup*: Run `/echo phase set 5` in a spruce forest at dusk. Stand 15 blocks away from Echo without looking directly at its crosshair center.
   - *Capture*: Capture Echo's blood-red overlay staring at you from between the trees.
8. **Shot 8 — "Crafting The Remote"**:
   - *Setup*: Run `/echo give all`, open a Crafting Table, and arrange the 5 components in the shaped recipe.
   - *Capture*: Screenshot of the Crafting Table GUI showing **The Remote** in the output slot.
9. **Shot 9 — "Echo Is Charging!" (Phase 6 Boss Telegraph)**:
   - *Setup*: Run `/echo phase set 6` in Survival/Hard (with good armor) and hold **The Remote** in your hand as Echo begins its 5th-attack `overload_telegraph`.
   - *Capture*: Capture the 2.4-block horror form with unhinged jaw, spinning glowing shards, and the `[!] USE THE REMOTE WITHIN 8 BLOCKS NOW! [!]` warning banner!
10. **Shot 10 — "You Turned Echo Off" (Purified Companion)**:
    - *Setup*: Use the **Purified Echo Plush Summoner** (`/echo give purified_echo_plush`) at sunrise.
    - *Capture*: Show the peaceful, permanently Cute Echo sitting beside the player holding **Echo's Heart**.

## 4. Three Short Video / TikTok / YouTube Shorts Trailer Ideas (Shot-by-Shot)

### Trailer 1: "My Minecraft Cat Started Repeating Things I Never Said..." (18 Seconds)
- **0:00–0:05**: Cute daytime montage. Summon Echo (`/echo summon`), type `I love my cat!`, and show Echo happily repeating `<Echo> I love my cat!` with a cute meow.
- **0:05–0:10**: Cut to night inside your base (`/echo phase set 2`). Type `Time to mine!`. Echo replies `<Echo> Time to mine!`... then 1 second later adds `<Echo> something is scratching inside the wall`.
- **0:10–0:14**: Cut to Phase 3 (`/echo phase set 3`). Echo's model jitters into red/cyan RGB clones and stutters `<Echo> He-He-He11o...`.
- **0:14–0:18**: Cut to a dark forest in Phase 6 (`/echo phase set 6`). Turn around as the 2.4-block glowing Horror Echo lunges into the camera (`jumpscare_pose`). Cut to black with title card.

### Trailer 2: "The 5 Missions to Build The Remote" (25 Seconds)
- **0:00–0:05**: Open **Echo's Journal** showing the 5-step checklist.
- **0:05–0:12**: Quick 1.5-second cuts of crafting the `Echo Circuit`, mining a glowing `Static Block` for the `Glitch Shard`, slaying a glowing Corrupted Zombie for the `Corrupted Core`, and mining `Red Crystal Ore` below `Y=0`.
- **0:12–0:17**: Slam all 5 parts into the Crafting Table to craft **The Remote**.
- **0:17–0:25**: Show the Phase 6 Boss charging its Overload (`Echo is charging!`), right-click **The Remote** to stun Echo in a shower of electric sparks (`3x Damage!`), and land the final blow!

### Trailer 3: "What Happens When You Stare at Echo in Phase 5?" (15 Seconds)
- **0:00–0:06**: Player walks backward through a misty forest (`/echo phase set 5`). Echo stalks 15 blocks behind, glowing crimson and breathing raspily.
- **0:06–0:10**: Player snaps their crosshair directly onto Echo -> Echo dissolves into black smoke and static (`teleport_out`)!
- **0:10–0:15**: Player looks around confused... then slowly turns 180 degrees to find the 2.4-block Horror silhouette standing right behind them.
