# Changelog (`CHANGELOG.md`)

## [1.0.0] - Release Polish, Full Audit, Accessibility & Automated Tests
- **Added**: First-launch comfort & privacy screen (`FirstLaunchWarningScreen`) with instant toggles for Photosensitive Mode, Jumpscares, and Horror Intensity (`1–3`).
- **Added**: Instant Comfort Panic Button — `/echo calm` command (permission level 0, usable by any player) and `K` keybind (`Calm Echo`) to immediately return Echo to a harmless `CUTE` state.
- **Added**: `AiContentFilter` blocking URLs, self-harm phrasing, real-world threats, graphic gore, and slurs in external AI outputs with automatic offline fallback.
- **Added**: `performanceMode` config option (reduces particle counts by 60%, disables RGB-split ghost passes, and throttles corruption scans to 40 ticks).
- **Added**: Data versioning (`DataVersion = 1`) across `PlayerPhaseData`, `PlayerMissionData`, `DailyAiRequestData`, and `EchoEntity` NBT.
- **Added**: Automated Forge GameTests (`EchoGameTests`) and unit/isolation verification suite (`Phase5ReleaseTest`).
- **Polished**: Added whisker detail cubes and anti-z-fighting `inflate` values to `echo.geo.json` and `echo_horror.geo.json`, shaded fur strokes on all phase textures, and added secondary ear/tail motion to animations.
- **Fixed**: Ensured `ServerBossEvent` is always removed on `EchoEntity#remove` and `EchoEntity#die` (including `/kill`), and cleared static queues on `ServerStoppingEvent`.

## [0.4.0] - Phase 4: RED Watcher, HORROR_FINAL Boss, 5 Missions & The Remote
- **Added**: 32-bone, 2.4-block hunched horror model (`echo_horror.geo.json`), 12 animations (`echo_horror.animation.json`), `AutoGlowingGeoLayer` (`echo_horror_glowing.png`), and `EchoRedOverlayLayer` (`echo_red_overlay.png`).
- **Added**: Phase 5 (`RED`) Watcher behavior (12–20 block stalking distance, line-of-sight dissolve teleportation, gradual model morph).
- **Added**: Phase 6 (`HORROR_FINAL`) 300-HP Boss fight with 5-step attack cycle, 3-second Overload telegraph, **The Remote** counter-stun (`12s` stun + `3x` damage), boss music loop, and defeat rewards (`Echo's Heart` & `Purified Echo Plush Summoner`).
- **Added**: 5 progressive survival missions, `Static Block` & `Red Crystal Ore` worldgen, Global Loot Modifier chest injection, and `Echo's Journal` GUI screen.

## [0.3.0] - Phase 3: GLITCH & CHAOS
- **Added**: Phase 3 (`GLITCH`) model bone jitter, texture flicker, invisibility flicker, RGB-split ghost duplicates, 2D proximity scanline overlay, `GlitchTextModifier`, and 4 procedural `.ogg` sounds.
- **Added**: Phase 4 (`CHAOS`) temporary mob corruption (`ChaosCorruptionHandler` + 3 custom AI goals) with full restoration guarantees.

## [0.2.0] - Phase 2: Chat, Voice, AI & First Creepy Shift
- **Added**: Server chat repetition (`ChatRepeatHandler`), 4-second 3D floating speech bubble, `HttpAIService` + 50-line `LocalCreepyFallback`, and optional push-to-talk `V` key voice input (`VoiceInputHandler`) with one-time privacy consent screen.

## [0.1.0] - Phase 1: Foundation
- **Added**: Initial Forge 1.20.1 + GeckoLib 4 project structure, `EchoEntity` (`TamableAnimal`), 6-phase `EchoPhase` & `PhaseManager`, `EchoPlushSummonerItem`, and operator commands.
