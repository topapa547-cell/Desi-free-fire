# Compatibility & Technical Environment Report (`COMPATIBILITY.md`)

| Area | Status & Details |
| :--- | :--- |
| **Minecraft Version** | Minecraft Java Edition `1.20.1` (`[1.20.1,1.21)` declared in `mods.toml`). |
| **Forge Version** | Target & configured against **Minecraft Forge `47.3.0`** (`[47,)` declared in `mods.toml`). |
| **Java Version** | **Java 17** (`JavaLanguageVersion.of(17)`). Verified against OpenJDK `17.0.21`. |
| **GeckoLib Dependency** | **GeckoLib `4.4.9`** (`geckolib-forge-1.20.1:4.4.9`, version range `[4.4,)` mandatory in `mods.toml`). If GeckoLib is missing from `.minecraft/mods/`, Forge displays a clean, human-readable missing-dependency screen before loading the game rather than crashing mid-load. |
| **Singleplayer vs. Dedicated Server** | **Full Parity & Dedicated-Server Safe**: All client rendering, screens, keybindings, and audio capture are isolated behind `@OnlyIn(Dist.CLIENT)` and `DistExecutor.unsafeRunWhenOn(Dist.CLIENT, ...)`. Verified via automated classloading test (`Phase5ReleaseTest`). |
| **Multiplayer (Multiple Players)** | Each player has their own independent `EchoPhase` (`PlayerPhaseData`), `CompletedMissions` (`PlayerMissionData`), and `EchoEntity` (`TamableAnimal#getOwnerUUID`). One player's phase or `/echo calm` panic button affects only their own Echo. |
| **Embeddium / Sodium / Rubidium / OptiFine / Iris** | **High Compatibility**: Screen glitch scanlines and chromatic bars (`GlitchOverlayRenderer`) are rendered using standard 2D `GuiGraphics#fill` quads (`RegisterGuiOverlaysEvent`) rather than custom GLSL post-processing shaders, avoiding framebuffer conflicts with Embeddium, Iris, and OptiFine. |
| **Known Shader Pack Note (`AutoGlowingGeoLayer`)** | GeckoLib's `AutoGlowingGeoLayer` (`echo_horror_glowing.png`) uses emissive render types. Under certain third-party Iris/OptiFine shader packs that override entity lightmaps, emissive eyes/shards may appear slightly softer or brighter depending on the shader pack's bloom settings. |
| **Low-End PCs (`performanceMode`)** | Setting `performanceMode = true` in `echocat-common.toml` disables the extra 2 RGB-split ghost render passes in `EchoRenderer`, cuts particle counts by 60%, and slows the Chaos mob corruption scan from 20 ticks to 40 ticks. |
