# Third-Party Notices & Disclaimers (`THIRD_PARTY_NOTICES.md`)

**NOT AN OFFICIAL MINECRAFT PRODUCT. NOT APPROVED BY OR ASSOCIATED WITH MOJANG OR MICROSOFT.**  
*Echo: The Talking Cat* is an independent, original community mod and is not affiliated with, endorsed by, or connected to Mojang Studios, Microsoft Corporation, Outfit7 Limited, or any other third-party game developer.

## Third-Party Software Credits

### 1. GeckoLib 4 (`software.bernie.geckolib`)
- **Authors**: Gecko, Eliot, Tslat, and contributors
- **License**: MIT License
- **Repository**: https://github.com/bernie-g/geckolib
- **Usage**: Used as an external required Forge mod dependency for 3D keyframe animation and emissive layer rendering.

### 2. Minecraft Forge (`net.minecraftforge`)
- **Authors**: Minecraft Forge Development Team
- **License**: GNU Lesser General Public License v2.1 (LGPL-2.1)
- **Website**: https://files.minecraftforge.net/
- **Usage**: Mod loader and event/registry framework for Minecraft Java Edition 1.20.1.

### 3. Google Gson (`com.google.gson`)
- **Authors**: Google Inc.
- **License**: Apache License 2.0
- **Usage**: Bundled with Minecraft 1.20.1 runtime; used to serialize and parse JSON payloads for optional AI HTTP requests.
