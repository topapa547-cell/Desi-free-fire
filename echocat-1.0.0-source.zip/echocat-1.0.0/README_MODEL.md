# Editing Echo's 3D Model, Animations & Textures in Blockbench

This project uses **GeckoLib 4** (`format_version: 1.12.0` geometry and `1.8.0` animations) for Minecraft 1.20.1.

## 1. Installing the GeckoLib Plugin in Blockbench
1. Download and open **[Blockbench](https://www.blockbench.net/)** (desktop app recommended).
2. Go to **File -> Plugins...**, switch to the **Available** tab, search for **GeckoLib Animation Utils**, and click **Install**.

## 2. Opening the 3D Model (`echo.geo.json`)
1. In Blockbench, click **File -> Open Model...**.
2. Navigate to:
   `src/main/resources/assets/echocat/geo/entity/echo.geo.json`
3. In the left **Textures** panel, click **Import Texture** (or drag and drop) and select any of the 6 phase textures from:
   `src/main/resources/assets/echocat/textures/entity/`
   - `echo_cute.png` (Phase 1)
   - `echo_weird.png` (Phase 2)
   - `echo_glitch.png` (Phase 3)
   - `echo_chaos.png` (Phase 4)
   - `echo_red.png` (Phase 5)
   - `echo_horror.png` (Phase 6)

## 3. Bone Hierarchy Reference (Do Not Rename Bones Without Updating Java Code)
Keep the exact bone names below so `EchoModel.java` and `echo.animation.json` continue to bind automatically:
- `root` (origin `[0, 0, 0]`)
  - `body`
    - `head` *(driven by `EchoModel#setCustomAnimations` for player look-at)*
      - `ear_left`
      - `ear_right`
      - `jaw` *(driven by `animation.echo.talk`)*
    - `tail_base`
      - `tail_mid`
        - `tail_tip`
    - `leg_front_left`
    - `leg_front_right`
    - `leg_back_left`
    - `leg_back_right`

## 4. Opening and Editing Animations (`echo.animation.json`)
1. With `echo.geo.json` open in Blockbench, switch to the **Animate** tab in the top-right corner.
2. In the left **Animations** panel, click **Import Animations...** and select:
   `src/main/resources/assets/echocat/animations/entity/echo.animation.json`
3. You will see the 4 core animations:
   - `animation.echo.idle` — Subtle breathing chest expansion, ear twitches, and 3-segment tail sway.
   - `animation.echo.walk` — Quadruped walk cycle with body bounce.
   - `animation.echo.sit` — Seated posture with tilted torso and folded hind legs.
   - `animation.echo.talk` — Jaw opening/closing and ear expressive movement (played on the overlay `talk_controller`).
4. After making edits, save via **File -> Save Model** (`Ctrl+S`) for geometry and click the floppy disk icon next to `echo.animation.json` in the **Animations** panel to export updated keyframes.
