# Full Code, Security, Performance & Stability Audit Report (`AUDIT_REPORT.md`)

**Project**: Echo: The Talking Cat (`com.echocat.mod`, `modId = echocat`, Version `1.0.0`)  
**Platform**: Minecraft Java Edition `1.20.1`, Forge `47.3.0`, GeckoLib `4.4.9`, Java `17`

## 1. Server / Client Separation Audit
- **Checked**: Every class under `com.echocat.mod` (`EchoCatMod`, `registry/*`, `entity/*`, `phase/*`, `mission/*`, `ai/*`, `chat/*`, `chaos/*`, `item/*`, `loot/*`, `command/*`, `network/*`).
- **Findings & Fixes**:
  - All client-only classes (`Minecraft`, `Screen`, `ConfirmScreen`, `GuiGraphics`, `KeyMapping`, `GeoEntityRenderer`, `javax.sound.sampled.*`) are strictly isolated inside `com.echocat.mod.client.*` and annotated with `@OnlyIn(Dist.CLIENT)`.
  - All Server->Client packets (`PhaseSyncPacket`, `EchoSpeechBubblePacket`, `PhaseTransitionEffectPacket`, `MissionSyncPacket`, `JumpscarePacket`) and `EchoJournalItem#use` delegate to `ClientPacketHandlers` exclusively inside `DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> ...)`.
  - **Verification**: Verified via `Phase5ReleaseTest` by loading and instantiating all common/server classes, packets, items, and handlers without loading any `@OnlyIn(Dist.CLIENT)` class.

## 2. Thread Safety & Off-Thread I/O Audit
- **Checked**: `HttpAIService`, `VoiceInputHandler`, `TtsPlaybackHelper`, and `ChatRepeatHandler`.
- **Findings & Fixes**:
  - `DailyAiRequestData` (`SavedData` on the Overworld) is accessed strictly on the main server thread inside `HttpAIService#generateForPlayer` *before* dispatching `CompletableFuture.supplyAsync(..., this.executor)`.
  - All AI completions hop back to the main server thread via `server.execute(...)` before touching `PENDING_SPEECH` or any `Entity` / `ServerLevel`.
  - On the client, `VoiceInputHandler` sends `VoiceTextPacket` via `Minecraft.getInstance().execute(...)` after background HTTP transcription completes.

## 3. Memory Leaks & Lifecycle Cleanup Audit
- **Issues Found & Fixed**:
  1. **Boss Bar Cleanup on `/kill` or `Entity#remove`**: Previously, `EchoEntity` only cleared `bossEvent` inside `completeBossDefeatSequence()` and `stopSeenByPlayer()`. If an admin ran `/kill @e[type=echocat:echo]` or the entity was discarded during Phase 6, the `ServerBossEvent` could linger. **Fix**: Overrode both `EchoEntity#remove(RemovalReason)` and `EchoEntity#die(DamageSource)` to call `this.bossEvent.setVisible(false)` and `this.bossEvent.removeAllPlayers()`.
  2. **Static Map Cleanup on Server Stop**: `ChaosCorruptionHandler.ACTIVE_CORRUPTED_MOBS` holds references to `Mob` instances while corrupted, and `ChatRepeatHandler` holds scheduled speech queues. In singleplayer integrated servers, switching worlds without restarting the game could retain stale references if a world closed mid-corruption. **Fix**: Subscribed to `ServerStoppingEvent` in `EchoCatMod` to call `ChaosCorruptionHandler.clearAllActive()`, `ChatRepeatHandler.clearQueues()`, and `HttpAIService.INSTANCE.clearRateLimitCache()`.

## 4. Null Safety & Edge-Case Audit
- **Checked**: Player offline, Echo dead/unloaded, owner in another dimension, chunk unloaded during teleport, world reload during boss fight, Creative/Spectator players, multiple players with their own Echoes.
- **Fixes Applied**:
  - `EchoEntity#teleportSafelyAroundPlayer` explicitly checks `serverLevel.isLoaded(candidate)` and verifies collision shapes of the floor, feet, and head blocks so Echo never teleports into unloaded chunks or solid blocks.
  - `EchoEntity#tickHorrorFinalBossPhase` checks `owner.isCreative() || owner.isSpectator()` in addition to `!owner.isAlive() || owner.level() != this.level()` and calls `resetBossToCalmState()` so Creative/Spectator players or disconnected owners cleanly reset the boss.
  - `ChaosCorruptionHandler#onEntityJoinLevel` immediately strips any lingering `EchoCatCorrupted` NBT tag when a chunk/world reloads so no vanilla mob is ever permanently broken.

## 5. Data Persistence & Versioning Audit
- **Fixes Applied**:
  - Added `CURRENT_DATA_VERSION = 1` (`"DataVersion"` integer tag) and migration hooks to `PlayerPhaseData`, `PlayerMissionData`, `DailyAiRequestData`, and `EchoEntity` (`"EchoDataVersion"` and `"EchoAttackCounter"`).
  - Verified NBT round-trip serialization in `Phase5ReleaseTest` and `EchoGameTests`.

## 6. Exploit & Duplicate Behavior Audit
- **Checked & Hardened**:
  - **Summoner Duplication**: `EchoPlushSummonerItem` and `PurifiedEchoPlushItem` only spawn Echo on the server (`ServerLevel`) and immediately shrink the stack (unless in Creative mode).
  - **Static Block & Red Crystal Ore**: Configured with `.requiresCorrectToolForDrops()` and tagged in `mineable/pickaxe.json` and `needs_iron_tool.json`; loot tables drop 1x `glitch_shard` / 1x `red_crystal` (no infinite block self-drop loop).
  - **Mission Order Enforcement**: `MissionManager#checkInventoryForActiveMission` strictly checks only `getActiveMissionId(player)` (`1 -> 2 -> 3 -> 4 -> 5`), preventing out-of-order phase skipping while still allowing items gathered early to count once their mission becomes active.
  - **Command Permissions**: All debug/phase/mission/give/reset commands require `.requires(source -> source.hasPermission(2))` (operator level 2), while `/echo calm` is intentionally permission level 0 so any player can use the comfort panic button on their own Echo.

## 7. Networking & Security Audit
- **Fixes Applied**:
  - Only two packets travel Client $ightarrow$ Server: `VoiceTextPacket` and `CalmEchoPacket`.
  - Both now enforce a strict **1000ms per-player server-side packet rate limit**, null/alive sender checks, and hard 120-character UTF-8 bounds on `VoiceTextPacket`.
  - Clients have zero packets to set arbitrary phases, complete missions, or spawn items.

## 8. Logging & Privacy Audit
- **Fixes Applied**:
  - Confirmed `EchoConfig.COMMON.apiKey` and `EchoConfig.CLIENT.sttApiKey` are never logged anywhere.
  - Removed `ctx.lastPlayerMessage()` from the external AI prompt in `HttpAIService#buildRequestPayload` so private player chat text is not even needed to generate context-aware creepy lines (only non-identifying game state: time of day, biome, dimension, health, and phase are sent).
  -Added `AiContentFilter` to block URLs, self-harm phrasing, real-world threats, gore, and slurs in any external AI response.
