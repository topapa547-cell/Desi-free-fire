# Step-by-Step CurseForge Upload & Publishing Guide (`CURSEFORGE_UPLOAD_GUIDE.md`)

This beginner-friendly guide walks you through publishing **Echo: The Talking Cat** on CurseForge from start to finish.

> **Recommended Release Strategy**: Upload your first build as a **Beta (`1.0.0-beta.1` or `1.0.0` marked as Beta release type)** first, gather player feedback and bug reports for a few days, and then mark your next upload as a full **Release**.

## Step 1: Create Your CurseForge Author Account
1. Visit **[https://authors.curseforge.com/](https://authors.curseforge.com/)** and sign in with your CurseForge / Overwolf account.
2. Complete your author profile (display name and avatar).

## Step 2: Create a New Minecraft Mod Project
1. In the Author Console, click **Create Project** -> select **Minecraft** -> select **Mods**.
2. Fill in the required project creation fields:
   - **Name**: `Echo: The Talking Cat` *(or choose one from `CURSEFORGE_SUGGESTIONS.md`)*
   - **URL Slug**: `echo-the-talking-cat`
   - **Summary** *(under 250 characters)*: Copy the Short Summary Line from the top of `CURSEFORGE_DESCRIPTION.md`.
   - **Primary Category**: `Mobs`
   - **Secondary Categories**: `Adventure and RPG`, `Magic`, `Ores and Resources`
   - **License**: Select **All Rights Reserved** (or MIT if you choose to open-source the code).
3. **Upload Project Avatar**: Upload `docs/echocat_icon_400x400.png` (`400x400` PNG).
4. **Paste Project Description**: Switch the Description editor to **Markdown** (or Rich Text) and paste the body of `CURSEFORGE_DESCRIPTION.md`.
5. **Upload Screenshots**: In the **Media / Images** tab, upload 4 to 10 in-game screenshots taken using the shot list in `CURSEFORGE_SUGGESTIONS.md`.

## Step 3: Build & Upload the `.jar` File
1. Before building your public `.jar`, open `gradle.properties` and replace `YOUR_AUTHOR_NAME_HERE` with your handle, and update `issueTrackerURL` in `src/main/resources/META-INF/mods.toml`.
2. Run `.\gradlew.bat clean build` and locate `build/libs/echocat-1.0.0.jar`.
3. On your CurseForge project page, click **Upload File**:
   - **File**: Select `build/libs/echocat-1.0.0.jar`.
   - **Display Name**: `Echo: The Talking Cat v1.0.0 (Forge 1.20.1)`
   - **Release Type**: Choose **Beta** (recommended for first upload) or **Release**.
   - **Changelog**: Copy and paste the `[1.0.0]` section from `CHANGELOG.md`.
   - **Modloader**: Check **Forge**.
   - **Java Version**: Check **Java 17**.
   - **Game Version**: Check **1.20.1**.
   - **Related Projects (Dependencies — CRITICAL!)**:
     - Click **Add Relation** -> Search for **`GeckoLib`** -> Set type to **Required Dependency**. (This ensures the CurseForge App automatically installs GeckoLib whenever a player installs your mod!)
4. Click **Submit File**.

## Step 4: Moderation Review & What to Do If Rejected
- First-time projects are reviewed by human CurseForge moderators (typically within 1 to 3 business days).
- If a moderator requests a change (for example, clarifying your description, license, or external API disclosure), you will receive a notification in the Author Console with the exact reason. Make the requested adjustment and click **Resubmit**.

## Step 5: Updating Versions & Supporting Players Later
- To release `1.0.1` later: bump `mod_version=1.0.1` in `gradle.properties`, run `.\gradlew.bat clean build`, and click **Upload File** on your project page.
- Add a GitHub repository link to the **Issues** tab on CurseForge so players can report bugs cleanly instead of only posting stack traces in the comments.

## Step 6: Learning About the CurseForge Author Rewards Program
- Once your project is approved and accumulating downloads, you can opt into the **CurseForge Author Rewards Program** inside your Author Console (**Reward Store / Payouts** tab) to earn reward points from official downloads.
- **Important**: Always read the **current official CurseForge Author Rewards documentation and Terms of Service** on `authors.curseforge.com` for up-to-date eligibility thresholds, payout methods (such as PayPal/Tremendous), and tax/KYC form requirements.
