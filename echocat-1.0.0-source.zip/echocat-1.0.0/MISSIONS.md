# Echo: The Talking Cat — Survival Missions & Progression Guide (`MISSIONS.md`)

Echo evolves across **6 phases** driven by **5 progressive missions**. You can check your active mission and hints at any time using **Echo's Journal** (automatically given the first time you summon Echo, or crafted from `1x Book + 1x Orange Dye`).

> **Strict Order Guarantee**: Missions must be completed in order (`1 -> 2 -> 3 -> 4 -> 5`). However, if you find or mine a mission item early, keep it in your inventory! As soon as you advance to that mission, the game automatically detects the item in your inventory and completes the mission.

## Mission 1: The First Bond (`Phase 1 CUTE -> Phase 2 WEIRD`)
- **Objective**: Obtain **1x Echo Circuit** (`echocat:echo_circuit`).
- **How to Obtain**:
  1. **Crafting Table**:
     - Top Row: `Redstone`, `Nether Quartz`, `Redstone`
     - Middle Row: `Copper Ingot`, `Copper Ingot`, `Copper Ingot`
     - Bottom Row: `Redstone`, `Nether Quartz`, `Redstone`
  2. **Structure Chests**: Appears in vanilla dungeon, mineshaft, desert pyramid, and stronghold chests via EchoCat's Global Loot Modifier.

## Mission 2: Static Signal (`Phase 2 WEIRD -> Phase 3 GLITCH`)
- **Objective**: Obtain **1x Glitch Shard** (`echocat:glitch_shard`).
- **How to Obtain**:
  - Mine a **Static Block** (`echocat:static_block`), which generates in small ore-like veins across Overworld stone and deepslate (`Y = -16` to `Y = 56`). Requires an **Iron Pickaxe or better** and drops `1x Glitch Shard`.

## Mission 3: Fractured Crowd (`Phase 3 GLITCH -> Phase 4 CHAOS`)
- **Objective**: Obtain **1x Corrupted Core** (`echocat:corrupted_core`).
- **How to Obtain (Chicken-and-Egg Solution)**:
  - `Corrupted Core` drops when you kill a **Corrupted Mob** (default `50%` chance, configurable via `corruptedCoreDropChance`).
  - **How the Chicken-and-Egg Problem is Solved**: Even though full 12-mob corruption belongs to Phase 4 (`CHAOS`), during **Phase 3 (`GLITCH`)** Echo's unstable static aura already corrupts **up to 2 nearby mobs** within 16 blocks! Slay those GLITCH-corrupted mobs to obtain your `Corrupted Core` and trigger Phase 4 (`CHAOS`).

## Mission 4: Deep Arterial Pulse (`Phase 4 CHAOS -> Phase 5 RED`)
- **Objective**: Obtain **1x Red Crystal** (`echocat:red_crystal`).
- **How to Obtain**:
  1. **Mining**: Mine **Red Crystal Ore** (`echocat:red_crystal_ore`) in deep deepslate layers below `Y = -4` (`Y = -60` to `Y = -4`) using an **Iron Pickaxe or better**.
  2. **Structure Chests**: Also appears as rare loot in vanilla structure chests.

## Mission 5: The Countermeasure (`Phase 5 RED -> Phase 6 HORROR_FINAL`)
- **Objective**: Craft or obtain **The Remote** (`echocat:the_remote`).
- **Step 1 — Obtain Remote Casing (`echocat:remote_casing`)**:
  - Craft at a Crafting Table (`Iron Ingots` surrounding `Redstone` with a `Glass Pane` on top) or find in structure chests.
- **Step 2 — Craft The Remote**:
  - Top Row: `[Empty]`, `Glitch Shard`, `[Empty]`
  - Middle Row: `Echo Circuit`, `Corrupted Core`, `Red Crystal`
  - Bottom Row: `[Empty]`, `Remote Casing`, `[Empty]`
- **Result**: Crafting (or holding) **The Remote** while in Phase 5 (`RED`) completes Mission 5 and awakens Echo's **Phase 6 (`HORROR_FINAL`)** Boss Fight!
