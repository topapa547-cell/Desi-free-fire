#!/bin/sh
echo "============================================================"
echo "  Building Echo: The Talking Cat (echocat-1.0.0.jar)..."
echo "  First run takes 3-5 minutes to download Forge 1.20.1."
echo "============================================================"
cd "$(dirname "$0")" || exit 1
chmod +x ./gradlew
./gradlew clean build
if [ $? -eq 0 ]; then
    echo ""
    echo "BUILD SUCCESSFUL! Your JAR is at: build/libs/echocat-1.0.0.jar"
fi
