# Privacy & External API Transparency Notice (`PRIVACY.md`)

**Echo: The Talking Cat** is designed with **offline-first privacy** by default.

## 1. Default Mode (`apiProvider = "none"`): 100% Offline
- Out of the box, `apiProvider` is set to `"none"` and `voiceConsentGiven` is `false`.
- **Zero network requests are made** outside of standard Minecraft multiplayer packets.
- Echo repeats your text chat using local server logic and chooses creepy lines from the 50 built-in offline sentences (`LocalCreepyFallback`).

## 2. Optional AI Creepy Lines (`apiProvider = "openai"` or `"custom"`)
- **What is sent**: Only when the server administrator explicitly sets `apiProvider` and pastes their own `apiKey` in `echocat-common.toml`, the mod sends non-identifying in-game context (in-game time of day, biome ID, dimension ID, player health value, and current horror phase) to the configured `apiEndpoint` (`https://api.openai.com/v1/chat/completions` by default).
- **What is NOT sent**: Your Minecraft account password, IP address, system files, or raw private chat logs are never sent to the AI endpoint.

## 3. Optional Push-to-Talk Voice (`V` Key) & TTS
- **Explicit Consent Required**: The microphone (`javax.sound.sampled`) is **never** accessed until you press `V`, read the in-game Privacy Notice screen, and click **"I Consent (Enable Mic)"** (which sets `voiceConsentGiven = true` in `echocat-client.toml`).
- **How to Revoke Consent**: You can revoke microphone access at any time by setting `voiceConsentGiven = false` in `.minecraft/config/echocat-client.toml` or setting `enableVoice = false`.
- **No Continuous Recording & No Disk Storage**: Audio is captured strictly in RAM (16 kHz, 16-bit mono PCM) **only while you hold the `V` key** (capped at 10 seconds maximum) and is immediately discarded from memory after the transcription request completes. Audio is **never** saved to your hard drive.

## 4. API Key Security Warning
- Your API key is **never** shipped inside the mod `.jar`, **never** synced from the server to connected clients, and **never** written to game log files (`latest.log` / `debug.log`).
- **WARNING**: Your API key is stored in plain text inside your local `echocat-common.toml` / `echocat-client.toml` configuration file. **Never share your config files publicly or include them in exported modpack zips!**
- **Third-Party Terms & Costs**: Any usage of OpenAI or another third-party API is governed by that provider's own Terms of Service and Privacy Policy, and any API usage costs are billed directly to the API key owner by their provider. Mod authors and players should also check the **current official CurseForge terms** regarding mods that connect to external web services.
