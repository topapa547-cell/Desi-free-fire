@echo off
title Echo: The Talking Cat - One-Click JAR Builder
echo ============================================================
echo   Building Echo: The Talking Cat (echocat-1.0.0.jar)...
echo   First run takes 3-5 minutes to download Forge 1.20.1.
echo ============================================================
echo.

call "%~dp0gradlew.bat" clean build

if %ERRORLEVEL% EQU 0 (
    echo.
    echo ============================================================
    echo   BUILD SUCCESSFUL!
    echo   Your mod JAR is ready at:
    echo   %~dp0build\libs\echocat-1.0.0.jar
    echo   Opening the build\libs folder for you now...
    echo ============================================================
    explorer "%~dp0build\libs"
) else (
    echo.
    echo ============================================================
    echo   BUILD FAILED.
    echo   Make sure Java 17 (JDK 17) is installed from:
    echo   https://adoptium.net/temurin/releases/?version=17
    echo ============================================================
)
pause
