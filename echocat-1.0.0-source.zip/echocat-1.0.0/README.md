# Echo: The Talking Cat (Minecraft Forge 1.20.1)

> *Not an official Minecraft product. Not approved by or associated with Mojang or Microsoft.*

**Echo: The Talking Cat** is an original atmospheric horror & companion mod for **Minecraft Java Edition 1.20.1 (Forge)**. Summon an adorable talking pet cat named **Echo** that bonds to you, follows you, repeats what you say in chat (and optionally via push-to-talk voice), and gradually evolves across **6 atmospheric horror phases** driven by **5 survival missions**.

## 1. Requirements & Installation
1. Install **Java 17** and **Minecraft Forge 1.20.1** (`47.3.0` or newer).
2. Download **GeckoLib 4 for Forge 1.20.1** (`geckolib-forge-1.20.1-4.4.9.jar`).
3. Place both `geckolib-forge-1.20.1-4.4.9.jar` and `echocat-1.0.0.jar` into your `.minecraft/mods/` folder.

## 2. Features Overview
- **6 Distinct Phases**:
  1. **Phase 1 — CUTE**: Friendly ginger tabby that repeats your chat and voice messages with a 3D floating speech bubble.
  2. **Phase 2 — WEIRD**: Still repeats you, but occasionally adds eerie context-aware sentences you never said (works 100% offline with 50 built-in lines, or with any OpenAI-compatible API).
  3. **Phase 3 — GLITCH**: Stuttered syllables, character corruption, digital static bursts, model bone jitter, texture flickers, and RGB-split ghost copies.
  4. **Phase 4 — CHAOS**: Nearby mobs within 24 blocks become temporarily **Corrupted**, fighting each other with glowing outlines and crimson eye dust (and cleanly returning to normal afterward).
  5. **Phase 5 — RED (The Watcher)**: Echo stops following closely, keeps 12–20 blocks away, dissolves and teleports behind you when looked at, and gradually morphs into its 2.4-block horror silhouette.
  6. **Phase 6 — HORROR_FINAL**: A 300-HP multi-stage boss fight where you must counter Echo's 5th-attack **Overload Telegraph** within 8 blocks using **The Remote**!
- **5 Survival Missions & Echo's Journal**: Track objectives in-game using **Echo's Journal** (`echocat:echo_journal`).
- **Accessibility & Instant Panic Button**: Built-in `photosensitiveMode`, `horrorIntensity` (1–3), `enableJumpscares` toggle, text cues + subtitles for all audio warnings, and an instant **`/echo calm`** command (or **`K` keybind**) usable by any player to immediately return their Echo to a harmless Cute state.

## 3. Complete Configuration Guide

### Common Config (`echocat-common.toml`)
| Key | Default | Description |
| :--- | :--- | :--- |
| `enableChat` | `true` | Whether Echo listens to and repeats player text chat messages within 16 blocks. |
| `enableVoice` | `true` | Whether Echo accepts transcribed push-to-talk voice messages. |
| `apiProvider` | `"none"` | `"none"` = 100% offline fallback (50 built-in lines); `"openai"` or `"custom"` = HTTP chat completions. |
| `apiEndpoint` | `"https://api.openai.com/v1/chat/completions"` | OpenAI-compatible chat completions URL. |
| `apiKey` | `""` | Your secret API key (never logged or synced; do not share config publicly). |
| `apiModel` | `"gpt-4o-mini"` | Model name requested from the AI endpoint. |
| `phaseSpeedMultiplier` | `1.0` | Multiplier (`0.1` to `10.0`) for phase timers such as Phase 5 RED progression. |
| `maxAffectedMobs` | `12` | Maximum nearby mobs corrupted per Echo in Phase 4 (`CHAOS`). |
| `debugMode` | `false` | Logs non-sensitive diagnostic events (AI source, corruption counts). |
| `horrorIntensity` | `2` | `1` = Mild, `2` = Standard, `3` = Extreme. Scales visuals, volume, corruption, and whispers. |
| `weirdCreepyChance` | `0.35` | Probability (`0.0`–`1.0`) in Phase 2+ that Echo adds an unprompted creepy line. |
| `chatCooldownMs` | `1500` | Per-player cooldown in ms between chat/voice repetitions. |
| `maxAiRequestsPerDay` | `200` | World-wide daily cap on external AI HTTP requests before using offline fallback. |
| `corruptionBlacklist` | `[...]` | Entity IDs immune to Phase 3/4 corruption (bosses, villagers, golems, allays). |
| `maxCorruptionDurationSeconds` | `90` | Max seconds a mob stays corrupted before full restoration. |
| `allowMobDamageToPlayers` | `true` | Whether corrupted mobs can deal damage to players. |
| `corruptedDamageMultiplier` | `0.5` | Damage multiplier when a corrupted mob hits a player. |
| `bossHealth` | `300.0` | Max HP of Echo in Phase 6 (`HORROR_FINAL`). |
| `bossDamage` | `6.0` | Base melee damage of Echo in Phase 6 (`3 hearts`). |
| `overloadDamage` | `10.0` | Damage of an uncountered Overload burst (`5 hearts`, capped so it never one-shots full HP). |
| `stunDuration` | `12` | Seconds Echo is stunned (taking `3x` damage) when countered by The Remote. |
| `remoteCooldown` | `20` | Cooldown in seconds on The Remote after a successful counter. |
| `redPhaseDurationMinutes` | `10.0` | Real minutes for `redProgress` to climb `0.0 -> 1.0` in Phase 5. |
| `enablePurifiedPlush` | `true` | Allows the post-boss **Purified Echo Plush Summoner** to spawn a forever-Cute Echo. |
| `corruptedCoreDropChance` | `0.50` | Drop chance (`50%`) of `Corrupted Core` when killing a Corrupted mob. |
| `bossPhase2OverloadInterval` | `4` | Attacks per Overload cycle when the boss is below `50%` HP. |
| `performanceMode` | `false` | Reduces particles by 60%, disables RGB-split ghost passes, and slows corruption scans to 40 ticks. |

### Client Config (`echocat-client.toml`)
| Key | Default | Description |
| :--- | :--- | :--- |
| `photosensitiveMode` | `false` | Locks visual changes to $\le 2$/sec, lowers contrast by 65%, disables strobing & jumpscare flashes. |
| `enableJumpscares` | `true` | Enables the Phase 6 first-sight jumpscare visual and stinger. |
| `showFirstLaunchWarning` | `true` | Shows the one-time comfort & privacy screen on first world join. |
| `voiceConsentGiven` | `false` | Set to `true` when you accept the in-game microphone privacy notice (`V` key). |
| `sttEndpoint` | `"https://api.openai.com/v1/audio/transcriptions"` | Speech-to-Text multipart endpoint. |
| `sttApiKey` | `""` | Optional client STT/TTS key (falls back to `COMMON.apiKey` in singleplayer). |
| `sttModel` | `"whisper-1"` | Model name for STT transcription. |
| `enableTts` | `false` | Optional cat-pitched WAV Text-to-Speech playback. |
| `ttsEndpoint` | `"https://api.openai.com/v1/audio/speech"` | TTS HTTP endpoint. |
| `ttsModel` / `ttsVoice` | `"tts-1"` / `"alloy"` | Model and voice ID for optional TTS. |
| `showMissionHud` | `true` | Shows the active mission objective in the top-right corner of the HUD. |

## 4. Commands Reference
- **Any Player (Permission Level 0)**:
  - `/echo calm` *(or press `K`)* — **Instant Panic Button**: Returns your Echo to a harmless `CUTE` state and stops all horror/corruption effects.
- **Operators / Cheats Enabled (Permission Level 2)**:
  - `/echo summon` — Gives 1x `Echo Plush Summoner`.
  - `/echo phase get` | `/echo phase set <1-6>` | `/echo phase next` — Inspect or change your current horror phase.
  - `/echo mission list` | `/echo mission complete <1-5>` — View or complete survival missions.
  - `/echo give <item|all>` — Give mission items (`echo_circuit`, `glitch_shard`, `corrupted_core`, `red_crystal`, `remote_casing`, `the_remote`, `echo_journal`, `echo_heart`, `purified_echo_plush`, or `all`).
  - `/echo debug corrupted` — Shows the count of active corrupted mobs near your Echo.
  - `/echo reset` — Despawns your Echo, clears missions & corruption, and resets phase to `1 (Cute)`.
