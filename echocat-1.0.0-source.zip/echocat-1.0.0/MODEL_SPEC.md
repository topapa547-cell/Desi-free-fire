# Echo Horror Form 3D Model Specification (`MODEL_SPEC.md`)

- **Geometry File**: `src/main/resources/assets/echocat/geo/entity/echo_horror.geo.json` (`format_version: 1.12.0`, Identifier: `geometry.echo_horror`)
- **Animation File**: `src/main/resources/assets/echocat/animations/entity/echo_horror.animation.json` (`format_version: 1.8.0`)
- **Texture Resolution**: `128x128` (`echo_horror.png`, `echo_horror_glowing.png` via `AutoGlowingGeoLayer`, and `echo_red_overlay.png`)
- **Standing Height**: ~`2.4 blocks` (`38.5` to `49.5` model units to ear tips, hunched forward posture, elongated limbs)
- **Total Cube Count**: `44 cubes` across `32 bones` (well below the 200-cube performance ceiling)

## 1. Complete Bone Hierarchy, Pivots & UV Map

| Bone Name | Parent | Pivot `[X, Y, Z]` | UV Origin `[U, V]` | Description |
| :--- | :--- | :--- | :--- | :--- |
| `root` | *(none)* | `[0, 0, 0]` | — | Master origin bone |
| `hips` | `root` | `[0, 17, 2]` | `[0, 0]` | Pelvic base (`8x5x6`) |
| `torso` | `hips` | `[0, 20, 2]` | `[28, 0]` | Hunched lower spine (`7x8x5`, `rotX=12`) |
| `chest` | `torso` | `[0, 27, 1]` | `[52, 0]` | Broad ribcage (`9x7x7`, `rotX=18`) |
| `spine_ridge` | `chest` | `[0, 30, 3.5]` | `[86, 0]` | Row of 6 dorsal spikes along the back (tips glow in `echo_horror_glowing.png`) |
| `neck_1` | `chest` | `[0, 33, -1.5]` | `[0, 14]` | Lower craned neck segment (`4x4x4`) |
| `neck_2` | `neck_1` | `[0, 36, -2.5]` | `[16, 14]` | Upper craned neck segment (`3x4x3`) |
| `head` | `neck_2` | `[0, 38.5, -4.0]` | `[0, 24]` | Stretched feline cranium (`8x7x7`) |
| `ear_left` | `head` | `[2.8, 44.5, -6.5]` | `[32, 24]` | Tall intact left ear (`2x5x2` + `1x2x1` tip) |
| `ear_right` | `head` | `[-2.8, 44.5, -6.5]` | `[46, 24]` | Torn, shorter right ear (`2x3x2`, tilted `-18°`) |
| `jaw_upper` | `head` | `[0, 39.5, -9.5]` | `[56, 24]` & `[76, 24]` | Upper muzzle + 4 thin flat upper teeth cubes |
| `jaw_lower` | `head` | `[0, 38.0, -8.5]` | `[84, 24]` & `[76, 28]` | Hinged lower jaw + 4 thin flat lower teeth cubes (hinges wide open) |
| `eye_left` | `head` | `[2.0, 41.5, -10.0]` | `[0, 40]` & `[100, 0]` | Hollow dark socket cube + separate glowing crimson eye core (`[100, 0]`) |
| `eye_right` | `head` | `[-2.0, 41.5, -10.0]` | `[8, 40]` & `[100, 4]` | Hollow dark socket cube + separate glowing crimson eye core (`[100, 4]`) |
| `arm_left_upper` | `chest` | `[5.0, 32.0, -1.0]` | `[0, 46]` | Long upper left arm (`2x10x2`) |
| `arm_left_lower` | `arm_left_upper` | `[5.5, 22.0, -1.0]` | `[10, 46]` | Forearm (`2x10x2`) |
| `hand_left` | `arm_left_lower` | `[5.5, 12.0, -1.0]` | `[20, 46]`, `[32, 46]`, `[38, 46]` | Palm + 4 long thin fingers (each built from 2 segments: proximal + distal claw) |
| `arm_right_upper` | `chest` | `[-5.0, 32.0, -1.0]` | `[0, 46]` | Long upper right arm (`2x10x2`) |
| `arm_right_lower` | `arm_right_upper` | `[-5.5, 22.0, -1.0]` | `[10, 46]` | Forearm (`2x10x2`) |
| `hand_right` | `arm_right_lower` | `[-5.5, 12.0, -1.0]` | `[20, 46]`, `[32, 46]`, `[38, 46]` | Palm + 4 long thin 2-segment fingers |
| `leg_left_upper` | `hips` | `[2.8, 16.0, 2.0]` | `[0, 62]` | Left thigh (`3x8x3`) |
| `leg_left_lower` | `leg_left_upper` | `[3.0, 8.0, 2.0]` | `[14, 62]` | Left shin (`2x7x2`) |
| `foot_left` | `leg_left_lower` | `[3.0, 1.0, 2.0]` | `[24, 62]` | Left paw (`3x1x4`) |
| `leg_right_upper` | `hips` | `[-2.8, 16.0, 2.0]` | `[0, 62]` | Right thigh (`3x8x3`) |
| `leg_right_lower` | `leg_right_upper` | `[-3.0, 8.0, 2.0]` | `[14, 62]` | Right shin (`2x7x2`) |
| `foot_right` | `leg_right_lower` | `[-3.0, 1.0, 2.0]` | `[24, 62]` | Right paw (`3x1x4`) |
| `tail_1` .. `tail_5` | `hips` -> chain | `[0, 16.5, 5..21]` | `[0..52, 76]` | 5 articulated whip-like tail segments |
| `tail_6` | `tail_5` | `[0, 16.0, 25.0]` | `[100, 10]` | Bifurcated glitchy split tail tip (2 glowing prongs) |
| `glitch_shard_1..4` | `root` | Orbiting torso | `[100, 20..26]` | 4 floating digital shards orbiting the body |

## 2. Animation List (`echo_horror.animation.json`)
1. `animation.echo_horror.horror_idle` — Slow ribcage breathing, twitching hands, unnatural `±28°` head tilt, orbiting shards.
2. `animation.echo_horror.horror_walk` — Uneven stalking gait with lurching hips.
3. `animation.echo_horror.horror_run` — Fast four-limbed sprint posture.
4. `animation.echo_horror.attack_swipe` — Wide right-arm claw swipe.
5. `animation.echo_horror.attack_bite` — Neck lunge with `jaw_lower` opening `58°`.
6. `animation.echo_horror.attack_pounce` — Crouched wind-up and forward leap with both arms outstretched.
7. `animation.echo_horror.teleport_out` — Stretches vertically and collapses into expanding glitch shards.
8. `animation.echo_horror.teleport_in` — Reforms body from glitch shards.
9. `animation.echo_horror.overload_telegraph` — 3.0-second wind-up: chest vibrates, jaw unhinges `65°`, arms raise, and all 4 glitch shards spin rapidly (`1080°`).
10. `animation.echo_horror.stunned` — Slumped posture, dropped head, locked limbs (played for 12s after being countered by The Remote).
11. `animation.echo_horror.death` — 4.0-second collapse into dissipating shards.
12. `animation.echo_horror.jumpscare_pose` — Rapid head/jaw lunge when the boss first spots its owner.

## 3. Honest Note on Blockbench Hand-Polish
Because this geometry was generated procedurally from exact mathematical coordinates, the 8 finger segments on `hand_left` and `hand_right` and the 8 teeth cubes on `jaw_upper`/`jaw_lower` are grouped inside their respective hand/jaw bones rather than having 16 individual sub-bones. When you open `echo_horror.geo.json` in Blockbench, you can optionally angle individual finger cubes or sculpt asymmetric vertex offsets on the torso/head for even more organic horror silhouette detail.
