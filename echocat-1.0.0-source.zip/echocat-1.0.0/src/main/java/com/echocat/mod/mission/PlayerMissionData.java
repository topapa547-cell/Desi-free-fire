package com.echocat.mod.mission;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.IntArrayTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Persistent world SavedData storing completed mission IDs per player UUID (with `dataVersion` migration support).
 */
public class PlayerMissionData extends SavedData {
    public static final int CURRENT_DATA_VERSION = 1;
    private static final String DATA_NAME = "echocat_player_missions";
    private static final String TAG_DATA_VERSION = "DataVersion";
    private static final String TAG_PLAYERS = "Players";
    private static final String TAG_UUID = "UUID";
    private static final String TAG_MISSIONS = "CompletedMissions";

    private int dataVersion = CURRENT_DATA_VERSION;
    private final Map<UUID, Set<Integer>> completedMissions = new HashMap<>();

    public PlayerMissionData() {
    }

    public static PlayerMissionData load(CompoundTag tag) {
        PlayerMissionData data = new PlayerMissionData();
        data.dataVersion = tag.contains(TAG_DATA_VERSION) ? tag.getInt(TAG_DATA_VERSION) : CURRENT_DATA_VERSION;

        ListTag list = tag.getList(TAG_PLAYERS, Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag entry = list.getCompound(i);
            if (entry.hasUUID(TAG_UUID)) {
                UUID uuid = entry.getUUID(TAG_UUID);
                int[] ids = entry.getIntArray(TAG_MISSIONS);
                Set<Integer> set = new HashSet<>();
                for (int id : ids) {
                    if (id >= 1 && id <= MissionManager.TOTAL_MISSIONS) {
                        set.add(id);
                    }
                }
                data.completedMissions.put(uuid, set);
            }
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putInt(TAG_DATA_VERSION, this.dataVersion);
        ListTag list = new ListTag();
        for (Map.Entry<UUID, Set<Integer>> entry : this.completedMissions.entrySet()) {
            CompoundTag playerTag = new CompoundTag();
            playerTag.putUUID(TAG_UUID, entry.getKey());
            int[] arr = entry.getValue().stream().mapToInt(Integer::intValue).toArray();
            playerTag.put(TAG_MISSIONS, new IntArrayTag(arr));
            list.add(playerTag);
        }
        tag.put(TAG_PLAYERS, list);
        return tag;
    }

    public int getDataVersion() {
        return this.dataVersion;
    }

    public boolean isMissionCompleted(UUID playerUuid, int missionId) {
        Set<Integer> set = this.completedMissions.get(playerUuid);
        return set != null && set.contains(missionId);
    }

    public boolean markMissionCompleted(UUID playerUuid, int missionId) {
        Set<Integer> set = this.completedMissions.computeIfAbsent(playerUuid, k -> new HashSet<>());
        boolean added = set.add(missionId);
        if (added) {
            this.setDirty();
        }
        return added;
    }

    public void clearMissions(UUID playerUuid) {
        if (this.completedMissions.remove(playerUuid) != null) {
            this.setDirty();
        }
    }

    public Set<Integer> getCompletedMissions(UUID playerUuid) {
        return Collections.unmodifiableSet(this.completedMissions.getOrDefault(playerUuid, Collections.emptySet()));
    }

    public static PlayerMissionData get(MinecraftServer server) {
        ServerLevel overworld = server.overworld();
        return overworld.getDataStorage().computeIfAbsent(
                PlayerMissionData::load,
                PlayerMissionData::new,
                DATA_NAME
        );
    }
}
