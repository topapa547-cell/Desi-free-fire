package com.echocat.mod.chaos;

import com.echocat.mod.config.EchoConfig;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;

import java.util.EnumSet;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Low-chance target goal injected into corrupted mobs during Phase 4 (CHAOS)
 * that periodically makes the corrupted mob turn its aggression toward Echo's owner player
 * (only when {@code allowMobDamageToPlayers} is enabled and the player is not in Creative/Spectator).
 */
public class CorruptedAggroPlayerGoal extends Goal {
    private final Mob mob;
    private Player targetPlayer;
    private int checkTimer = 20;

    public CorruptedAggroPlayerGoal(Mob mob) {
        this.mob = mob;
        this.setFlags(EnumSet.of(Goal.Flag.TARGET));
    }

    @Override
    public boolean canUse() {
        if (!ChaosCorruptionHandler.isCorrupted(this.mob)) {
            return false;
        }
        if (!EchoConfig.COMMON.allowMobDamageToPlayers.get()) {
            return false;
        }
        if (--this.checkTimer > 0) {
            return false;
        }
        this.checkTimer = 40; // Check every 2 seconds

        // Low-chance aggro roll (~22% per check)
        if (ThreadLocalRandom.current().nextFloat() > 0.22F) {
            return false;
        }

        UUID ownerUuid = ChaosCorruptionHandler.getCorruptionOwnerUuid(this.mob);
        if (ownerUuid == null) {
            return false;
        }

        Player owner = this.mob.level().getPlayerByUUID(ownerUuid);
        if (owner == null || !owner.isAlive() || owner.isCreative() || owner.isSpectator()) {
            return false;
        }
        if (this.mob.distanceToSqr(owner) > (20.0D * 20.0D)) {
            return false;
        }

        this.targetPlayer = owner;
        return true;
    }

    @Override
    public boolean canContinueToUse() {
        if (!ChaosCorruptionHandler.isCorrupted(this.mob) || !EchoConfig.COMMON.allowMobDamageToPlayers.get()) {
            return false;
        }
        LivingEntity current = this.mob.getTarget();
        return current instanceof Player p && p.isAlive() && !p.isCreative() && !p.isSpectator()
                && this.mob.distanceToSqr(p) <= (24.0D * 24.0D);
    }

    @Override
    public void start() {
        this.mob.setTarget(this.targetPlayer);
        super.start();
    }

    @Override
    public void stop() {
        this.targetPlayer = null;
        super.stop();
    }
}
