package com.echocat.mod.client.voice;

import com.echocat.mod.EchoCatMod;
import com.echocat.mod.chat.ChatRepeatHandler;
import com.echocat.mod.config.EchoConfig;
import com.echocat.mod.network.ModNetwork;
import com.echocat.mod.client.FirstLaunchWarningScreen;
import com.echocat.mod.network.CalmEchoPacket;
import com.echocat.mod.network.VoiceTextPacket;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.ChatFormatting;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.ConfirmScreen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.lwjgl.glfw.GLFW;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.TargetDataLine;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Client-side Push-To-Talk (default V key, category "Echo") voice capture and STT handler:
 * - Captures microphone audio strictly in memory (16 kHz, 16-bit signed PCM, mono) ONLY while
 *   the push-to-talk key is held, capped at 10 seconds maximum per recording.
 * - Requires explicit one-time player privacy consent ({@code EchoConfig.CLIENT.voiceConsentGiven})
 *   via an in-game confirmation screen before the microphone is ever opened.
 * - Renders a "[REC] Echo Listening..." HUD badge while recording.
 * - Uploads in-memory WAV bytes via asynchronous multipart/form-data to {@code sttEndpoint},
 *   parses the transcript, and sends {@link VoiceTextPacket} to the server.
 * - Never records continuously, never writes audio to disk, never logs API keys or private audio.
 */
@OnlyIn(Dist.CLIENT)
public final class VoiceInputHandler {
    public static final VoiceInputHandler INSTANCE = new VoiceInputHandler();

    public static final KeyMapping PUSH_TO_TALK_KEY = new KeyMapping(
            "key.echocat.push_to_talk",
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_V,
            "key.categories.echocat"
    );

    public static final KeyMapping CALM_ECHO_KEY = new KeyMapping(
            "key.echocat.calm_echo",
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_K,
            "key.categories.echocat"
    );

    private static final float SAMPLE_RATE = 16000.0F;
    private static final int SAMPLE_SIZE_BITS = 16;
    private static final int CHANNELS = 1;
    private static final int MAX_RECORD_SECONDS = 10;
    private static final int MAX_PCM_BYTES = (int) SAMPLE_RATE * (SAMPLE_SIZE_BITS / 8) * CHANNELS * MAX_RECORD_SECONDS;
    private static final int MIN_PCM_BYTES = (int) SAMPLE_RATE * (SAMPLE_SIZE_BITS / 8) * CHANNELS / 4; // >= 0.25s

    private final ExecutorService voiceExecutor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "EchoCat-Client-Voice");
        t.setDaemon(true);
        return t;
    });

    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(5))
            .executor(this.voiceExecutor)
            .build();

    private final AtomicBoolean recording = new AtomicBoolean(false);
    private boolean keyWasDown = false;
    private boolean calmKeyWasDown = false;
    private boolean firstLaunchCheckedThisSession = false;
    private boolean consentScreenShownThisPress = false;
    private long recordStartMs = 0L;
    private TargetDataLine activeMicLine = null;
    private ByteArrayOutputStream pcmBuffer = null;

    private VoiceInputHandler() {
    }

    public boolean isRecording() {
        return this.recording.get();
    }

    @SubscribeEvent
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) {
            if (this.recording.get()) {
                stopCapture(false);
            }
            return;
        }

        if (!this.firstLaunchCheckedThisSession && mc.screen == null) {
            this.firstLaunchCheckedThisSession = true;
            if (EchoConfig.CLIENT.showFirstLaunchWarning.get()) {
                mc.setScreen(new FirstLaunchWarningScreen());
                return;
            }
        }

        boolean calmDown = CALM_ECHO_KEY.isDown() && mc.screen == null;
        if (calmDown && !this.calmKeyWasDown) {
            ModNetwork.CHANNEL.sendToServer(new CalmEchoPacket());
        }
        this.calmKeyWasDown = calmDown;

        boolean keyDown = PUSH_TO_TALK_KEY.isDown() && mc.screen == null;

        if (keyDown && !this.keyWasDown) {
            handlePushToTalkPressed(mc);
        } else if (!keyDown && this.keyWasDown) {
            this.consentScreenShownThisPress = false;
            if (this.recording.get()) {
                stopCapture(true);
            }
        } else if (keyDown && this.recording.get()) {
            // Enforce strict 10-second max recording duration
            if (System.currentTimeMillis() - this.recordStartMs >= (MAX_RECORD_SECONDS * 1000L)) {
                displayClientChat(Component.translatable("message.echocat.voice.max_length").withStyle(ChatFormatting.YELLOW));
                stopCapture(true);
            }
        }

        this.keyWasDown = keyDown;
    }

    private void handlePushToTalkPressed(Minecraft mc) {
        if (!EchoConfig.COMMON.enableVoice.get()) {
            displayClientChat(Component.translatable("message.echocat.voice.disabled").withStyle(ChatFormatting.RED));
            return;
        }

        // Privacy Consent Gate: require explicit confirmation before ever touching javax.sound.sampled
        if (!EchoConfig.CLIENT.voiceConsentGiven.get()) {
            if (!this.consentScreenShownThisPress) {
                this.consentScreenShownThisPress = true;
                openVoiceConsentScreen(mc);
            }
            return;
        }

        startCapture();
    }

    private void openVoiceConsentScreen(Minecraft mc) {
        ConfirmScreen confirmScreen = new ConfirmScreen(
                accepted -> {
                    if (accepted) {
                        EchoConfig.CLIENT.voiceConsentGiven.set(true);
                        EchoConfig.CLIENT.voiceConsentGiven.save();
                        displayClientChat(Component.translatable("message.echocat.voice.consent_accepted")
                                .withStyle(ChatFormatting.GREEN));
                    } else {
                        displayClientChat(Component.translatable("message.echocat.voice.consent_declined")
                                .withStyle(ChatFormatting.YELLOW));
                    }
                    mc.setScreen(null);
                },
                Component.translatable("screen.echocat.voice_consent.title").withStyle(ChatFormatting.GOLD),
                Component.translatable("screen.echocat.voice_consent.body"),
                Component.translatable("screen.echocat.voice_consent.accept").withStyle(ChatFormatting.GREEN),
                Component.translatable("screen.echocat.voice_consent.decline").withStyle(ChatFormatting.RED)
        );
        mc.setScreen(confirmScreen);
    }

    private void startCapture() {
        if (this.recording.get()) {
            return;
        }
        try {
            AudioFormat format = new AudioFormat(SAMPLE_RATE, SAMPLE_SIZE_BITS, CHANNELS, true, false);
            DataLine.Info info = new DataLine.Info(TargetDataLine.class, format);
            if (!AudioSystem.isLineSupported(info)) {
                displayClientChat(Component.translatable("message.echocat.voice.mic_unavailable")
                        .withStyle(ChatFormatting.RED));
                return;
            }

            TargetDataLine line = (TargetDataLine) AudioSystem.getLine(info);
            line.open(format);
            line.start();

            this.activeMicLine = line;
            this.pcmBuffer = new ByteArrayOutputStream(32768);
            this.recordStartMs = System.currentTimeMillis();
            this.recording.set(true);

            Thread readerThread = new Thread(() -> readMicLoop(line, this.pcmBuffer), "EchoCat-Mic-Reader");
            readerThread.setDaemon(true);
            readerThread.start();
        } catch (Exception ex) {
            this.recording.set(false);
            displayClientChat(Component.translatable("message.echocat.voice.mic_unavailable")
                    .withStyle(ChatFormatting.RED));
        }
    }

    private void readMicLoop(TargetDataLine line, ByteArrayOutputStream buffer) {
        byte[] chunk = new byte[1024];
        try {
            while (this.recording.get() && line.isOpen()) {
                int read = line.read(chunk, 0, chunk.length);
                if (read > 0) {
                    synchronized (buffer) {
                        int remainingCap = MAX_PCM_BYTES - buffer.size();
                        if (remainingCap > 0) {
                            buffer.write(chunk, 0, Math.min(read, remainingCap));
                        }
                    }
                }
            }
        } catch (Exception ignored) {
            // Line closed on stopCapture
        }
    }

    private void stopCapture(boolean sendToStt) {
        if (!this.recording.compareAndSet(true, false)) {
            return;
        }
        TargetDataLine line = this.activeMicLine;
        this.activeMicLine = null;
        if (line != null) {
            try {
                line.stop();
                line.close();
            } catch (Exception ignored) {
            }
        }

        ByteArrayOutputStream buffer = this.pcmBuffer;
        this.pcmBuffer = null;
        if (!sendToStt || buffer == null) {
            return;
        }

        byte[] rawPcm;
        synchronized (buffer) {
            rawPcm = buffer.toByteArray();
        }

        if (rawPcm.length < MIN_PCM_BYTES) {
            return;
        }

        byte[] wavBytes = wrapPcmAsWav(rawPcm, (int) SAMPLE_RATE, CHANNELS, SAMPLE_SIZE_BITS);
        transcribeAudioAsync(wavBytes);
    }

    private void transcribeAudioAsync(byte[] wavBytes) {
        String endpoint = EchoConfig.CLIENT.sttEndpoint.get();
        String apiKey = resolveClientApiKey();
        String model = EchoConfig.CLIENT.sttModel.get();

        if (endpoint == null || endpoint.isBlank() || apiKey.isBlank()) {
            displayClientChat(Component.translatable("message.echocat.voice.stt_unconfigured")
                    .withStyle(ChatFormatting.YELLOW));
            return;
        }

        CompletableFuture.runAsync(() -> {
            try {
                String boundary = "----EchoCatVoiceBoundary" + UUID.randomUUID().toString().replace("-", "");
                byte[] multipartBody = buildMultipartSttBody(boundary, wavBytes,
                        (model == null || model.isBlank()) ? "whisper-1" : model.trim());

                HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(endpoint.trim()))
                        .timeout(Duration.ofSeconds(5))
                        .header("Authorization", "Bearer " + apiKey)
                        .header("Content-Type", "multipart/form-data; boundary=" + boundary)
                        .POST(HttpRequest.BodyPublishers.ofByteArray(multipartBody))
                        .build();

                HttpResponse<String> response = this.httpClient.send(
                        request,
                        HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8)
                );

                if (response.statusCode() >= 200 && response.statusCode() < 300) {
                    String transcript = parseTranscriptResponse(response.body());
                    String sanitized = ChatRepeatHandler.sanitizePlayerMessage(transcript);
                    if (!sanitized.isEmpty()) {
                        if (EchoConfig.COMMON.debugMode.get()) {
                            EchoCatMod.LOGGER.info("[EchoCat Voice Debug] STT succeeded via external API (HTTP {})",
                                    response.statusCode());
                        }
                        Minecraft.getInstance().execute(() ->
                                ModNetwork.CHANNEL.sendToServer(new VoiceTextPacket(sanitized))
                        );
                        return;
                    }
                }
                displayClientChat(Component.translatable("message.echocat.voice.stt_failed")
                        .withStyle(ChatFormatting.RED));
            } catch (Exception ex) {
                if (EchoConfig.COMMON.debugMode.get()) {
                    EchoCatMod.LOGGER.info("[EchoCat Voice Debug] STT fallback to chat-only ({})",
                            ex.getClass().getSimpleName());
                }
                displayClientChat(Component.translatable("message.echocat.voice.stt_failed")
                        .withStyle(ChatFormatting.RED));
            }
        }, this.voiceExecutor);
    }

    public static String resolveClientApiKey() {
        String clientKey = EchoConfig.CLIENT.sttApiKey.get();
        if (clientKey != null && !clientKey.isBlank()) {
            return clientKey.trim();
        }
        String commonKey = EchoConfig.COMMON.apiKey.get();
        if (commonKey != null && !commonKey.isBlank()) {
            return commonKey.trim();
        }
        return "";
    }

    private static byte[] buildMultipartSttBody(String boundary, byte[] wavBytes, String model) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream(wavBytes.length + 512);
        String crlf = "\r\n";

        // Part 1: model field
        out.write(("--" + boundary + crlf).getBytes(StandardCharsets.UTF_8));
        out.write(("Content-Disposition: form-data; name=\"model\"" + crlf + crlf).getBytes(StandardCharsets.UTF_8));
        out.write((model + crlf).getBytes(StandardCharsets.UTF_8));

        // Part 2: in-memory WAV audio bytes
        out.write(("--" + boundary + crlf).getBytes(StandardCharsets.UTF_8));
        out.write(("Content-Disposition: form-data; name=\"file\"; filename=\"speech.wav\"" + crlf).getBytes(StandardCharsets.UTF_8));
        out.write(("Content-Type: audio/wav" + crlf + crlf).getBytes(StandardCharsets.UTF_8));
        out.write(wavBytes);
        out.write(crlf.getBytes(StandardCharsets.UTF_8));

        // Closing boundary
        out.write(("--" + boundary + "--" + crlf).getBytes(StandardCharsets.UTF_8));
        return out.toByteArray();
    }

    private static String parseTranscriptResponse(String body) {
        if (body == null || body.isBlank()) {
            return "";
        }
        try {
            JsonElement el = JsonParser.parseString(body);
            if (el.isJsonObject()) {
                JsonObject obj = el.getAsJsonObject();
                if (obj.has("text") && !obj.get("text").isJsonNull()) {
                    return obj.get("text").getAsString();
                }
            }
        } catch (Exception ignored) {
            // Plain-text response fallback
        }
        return body.trim();
    }

    /**
     * Wraps raw 16-bit little-endian PCM bytes with a standard 44-byte RIFF/WAVE header in memory.
     */
    public static byte[] wrapPcmAsWav(byte[] pcmData, int sampleRate, int channels, int bitsPerSample) {
        int byteRate = sampleRate * channels * (bitsPerSample / 8);
        int blockAlign = channels * (bitsPerSample / 8);
        ByteBuffer buffer = ByteBuffer.allocate(44 + pcmData.length).order(ByteOrder.LITTLE_ENDIAN);

        buffer.put("RIFF".getBytes(StandardCharsets.US_ASCII));
        buffer.putInt(36 + pcmData.length);
        buffer.put("WAVE".getBytes(StandardCharsets.US_ASCII));
        buffer.put("fmt ".getBytes(StandardCharsets.US_ASCII));
        buffer.putInt(16); // PCM chunk size
        buffer.putShort((short) 1); // AudioFormat = 1 (PCM)
        buffer.putShort((short) channels);
        buffer.putInt(sampleRate);
        buffer.putInt(byteRate);
        buffer.putShort((short) blockAlign);
        buffer.putShort((short) bitsPerSample);
        buffer.put("data".getBytes(StandardCharsets.US_ASCII));
        buffer.putInt(pcmData.length);
        buffer.put(pcmData);
        return buffer.array();
    }

    /**
     * Renders a compact recording HUD indicator in the top-left corner while the mic is active.
     */
    public static void renderRecordingHud(ForgeGui gui, GuiGraphics guiGraphics, float partialTick, int screenWidth, int screenHeight) {
        if (!INSTANCE.isRecording()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        Font font = mc.font;
        Component label = Component.translatable("hud.echocat.recording");

        int x = 10;
        int y = 10;
        int width = font.width(label) + 18;
        int height = 14;

        // Dark translucent pill background
        guiGraphics.fill(x, y, x + width, y + height, 0xAA1A0508);
        // Pulsing red recording dot
        boolean pulseOn = (System.currentTimeMillis() / 300L) % 2L == 0L;
        int dotColor = pulseOn ? 0xFFFF2A2A : 0xFF991111;
        guiGraphics.fill(x + 4, y + 4, x + 10, y + 10, dotColor);

        guiGraphics.drawString(font, label, x + 14, y + 3, 0xFFFFD0D0, true);
    }

    private static void displayClientChat(Component message) {
        Minecraft mc = Minecraft.getInstance();
        mc.execute(() -> {
            if (mc.player != null) {
                mc.player.displayClientMessage(message, false);
            }
        });
    }
}
