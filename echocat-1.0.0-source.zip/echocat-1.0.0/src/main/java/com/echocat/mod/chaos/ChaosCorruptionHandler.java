package com.echocat.mod.chaos;

import com.echocat.mod.EchoCatMod;
import com.echocat.mod.config.EchoConfig;
import com.echocat.mod.entity.EchoEntity;
import com.echocat.mod.phase.EchoPhase;
import com.echocat.mod.phase.EchoPhaseChangeEvent;
import com.echocat.mod.registry.ModItems;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.ForgeRegistries;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Manages temporary mob corruption during Phase 3 (GLITCH) and Phase 4+ (CHAOS).
 * Hardened in Phase 5 with `performanceMode` (40-tick scan interval & reduced particles),
 * `horrorIntensity` attribute scaling, and `clearAllActive()` server-stop cleanup.
 */
public class ChaosCorruptionHandler {
    public static final double CORRUPTION_RADIUS = 24.0D;
    public static final double CORRUPTION_RADIUS_SQR = CORRUPTION_RADIUS * CORRUPTION_RADIUS;
    public static final double GLITCH_LIMITED_RADIUS = 16.0D;
    public static final double GLITCH_LIMITED_RADIUS_SQR = GLITCH_LIMITED_RADIUS * GLITCH_LIMITED_RADIUS;
    public static final int GLITCH_MAX_CORRUPTED_MOBS = 2;

    public static final String NBT_CORRUPTED = "EchoCatCorrupted";
    public static final String NBT_START_TIME = "EchoCatCorruptStartMs";
    public static final String NBT_ECHO_UUID = "EchoCatSourceEchoUUID";
    public static final String NBT_OWNER_UUID = "EchoCatSourceOwnerUUID";

    private static final UUID CORRUPTED_ATTACK_MODIFIER_UUID = UUID.fromString("e4c0ca70-4444-4a05-9b11-000000000001");
    private static final UUID CORRUPTED_SPEED_MODIFIER_UUID = UUID.fromString("e4c0ca70-4444-4a05-9b11-000000000002");

    private static final DustParticleOptions RED_EYE_DUST =
            new DustParticleOptions(new Vector3f(1.0F, 0.08F, 0.12F), 0.85F);

    public record ActiveCorruptionRecord(
            Mob mob,
            UUID sourceEchoUuid,
            UUID ownerUuid,
            long startTimestampMs,
            boolean wasGlowingBefore,
            Goal meleeGoal,
            Goal nearestMobGoal,
            Goal aggroPlayerGoal
    ) {}

    private static final Map<UUID, ActiveCorruptionRecord> ACTIVE_CORRUPTED_MOBS = new ConcurrentHashMap<>();

    public static boolean isCorrupted(Mob mob) {
        if (mob == null) {
            return false;
        }
        return ACTIVE_CORRUPTED_MOBS.containsKey(mob.getUUID())
                || mob.getPersistentData().getBoolean(NBT_CORRUPTED);
    }

    public static UUID getCorruptionOwnerUuid(Mob mob) {
        if (mob == null) {
            return null;
        }
        ActiveCorruptionRecord rec = ACTIVE_CORRUPTED_MOBS.get(mob.getUUID());
        if (rec != null) {
            return rec.ownerUuid();
        }
        CompoundTag data = mob.getPersistentData();
        return data.hasUUID(NBT_OWNER_UUID) ? data.getUUID(NBT_OWNER_UUID) : null;
    }

    public static boolean isExemptFromCorruption(Mob mob) {
        if (mob == null || !mob.isAlive()) {
            return true;
        }
        if (mob instanceof EchoEntity
                || mob instanceof EnderDragon
                || mob instanceof WitherBoss
                || mob instanceof AbstractVillager
                || mob instanceof IronGolem) {
            return true;
        }
        if (!mob.canChangeDimensions() || mob.hasCustomName()) {
            return true;
        }
        if (mob instanceof TamableAnimal tamable && tamable.isTame()) {
            return true;
        }

        ResourceLocation entityKey = ForgeRegistries.ENTITY_TYPES.getKey(mob.getType());
        if (entityKey != null) {
            String idString = entityKey.toString();
            List<? extends String> blacklist = EchoConfig.COMMON.corruptionBlacklist.get();
            if (blacklist != null && blacklist.contains(idString)) {
                return true;
            }
        }
        return false;
    }

    @SubscribeEvent
    public void onEntityJoinLevel(final EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide()) {
            return;
        }
        if (event.getEntity() instanceof Mob mob) {
            CompoundTag persistent = mob.getPersistentData();
            if (persistent.getBoolean(NBT_CORRUPTED)) {
                uncorruptMob(mob);
            }
        }
    }

    @SubscribeEvent
    public void onPhaseChange(final EchoPhaseChangeEvent event) {
        if (event.getNewPhase().getId() < EchoPhase.GLITCH.getId()) {
            UUID playerUuid = event.getEntity().getUUID();
            restoreAllForOwner(playerUuid);
        }
    }

    @SubscribeEvent
    public void onLivingDrops(final LivingDropsEvent event) {
        if (!(event.getEntity() instanceof Mob mob)) {
            return;
        }
        if (isCorrupted(mob)) {
            double chance = EchoConfig.COMMON.corruptedCoreDropChance.get();
            if (ThreadLocalRandom.current().nextDouble() <= chance) {
                ItemEntity drop = new ItemEntity(
                        mob.level(),
                        mob.getX(),
                        mob.getY() + 0.5D,
                        mob.getZ(),
                        new ItemStack(ModItems.CORRUPTED_CORE.get())
                );
                event.getDrops().add(drop);
            }
            uncorruptMob(mob);
        }
    }

    @SubscribeEvent
    public void onLivingHurt(final LivingHurtEvent event) {
        if (!(event.getEntity() instanceof Player)) {
            return;
        }
        Entity attacker = event.getSource().getEntity();
        if (attacker instanceof Mob mob && isCorrupted(mob)) {
            if (!EchoConfig.COMMON.allowMobDamageToPlayers.get()) {
                event.setCanceled(true);
                return;
            }
            int intensity = Math.max(1, Math.min(3, EchoConfig.COMMON.horrorIntensity.get()));
            float intensityFactor = 0.70F + (0.15F * intensity);
            float multiplier = EchoConfig.COMMON.corruptedDamageMultiplier.get().floatValue() * intensityFactor;
            event.setAmount(event.getAmount() * multiplier);
        }
    }

    @SubscribeEvent
    public void onServerTick(final TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        MinecraftServer server = event.getServer();
        if (server == null) {
            return;
        }
        int tick = server.getTickCount();
        boolean perfMode = EchoConfig.COMMON.performanceMode.get();

        int particleInterval = perfMode ? 20 : 10;
        if (tick % particleInterval == 0 && !ACTIVE_CORRUPTED_MOBS.isEmpty()) {
            spawnCorruptedMobParticles(perfMode);
        }

        int scanInterval = perfMode ? 40 : 20;
        if (tick % scanInterval != 0) {
            return;
        }

        validateExistingCorruptedMobs(server);
        scanAndCorruptNearbyMobs(server);
    }

    private static void validateExistingCorruptedMobs(MinecraftServer server) {
        long now = System.currentTimeMillis();
        long maxDurationMs = EchoConfig.COMMON.maxCorruptionDurationSeconds.get() * 1000L;

        Iterator<Map.Entry<UUID, ActiveCorruptionRecord>> it = ACTIVE_CORRUPTED_MOBS.entrySet().iterator();
        while (it.hasNext()) {
            ActiveCorruptionRecord rec = it.next().getValue();
            Mob mob = rec.mob();

            if (mob == null || !mob.isAlive() || mob.isRemoved() || !(mob.level() instanceof ServerLevel level)) {
                if (mob != null) {
                    stripCorruptionDataAndModifiers(mob, rec);
                }
                it.remove();
                continue;
            }

            if (level.getDifficulty() == Difficulty.PEACEFUL || (now - rec.startTimestampMs()) > maxDurationMs) {
                stripCorruptionDataAndModifiers(mob, rec);
                it.remove();
                continue;
            }

            Entity sourceEntity = level.getEntity(rec.sourceEchoUuid());
            if (!(sourceEntity instanceof EchoEntity echo)
                    || !echo.isAlive()
                    || echo.isPurified()
                    || echo.getPhase().getId() < EchoPhase.GLITCH.getId()
                    || mob.distanceToSqr(echo) > CORRUPTION_RADIUS_SQR) {
                stripCorruptionDataAndModifiers(mob, rec);
                it.remove();
            }
        }
    }

    private static void scanAndCorruptNearbyMobs(MinecraftServer server) {
        int chaosMaxPerEcho = EchoConfig.COMMON.maxAffectedMobs.get();

        for (ServerLevel level : server.getAllLevels()) {
            if (level.getDifficulty() == Difficulty.PEACEFUL) {
                continue;
            }

            for (Entity entity : level.getAllEntities()) {
                if (!(entity instanceof EchoEntity echo) || !echo.isAlive() || echo.isPurified()) {
                    continue;
                }
                EchoPhase phase = echo.getPhase();
                if (phase.getId() < EchoPhase.GLITCH.getId()) {
                    continue;
                }

                boolean isGlitchSeed = (phase == EchoPhase.GLITCH);
                int maxCap = isGlitchSeed ? GLITCH_MAX_CORRUPTED_MOBS : chaosMaxPerEcho;
                double radius = isGlitchSeed ? GLITCH_LIMITED_RADIUS : CORRUPTION_RADIUS;
                double radiusSqr = isGlitchSeed ? GLITCH_LIMITED_RADIUS_SQR : CORRUPTION_RADIUS_SQR;

                UUID echoUuid = echo.getUUID();
                UUID ownerUuid = echo.getOwnerUUID();

                int currentCount = countCorruptedByEcho(echoUuid);
                if (currentCount >= maxCap) {
                    continue;
                }

                AABB searchBox = echo.getBoundingBox().inflate(radius);
                List<Mob> nearbyMobs = level.getEntitiesOfClass(
                        Mob.class,
                        searchBox,
                        mob -> !isCorrupted(mob)
                                && !isExemptFromCorruption(mob)
                                && mob.distanceToSqr(echo) <= radiusSqr
                );

                for (Mob candidate : nearbyMobs) {
                    if (currentCount >= maxCap) {
                        break;
                    }
                    corruptMob(candidate, echoUuid, ownerUuid);
                    currentCount++;
                }
            }
        }
    }

    public static void corruptMob(Mob mob, UUID echoUuid, UUID ownerUuid) {
        if (mob == null || isCorrupted(mob) || isExemptFromCorruption(mob)) {
            return;
        }

        long now = System.currentTimeMillis();
        CompoundTag data = mob.getPersistentData();
        data.putBoolean(NBT_CORRUPTED, true);
        data.putLong(NBT_START_TIME, now);
        data.putUUID(NBT_ECHO_UUID, echoUuid);
        if (ownerUuid != null) {
            data.putUUID(NBT_OWNER_UUID, ownerUuid);
        }

        boolean wasGlowing = mob.isGlowingTag();
        mob.setGlowingTag(true);

        int intensity = Math.max(1, Math.min(3, EchoConfig.COMMON.horrorIntensity.get()));
        double attackBoost = 1.0D + (0.5D * intensity);
        double speedBoost = 0.06D + (0.03D * intensity);

        AttributeInstance attackAttr = mob.getAttribute(Attributes.ATTACK_DAMAGE);
        if (attackAttr != null && attackAttr.getModifier(CORRUPTED_ATTACK_MODIFIER_UUID) == null) {
            attackAttr.addTransientModifier(new AttributeModifier(
                    CORRUPTED_ATTACK_MODIFIER_UUID,
                    "EchoCat chaos corruption attack boost",
                    attackBoost,
                    AttributeModifier.Operation.ADDITION
            ));
        }

        AttributeInstance speedAttr = mob.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speedAttr != null && speedAttr.getModifier(CORRUPTED_SPEED_MODIFIER_UUID) == null) {
            speedAttr.addTransientModifier(new AttributeModifier(
                    CORRUPTED_SPEED_MODIFIER_UUID,
                    "EchoCat chaos corruption speed boost",
                    speedBoost,
                    AttributeModifier.Operation.MULTIPLY_BASE
            ));
        }

        Goal meleeGoal = new CorruptedMeleeAttackGoal(mob, 1.15D);
        Goal nearestMobGoal = new CorruptedAttackNearestMobGoal(mob);
        Goal aggroPlayerGoal = new CorruptedAggroPlayerGoal(mob);

        mob.goalSelector.addGoal(1, meleeGoal);
        mob.targetSelector.addGoal(1, nearestMobGoal);
        mob.targetSelector.addGoal(2, aggroPlayerGoal);

        ACTIVE_CORRUPTED_MOBS.put(mob.getUUID(), new ActiveCorruptionRecord(
                mob,
                echoUuid,
                ownerUuid,
                now,
                wasGlowing,
                meleeGoal,
                nearestMobGoal,
                aggroPlayerGoal
        ));
    }

    public static void uncorruptMob(Mob mob) {
        if (mob == null) {
            return;
        }
        ActiveCorruptionRecord rec = ACTIVE_CORRUPTED_MOBS.remove(mob.getUUID());
        stripCorruptionDataAndModifiers(mob, rec);
    }

    public static void restoreAllForOwner(UUID ownerUuid) {
        if (ownerUuid == null) {
            return;
        }
        Iterator<Map.Entry<UUID, ActiveCorruptionRecord>> it = ACTIVE_CORRUPTED_MOBS.entrySet().iterator();
        while (it.hasNext()) {
            ActiveCorruptionRecord rec = it.next().getValue();
            if (ownerUuid.equals(rec.ownerUuid())) {
                stripCorruptionDataAndModifiers(rec.mob(), rec);
                it.remove();
            }
        }
    }

    /**
     * Restores all corrupted mobs and clears the static map on server shutdown so no Entity references leak.
     */
    public static void clearAllActive() {
        Iterator<Map.Entry<UUID, ActiveCorruptionRecord>> it = ACTIVE_CORRUPTED_MOBS.entrySet().iterator();
        while (it.hasNext()) {
            ActiveCorruptionRecord rec = it.next().getValue();
            if (rec.mob() != null) {
                stripCorruptionDataAndModifiers(rec.mob(), rec);
            }
            it.remove();
        }
    }

    private static void stripCorruptionDataAndModifiers(Mob mob, ActiveCorruptionRecord rec) {
        CompoundTag data = mob.getPersistentData();
        data.remove(NBT_CORRUPTED);
        data.remove(NBT_START_TIME);
        data.remove(NBT_ECHO_UUID);
        data.remove(NBT_OWNER_UUID);

        if (rec != null) {
            mob.goalSelector.removeGoal(rec.meleeGoal());
            mob.targetSelector.removeGoal(rec.nearestMobGoal());
            mob.targetSelector.removeGoal(rec.aggroPlayerGoal());
            mob.setGlowingTag(rec.wasGlowingBefore());
        } else {
            mob.setGlowingTag(false);
        }

        mob.setTarget(null);

        AttributeInstance attackAttr = mob.getAttribute(Attributes.ATTACK_DAMAGE);
        if (attackAttr != null) {
            attackAttr.removeModifier(CORRUPTED_ATTACK_MODIFIER_UUID);
        }

        AttributeInstance speedAttr = mob.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speedAttr != null) {
            speedAttr.removeModifier(CORRUPTED_SPEED_MODIFIER_UUID);
        }
    }

    private static void spawnCorruptedMobParticles(boolean perfMode) {
        int count = perfMode ? 1 : 2;
        for (ActiveCorruptionRecord rec : ACTIVE_CORRUPTED_MOBS.values()) {
            Mob mob = rec.mob();
            if (mob != null && mob.isAlive() && mob.level() instanceof ServerLevel serverLevel) {
                double x = mob.getX();
                double y = mob.getY() + mob.getBbHeight() * 0.75D;
                double z = mob.getZ();
                serverLevel.sendParticles(ParticleTypes.LARGE_SMOKE, x, y, z, count, 0.25D, 0.25D, 0.25D, 0.01D);
                serverLevel.sendParticles(RED_EYE_DUST, x, mob.getEyeY(), z, count, 0.12D, 0.05D, 0.12D, 0.0D);
            }
        }
    }

    public static int countCorruptedByEcho(UUID echoUuid) {
        int count = 0;
        for (ActiveCorruptionRecord rec : ACTIVE_CORRUPTED_MOBS.values()) {
            if (echoUuid.equals(rec.sourceEchoUuid()) && rec.mob() != null && rec.mob().isAlive()) {
                count++;
            }
        }
        return count;
    }

    public static List<Mob> getCorruptedMobsForOwner(UUID ownerUuid) {
        List<Mob> list = new ArrayList<>();
        Set<UUID> seen = new HashSet<>();
        for (ActiveCorruptionRecord rec : ACTIVE_CORRUPTED_MOBS.values()) {
            Mob mob = rec.mob();
            if (mob != null && mob.isAlive() && seen.add(mob.getUUID())) {
                if (ownerUuid == null || ownerUuid.equals(rec.ownerUuid())) {
                    list.add(mob);
                }
            }
        }
        return list;
    }
}
