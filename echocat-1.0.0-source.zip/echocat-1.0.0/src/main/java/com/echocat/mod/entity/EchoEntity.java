package com.echocat.mod.entity;

import com.echocat.mod.ai.CreepyContext;
import com.echocat.mod.ai.HttpAIService;
import com.echocat.mod.config.EchoConfig;
import com.echocat.mod.network.EchoSpeechBubblePacket;
import com.echocat.mod.network.JumpscarePacket;
import com.echocat.mod.network.ModNetwork;
import com.echocat.mod.phase.EchoPhase;
import com.echocat.mod.phase.PhaseManager;
import com.echocat.mod.registry.ModItems;
import com.echocat.mod.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.Difficulty;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.FollowOwnerGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.SitWhenOrderedToGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Echo: The Talking Cat entity (v1.0.0 Release).
 * Includes full boss-bar lifecycle cleanup on `remove()` / `die()`, NBT `EchoDataVersion = 1`,
 * `performanceMode` particle throttling, `horrorIntensity` scaling, and `/echo calm` support.
 */
public class EchoEntity extends TamableAnimal implements GeoEntity {
    public static final int CURRENT_ENTITY_DATA_VERSION = 1;

    private static final EntityDataAccessor<Integer> DATA_PHASE_ID =
            SynchedEntityData.defineId(EchoEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> DATA_TALKING =
            SynchedEntityData.defineId(EchoEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Float> DATA_RED_PROGRESS =
            SynchedEntityData.defineId(EchoEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Integer> DATA_BOSS_ANIM_STATE =
            SynchedEntityData.defineId(EchoEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> DATA_PURIFIED =
            SynchedEntityData.defineId(EchoEntity.class, EntityDataSerializers.BOOLEAN);

    public static final int ANIM_STATE_NORMAL = 0;
    public static final int ANIM_STATE_SWIPE = 1;
    public static final int ANIM_STATE_BITE = 2;
    public static final int ANIM_STATE_POUNCE = 3;
    public static final int ANIM_STATE_TELEPORT_OUT = 4;
    public static final int ANIM_STATE_TELEPORT_IN = 5;
    public static final int ANIM_STATE_OVERLOAD_TELEGRAPH = 6;
    public static final int ANIM_STATE_STUNNED = 7;
    public static final int ANIM_STATE_DEATH = 8;
    public static final int ANIM_STATE_JUMPSCARE = 9;

    private static final RawAnimation CUTE_IDLE = RawAnimation.begin().thenLoop("animation.echo.idle");
    private static final RawAnimation CUTE_WALK = RawAnimation.begin().thenLoop("animation.echo.walk");
    private static final RawAnimation CUTE_SIT = RawAnimation.begin().thenLoop("animation.echo.sit");
    private static final RawAnimation CUTE_TALK = RawAnimation.begin().thenLoop("animation.echo.talk");

    private static final RawAnimation HORROR_IDLE = RawAnimation.begin().thenLoop("animation.echo_horror.horror_idle");
    private static final RawAnimation HORROR_WALK = RawAnimation.begin().thenLoop("animation.echo_horror.horror_walk");
    private static final RawAnimation HORROR_RUN = RawAnimation.begin().thenLoop("animation.echo_horror.horror_run");
    private static final RawAnimation HORROR_SWIPE = RawAnimation.begin().thenPlay("animation.echo_horror.attack_swipe");
    private static final RawAnimation HORROR_BITE = RawAnimation.begin().thenPlay("animation.echo_horror.attack_bite");
    private static final RawAnimation HORROR_POUNCE = RawAnimation.begin().thenPlay("animation.echo_horror.attack_pounce");
    private static final RawAnimation HORROR_TELEPORT_OUT = RawAnimation.begin().thenPlay("animation.echo_horror.teleport_out");
    private static final RawAnimation HORROR_TELEPORT_IN = RawAnimation.begin().thenPlay("animation.echo_horror.teleport_in");
    private static final RawAnimation HORROR_OVERLOAD = RawAnimation.begin().thenLoop("animation.echo_horror.overload_telegraph");
    private static final RawAnimation HORROR_STUNNED = RawAnimation.begin().thenLoop("animation.echo_horror.stunned");
    private static final RawAnimation HORROR_DEATH = RawAnimation.begin().thenPlay("animation.echo_horror.death");
    private static final RawAnimation HORROR_JUMPSCARE = RawAnimation.begin().thenPlay("animation.echo_horror.jumpscare_pose");

    private static final String TAG_DATA_VERSION = "EchoDataVersion";
    private static final String TAG_ECHO_PHASE = "EchoPhase";
    private static final String TAG_ECHO_SITTING = "EchoSitting";
    private static final String TAG_RED_PROGRESS = "EchoRedProgress";
    private static final String TAG_PURIFIED = "EchoPurified";
    private static final String TAG_ATTACK_COUNTER = "EchoAttackCounter";

    private final AnimatableInstanceCache geoCache = GeckoLibUtil.createInstanceCache(this);
    private final ServerBossEvent bossEvent = new ServerBossEvent(
            Component.translatable("entity.echocat.echo_boss").withStyle(ChatFormatting.RED),
            BossEvent.BossBarColor.RED,
            BossEvent.BossBarOverlay.NOTCHED_10
    );

    private int talkingTicks = 0;
    private int nextStaticBurstTick = 600;
    private int watcherTeleportCooldown = 0;
    private int watcherWhisperTimer = 400;

    private boolean bossConfigured = false;
    private boolean jumpscareTriggered = false;
    private int attackCounter = 0;
    private int bossActionCooldown = 40;
    private int overloadTelegraphTicks = 0;
    private int stunnedTicks = 0;
    private int actionAnimResetTicks = 0;
    private int defeatTicks = 0;
    private int peacefulNoticeCooldown = 0;

    private String speechBubbleText = "";
    private int speechBubbleTicksRemaining = 0;
    private int speechBubbleMaxTicks = 80;
    private boolean speechBubbleCreepy = false;

    public EchoEntity(EntityType<? extends TamableAnimal> entityType, Level level) {
        super(entityType, level);
        this.setTame(false);
        this.bossEvent.setVisible(false);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.30D)
                .add(Attributes.FOLLOW_RANGE, 40.0D)
                .add(Attributes.ATTACK_DAMAGE, 2.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new FloatGoal(this));
        this.goalSelector.addGoal(2, new SitWhenOrderedToGoal(this));
        this.goalSelector.addGoal(3, new FollowOwnerGoal(this, 1.1D, 5.0F, 2.0F, false) {
            @Override
            public boolean canUse() {
                if (EchoEntity.this.getPhase().getId() >= EchoPhase.RED.getId() && !EchoEntity.this.isPurified()) {
                    return false;
                }
                return super.canUse();
            }

            @Override
            public boolean canContinueToUse() {
                if (EchoEntity.this.getPhase().getId() >= EchoPhase.RED.getId() && !EchoEntity.this.isPurified()) {
                    return false;
                }
                return super.canContinueToUse();
            }
        });
        this.goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(this, 0.9D) {
            @Override
            public boolean canUse() {
                if (EchoEntity.this.getPhase() == EchoPhase.HORROR_FINAL && !EchoEntity.this.isPurified()) {
                    return false;
                }
                return super.canUse();
            }
        });
        this.goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 24.0F));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_PHASE_ID, EchoPhase.CUTE.getId());
        this.entityData.define(DATA_TALKING, false);
        this.entityData.define(DATA_RED_PROGRESS, 0.0F);
        this.entityData.define(DATA_BOSS_ANIM_STATE, ANIM_STATE_NORMAL);
        this.entityData.define(DATA_PURIFIED, false);
    }

    public boolean isPurified() {
        return this.entityData.get(DATA_PURIFIED);
    }

    public void setPurified(boolean purified) {
        this.entityData.set(DATA_PURIFIED, purified);
        if (purified) {
            calmToCuteState();
        }
    }

    /**
     * Immediately calms Echo back to a harmless Phase 1 (CUTE) state, stopping all boss bars,
     * telegraphs, stuns, and red overlays. Invoked by `/echo calm` or the `K` panic keybind.
     */
    public void calmToCuteState() {
        this.entityData.set(DATA_PHASE_ID, EchoPhase.CUTE.getId());
        this.entityData.set(DATA_RED_PROGRESS, 0.0F);
        this.entityData.set(DATA_BOSS_ANIM_STATE, ANIM_STATE_NORMAL);
        this.overloadTelegraphTicks = 0;
        this.stunnedTicks = 0;
        this.defeatTicks = 0;
        this.attackCounter = 0;
        configureBossStats(false);
        this.bossEvent.setVisible(false);
        this.getNavigation().stop();
    }

    public EchoPhase getPhase() {
        if (this.isPurified()) {
            return EchoPhase.CUTE;
        }
        return EchoPhase.byId(this.entityData.get(DATA_PHASE_ID));
    }

    public void setPhase(EchoPhase phase) {
        if (this.isPurified()) {
            this.entityData.set(DATA_PHASE_ID, EchoPhase.CUTE.getId());
            return;
        }
        EchoPhase old = this.getPhase();
        this.entityData.set(DATA_PHASE_ID, phase.getId());
        if (phase == EchoPhase.HORROR_FINAL) {
            this.setRedProgress(1.0F);
            configureBossStats(true);
        } else {
            if (old == EchoPhase.HORROR_FINAL) {
                configureBossStats(false);
            }
            if (phase.getId() < EchoPhase.RED.getId()) {
                this.setRedProgress(0.0F);
            }
        }
    }

    public int getPhaseId() {
        return this.getPhase().getId();
    }

    public void setPhaseId(int id) {
        this.setPhase(EchoPhase.byId(id));
    }

    public float getRedProgress() {
        return Mth.clamp(this.entityData.get(DATA_RED_PROGRESS), 0.0F, 1.0F);
    }

    public void setRedProgress(float progress) {
        this.entityData.set(DATA_RED_PROGRESS, Mth.clamp(progress, 0.0F, 1.0F));
    }

    public int getBossAnimState() {
        return this.entityData.get(DATA_BOSS_ANIM_STATE);
    }

    public void setBossAnimState(int state, int resetTicks) {
        this.entityData.set(DATA_BOSS_ANIM_STATE, state);
        this.actionAnimResetTicks = resetTicks;
    }

    public boolean isOverloadCharging() {
        return this.overloadTelegraphTicks > 0 && this.getBossAnimState() == ANIM_STATE_OVERLOAD_TELEGRAPH;
    }

    public boolean isBossStunned() {
        return this.stunnedTicks > 0;
    }

    public boolean shouldRenderHorrorModel(boolean photosensitive) {
        if (this.isPurified()) {
            return false;
        }
        EchoPhase phase = this.getPhase();
        if (phase == EchoPhase.HORROR_FINAL) {
            return true;
        }
        if (phase != EchoPhase.RED) {
            return false;
        }
        float rp = this.getRedProgress();
        if (rp >= 0.90F) {
            return true;
        }
        if (rp < 0.50F) {
            return false;
        }
        float ratio = (rp - 0.50F) / 0.40F;
        long bucket = photosensitive
                ? (System.currentTimeMillis() / 500L)
                : (System.currentTimeMillis() / 120L);
        long hash = Math.floorMod((bucket * 2654435761L) ^ this.getId(), 100);
        return hash < (int) (ratio * 100.0F);
    }

    public void triggerTalkAnimation(int durationTicks) {
        this.talkingTicks = Math.max(this.talkingTicks, durationTicks);
        this.entityData.set(DATA_TALKING, this.talkingTicks > 0);
    }

    public boolean isTalking() {
        return this.entityData.get(DATA_TALKING);
    }

    public void setSpeechBubble(String text, int durationTicks, boolean creepy) {
        this.speechBubbleText = text == null ? "" : text;
        this.speechBubbleMaxTicks = Math.max(1, durationTicks);
        this.speechBubbleTicksRemaining = this.speechBubbleMaxTicks;
        this.speechBubbleCreepy = creepy;
    }

    public String getSpeechBubbleText() {
        return this.speechBubbleText;
    }

    public int getSpeechBubbleTicksRemaining() {
        return this.speechBubbleTicksRemaining;
    }

    public int getSpeechBubbleMaxTicks() {
        return this.speechBubbleMaxTicks;
    }

    public boolean isSpeechBubbleCreepy() {
        return this.speechBubbleCreepy;
    }

    private void configureBossStats(boolean enableBoss) {
        if (this.level().isClientSide) {
            return;
        }
        AttributeInstance maxHealthAttr = this.getAttribute(Attributes.MAX_HEALTH);
        AttributeInstance attackAttr = this.getAttribute(Attributes.ATTACK_DAMAGE);

        if (enableBoss && !this.isPurified()) {
            double targetHp = EchoConfig.COMMON.bossHealth.get();
            double targetDmg = EchoConfig.COMMON.bossDamage.get();
            if (maxHealthAttr != null) {
                maxHealthAttr.setBaseValue(targetHp);
            }
            if (attackAttr != null) {
                attackAttr.setBaseValue(targetDmg);
            }
            this.setHealth((float) targetHp);
            this.setOrderedToSit(false);
            this.setInSittingPose(false);
            this.bossConfigured = true;
            this.jumpscareTriggered = false;
            this.attackCounter = 0;
            this.overloadTelegraphTicks = 0;
            this.stunnedTicks = 0;
            this.defeatTicks = 0;
            this.bossEvent.setProgress(1.0F);
            this.bossEvent.setVisible(true);
        } else {
            if (maxHealthAttr != null) {
                maxHealthAttr.setBaseValue(20.0D);
            }
            if (attackAttr != null) {
                attackAttr.setBaseValue(2.0D);
            }
            this.setHealth(20.0F);
            this.bossConfigured = false;
            this.overloadTelegraphTicks = 0;
            this.stunnedTicks = 0;
            this.defeatTicks = 0;
            this.setBossAnimState(ANIM_STATE_NORMAL, 0);
            this.bossEvent.setVisible(false);
        }
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        this.bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        this.bossEvent.removePlayer(player);
    }

    @Override
    public void remove(RemovalReason reason) {
        this.bossEvent.setVisible(false);
        this.bossEvent.removeAllPlayers();
        super.remove(reason);
    }

    @Override
    public void die(DamageSource cause) {
        this.bossEvent.setVisible(false);
        this.bossEvent.removeAllPlayers();
        super.die(cause);
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide) {
            serverTickLogic();
        } else {
            if (this.speechBubbleTicksRemaining > 0) {
                this.speechBubbleTicksRemaining--;
                if (this.speechBubbleTicksRemaining == 0) {
                    this.speechBubbleText = "";
                }
            }
        }
    }

    private void serverTickLogic() {
        if (this.talkingTicks > 0) {
            this.talkingTicks--;
            if (this.talkingTicks == 0) {
                this.entityData.set(DATA_TALKING, false);
            }
        }

        if (this.actionAnimResetTicks > 0) {
            this.actionAnimResetTicks--;
            if (this.actionAnimResetTicks == 0
                    && this.overloadTelegraphTicks <= 0
                    && this.stunnedTicks <= 0
                    && this.defeatTicks <= 0) {
                this.entityData.set(DATA_BOSS_ANIM_STATE, ANIM_STATE_NORMAL);
            }
        }

        if (this.isPurified()) {
            this.bossEvent.setVisible(false);
            return;
        }

        if (this.tickCount % 40 == 0 && this.getOwner() instanceof ServerPlayer owner) {
            EchoPhase ownerPhase = PhaseManager.getPhase(owner);
            if (this.getPhase() != ownerPhase) {
                this.setPhase(ownerPhase);
            }
        }

        EchoPhase currentPhase = this.getPhase();
        int intensity = Math.max(1, Math.min(3, EchoConfig.COMMON.horrorIntensity.get()));
        float volumeScale = 0.65F + (0.175F * intensity);

        if (currentPhase.getId() >= EchoPhase.GLITCH.getId() && currentPhase != EchoPhase.HORROR_FINAL) {
            if (this.tickCount >= this.nextStaticBurstTick) {
                this.playSound(ModSounds.ECHO_STATIC_BURST.get(), 0.75F * volumeScale, 0.85F + ThreadLocalRandom.current().nextFloat() * 0.30F);
                int minTicks = Math.max(260, 520 - (intensity * 60));
                int maxTicks = Math.max(minTicks + 120, 1320 - (intensity * 80));
                this.nextStaticBurstTick = this.tickCount + ThreadLocalRandom.current().nextInt(minTicks, maxTicks + 1);
            }
        }

        if (currentPhase == EchoPhase.CHAOS && this.tickCount % 50 == 0) {
            this.playSound(ModSounds.ECHO_CHAOS_HUM.get(), 0.45F * volumeScale, 0.90F);
        }

        if (currentPhase == EchoPhase.RED) {
            tickRedWatcherPhase(intensity, volumeScale);
        }

        if (currentPhase == EchoPhase.HORROR_FINAL) {
            tickHorrorFinalBossPhase(intensity, volumeScale);
        } else if (this.bossEvent.isVisible()) {
            this.bossEvent.setVisible(false);
        }
    }

    private void tickRedWatcherPhase(int intensity, float volumeScale) {
        double durationMinutes = Math.max(0.5D, EchoConfig.COMMON.redPhaseDurationMinutes.get());
        double speedMult = Math.max(0.1D, EchoConfig.COMMON.phaseSpeedMultiplier.get());
        float totalTicks = (float) (durationMinutes * 60.0D * 20.0D / speedMult);
        float step = 1.0F / Math.max(200.0F, totalTicks);
        this.setRedProgress(this.getRedProgress() + step);

        if (this.watcherTeleportCooldown > 0) {
            this.watcherTeleportCooldown--;
        }

        if (this.tickCount % 70 == 0) {
            this.playSound(ModSounds.ECHO_RED_BREATH.get(), 0.55F * volumeScale, 0.95F);
        }

        if (!(this.getOwner() instanceof ServerPlayer owner) || !owner.isAlive() || owner.level() != this.level()) {
            return;
        }

        this.getLookControl().setLookAt(owner, 35.0F, 35.0F);
        double dist = this.distanceTo(owner);

        if (dist < 11.5D) {
            Vec3 away = this.position().subtract(owner.position()).normalize();
            Vec3 targetPos = owner.position().add(away.scale(15.0D));
            this.getNavigation().moveTo(targetPos.x, targetPos.y, targetPos.z, 1.15D);
        } else if (dist > 22.0D) {
            this.getNavigation().moveTo(owner, 1.10D);
        } else {
            this.getNavigation().stop();
        }

        // Throttle Watcher line-of-sight check to every 5 ticks for zero TPS overhead
        if (this.tickCount % 5 == 0 && this.watcherTeleportCooldown <= 0 && isPlayerLookingAtEcho(owner)) {
            this.watcherTeleportCooldown = 90;
            this.setBossAnimState(ANIM_STATE_TELEPORT_OUT, 14);
            if (this.level() instanceof ServerLevel sl) {
                int pCount = EchoConfig.COMMON.performanceMode.get() ? 6 : 16;
                sl.sendParticles(ParticleTypes.LARGE_SMOKE, this.getX(), this.getY() + 1.0D, this.getZ(), pCount, 0.3D, 0.5D, 0.3D, 0.03D);
            }
            this.playSound(ModSounds.ECHO_STATIC_BURST.get(), 0.85F * volumeScale, 0.75F);
            teleportSafelyAroundPlayer(owner, 14.0D, 20.0D, true);
            this.setBossAnimState(ANIM_STATE_TELEPORT_IN, 12);
        }

        if (--this.watcherWhisperTimer <= 0) {
            // Whisper frequency scales with horrorIntensity (level 1 = less frequent, level 3 = more frequent)
            int baseInterval = 520 - (intensity * 90);
            this.watcherWhisperTimer = baseInterval + ThreadLocalRandom.current().nextInt(240);
            CreepyContext ctx = CreepyContext.fromPlayer(owner, "...", EchoPhase.RED);
            HttpAIService.INSTANCE.generateForPlayer(owner.server, owner.getUUID(), ctx)
                    .thenAccept(line -> {
                        if (line != null && !line.isBlank()) {
                            owner.server.execute(() -> {
                                if (this.isAlive() && owner.isAlive()) {
                                    owner.sendSystemMessage(
                                            Component.translatable("chat.echocat.echo_format", line)
                                                    .withStyle(ChatFormatting.DARK_RED, ChatFormatting.ITALIC)
                                    );
                                    ModNetwork.CHANNEL.send(
                                            PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> this),
                                            new EchoSpeechBubblePacket(this.getId(), line, 80, true)
                                    );
                                }
                            });
                        }
                    });
        }
    }

    private void tickHorrorFinalBossPhase(int intensity, float volumeScale) {
        if (!this.bossConfigured) {
            configureBossStats(true);
        }

        boolean perfMode = EchoConfig.COMMON.performanceMode.get();

        if (this.defeatTicks > 0) {
            this.defeatTicks--;
            this.getNavigation().stop();
            if (this.level() instanceof ServerLevel sl && this.defeatTicks % (perfMode ? 8 : 4) == 0) {
                int pCount = perfMode ? 3 : 6;
                sl.sendParticles(ParticleTypes.END_ROD, this.getX(), this.getY() + 1.0D, this.getZ(), pCount, 0.4D, 0.6D, 0.4D, 0.04D);
                sl.sendParticles(ParticleTypes.LARGE_SMOKE, this.getX(), this.getY() + 0.8D, this.getZ(), pCount, 0.4D, 0.5D, 0.4D, 0.02D);
            }
            if (this.defeatTicks == 0) {
                completeBossDefeatSequence();
            }
            return;
        }

        this.bossEvent.setProgress(Mth.clamp(this.getHealth() / this.getMaxHealth(), 0.0F, 1.0F));

        if (this.level().getDifficulty() == Difficulty.PEACEFUL) {
            this.bossEvent.setVisible(false);
            if (this.peacefulNoticeCooldown <= 0 && this.getOwner() instanceof ServerPlayer owner) {
                this.peacefulNoticeCooldown = 400;
                owner.displayClientMessage(
                        Component.translatable("message.echocat.boss.peaceful").withStyle(ChatFormatting.YELLOW),
                        true
                );
            } else if (this.peacefulNoticeCooldown > 0) {
                this.peacefulNoticeCooldown--;
            }
            tickRedWatcherPhase(intensity, volumeScale);
            return;
        }

        if (!(this.getOwner() instanceof ServerPlayer owner)
                || !owner.isAlive()
                || owner.isCreative()
                || owner.isSpectator()
                || owner.level() != this.level()
                || this.distanceToSqr(owner) > (64.0D * 64.0D)) {
            resetBossToCalmState();
            return;
        }

        this.bossEvent.setVisible(true);

        if (!this.jumpscareTriggered && this.tickCount % 5 == 0 && this.hasLineOfSight(owner) && this.distanceTo(owner) <= 28.0D) {
            this.jumpscareTriggered = true;
            this.setBossAnimState(ANIM_STATE_JUMPSCARE, 16);
            this.playSound(ModSounds.ECHO_JUMPSCARE.get(), 0.85F * volumeScale, 1.0F);
            ModNetwork.CHANNEL.send(
                    PacketDistributor.PLAYER.with(() -> owner),
                    new JumpscarePacket(this.getId())
            );
        }

        if (this.tickCount % 80 == 0) {
            this.playSound(ModSounds.ECHO_BOSS_LOOP.get(), 0.60F * volumeScale, this.isPhaseTwoBoss() ? 1.08F : 1.0F);
        }

        if (this.isPhaseTwoBoss() && this.tickCount % (perfMode ? 12 : 5) == 0 && this.level() instanceof ServerLevel sl) {
            double angle = (this.tickCount * 0.25D) % (Math.PI * 2.0D);
            double sx = this.getX() + Math.cos(angle) * 1.4D;
            double sz = this.getZ() + Math.sin(angle) * 1.4D;
            sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, sx, this.getY() + 1.5D, sz, perfMode ? 1 : 3, 0.1D, 0.1D, 0.1D, 0.02D);
        }

        if (this.stunnedTicks > 0) {
            this.stunnedTicks--;
            this.getNavigation().stop();
            if (this.level() instanceof ServerLevel sl && this.stunnedTicks % (perfMode ? 12 : 6) == 0) {
                sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, this.getX(), this.getY() + 1.2D, this.getZ(), perfMode ? 2 : 5, 0.35D, 0.5D, 0.35D, 0.05D);
            }
            if (this.stunnedTicks == 0) {
                this.setBossAnimState(ANIM_STATE_NORMAL, 0);
                owner.displayClientMessage(
                        Component.translatable("message.echocat.boss.recovered").withStyle(ChatFormatting.RED),
                        true
                );
            }
            return;
        }

        if (this.overloadTelegraphTicks > 0) {
            this.overloadTelegraphTicks--;
            this.getNavigation().stop();
            this.getLookControl().setLookAt(owner, 35.0F, 35.0F);

            if (this.level() instanceof ServerLevel sl && this.overloadTelegraphTicks % (perfMode ? 6 : 3) == 0) {
                int pCount = perfMode ? 3 : 7;
                sl.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, this.getX(), this.getY() + 1.4D, this.getZ(), pCount, 0.5D, 0.6D, 0.5D, 0.06D);
                sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, this.getX(), this.getY() + 1.4D, this.getZ(), pCount, 0.5D, 0.6D, 0.5D, 0.08D);
            }

            if (this.overloadTelegraphTicks == 0) {
                executeOverloadBurst(owner, volumeScale);
            }
            return;
        }

        this.getLookControl().setLookAt(owner, 30.0F, 30.0F);
        double moveSpeed = this.isPhaseTwoBoss() ? 1.38D : 1.18D;
        this.getNavigation().moveTo(owner, moveSpeed);

        if (this.bossActionCooldown > 0) {
            this.bossActionCooldown--;
            return;
        }

        int overloadInterval = this.isPhaseTwoBoss()
                ? EchoConfig.COMMON.bossPhase2OverloadInterval.get()
                : 5;

        if (this.attackCounter + 1 >= overloadInterval && this.distanceTo(owner) <= 12.0D) {
            startOverloadTelegraph(owner, volumeScale);
            return;
        }

        double dist = this.distanceTo(owner);
        int nextStep = (this.attackCounter % 4) + 1;

        if (nextStep == 4 && dist <= 18.0D) {
            this.attackCounter++;
            this.bossActionCooldown = this.isPhaseTwoBoss() ? 28 : 38;
            this.setBossAnimState(ANIM_STATE_TELEPORT_OUT, 10);
            teleportSafelyAroundPlayer(owner, 2.5D, 4.0D, true);
            this.setBossAnimState(ANIM_STATE_SWIPE, 14);
            this.playSound(ModSounds.ECHO_GLITCH_VOICE.get(), 0.95F * volumeScale, 0.85F);
            dealScaledBossDamage(owner, 1.0F);
        } else if (nextStep == 3 && dist >= 3.5D && dist <= 11.0D) {
            this.attackCounter++;
            this.bossActionCooldown = this.isPhaseTwoBoss() ? 26 : 36;
            this.setBossAnimState(ANIM_STATE_POUNCE, 16);
            Vec3 leap = owner.position().subtract(this.position()).normalize().scale(0.95D);
            this.setDeltaMovement(leap.x, 0.42D, leap.z);
            this.playSound(ModSounds.ECHO_GLITCH_VOICE.get(), 0.95F * volumeScale, 1.15F);
            if (dist <= 4.8D) {
                dealScaledBossDamage(owner, 1.10F);
            }
        } else if (dist <= 3.4D) {
            this.attackCounter++;
            this.bossActionCooldown = this.isPhaseTwoBoss() ? 22 : 32;
            if (nextStep == 2) {
                this.setBossAnimState(ANIM_STATE_BITE, 14);
                dealScaledBossDamage(owner, 1.15F);
            } else {
                this.setBossAnimState(ANIM_STATE_SWIPE, 12);
                dealScaledBossDamage(owner, 1.0F);
            }
            this.playSound(ModSounds.ECHO_GLITCH_VOICE.get(), 0.90F * volumeScale, 0.95F);
        }
    }

    public boolean isPhaseTwoBoss() {
        return this.getPhase() == EchoPhase.HORROR_FINAL && this.getHealth() <= (this.getMaxHealth() * 0.5F);
    }

    private void startOverloadTelegraph(ServerPlayer owner, float volumeScale) {
        this.overloadTelegraphTicks = 60;
        this.setBossAnimState(ANIM_STATE_OVERLOAD_TELEGRAPH, 65);
        this.getNavigation().stop();
        this.playSound(ModSounds.ECHO_OVERLOAD_CHARGE.get(), 1.15F * volumeScale, 1.0F);

        // Text-only accessibility cues in addition to audio (Step 3 requirement)
        owner.sendSystemMessage(
                Component.translatable("message.echocat.boss.overload_warning")
                        .withStyle(ChatFormatting.RED, ChatFormatting.BOLD)
        );
        owner.displayClientMessage(
                Component.translatable("message.echocat.boss.overload_actionbar")
                        .withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD),
                true
        );
    }

    private void executeOverloadBurst(ServerPlayer owner, float volumeScale) {
        this.attackCounter = 0;
        this.bossActionCooldown = 45;
        this.setBossAnimState(ANIM_STATE_NORMAL, 0);

        this.playSound(ModSounds.ECHO_STATIC_BURST.get(), 1.15F * volumeScale, 0.65F);
        if (this.level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.EXPLOSION, this.getX(), this.getY() + 1.0D, this.getZ(), 4, 0.6D, 0.6D, 0.6D, 0.05D);
        }

        if (this.distanceTo(owner) <= 10.0D) {
            float rawOverload = EchoConfig.COMMON.overloadDamage.get().floatValue();
            float safeDamage = Math.min(rawOverload, 16.0F);
            owner.hurt(this.damageSources().mobAttack(this), safeDamage);
        }
    }

    public void triggerRemoteCounterStun(Player player) {
        this.overloadTelegraphTicks = 0;
        this.attackCounter = 0;
        int stunSecs = EchoConfig.COMMON.stunDuration.get();
        this.stunnedTicks = stunSecs * 20;
        this.setBossAnimState(ANIM_STATE_STUNNED, this.stunnedTicks);
        this.getNavigation().stop();

        this.playSound(ModSounds.ECHO_STUNNED.get(), 1.2F, 1.0F);
        if (this.level() instanceof ServerLevel sl) {
            int sparkCount = EchoConfig.COMMON.performanceMode.get() ? 12 : 28;
            sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, this.getX(), this.getY() + 1.2D, this.getZ(), sparkCount, 0.5D, 0.6D, 0.5D, 0.12D);
        }

        // Both chat and actionbar text cues for deaf/hard-of-hearing players
        Component stunMsg = Component.translatable("message.echocat.boss.stunned", stunSecs)
                .withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD);
        player.sendSystemMessage(stunMsg);
        player.displayClientMessage(stunMsg, true);
    }

    private void dealScaledBossDamage(ServerPlayer target, float attackMultiplier) {
        float base = EchoConfig.COMMON.bossDamage.get().floatValue() * attackMultiplier;
        Difficulty diff = this.level().getDifficulty();
        float diffScale = switch (diff) {
            case PEACEFUL -> 0.0F;
            case EASY -> 0.75F;
            case NORMAL -> 1.0F;
            case HARD -> 1.35F;
        };
        if (diffScale > 0.0F) {
            target.hurt(this.damageSources().mobAttack(this), base * diffScale);
        }
    }

    public void resetBossToCalmState() {
        if (this.overloadTelegraphTicks > 0 || this.stunnedTicks > 0 || this.getHealth() < this.getMaxHealth()) {
            this.overloadTelegraphTicks = 0;
            this.stunnedTicks = 0;
            this.attackCounter = 0;
            this.setBossAnimState(ANIM_STATE_NORMAL, 0);
            this.setHealth(this.getMaxHealth());
        }
        this.bossEvent.setVisible(false);
        this.getNavigation().stop();
    }

    private boolean isPlayerLookingAtEcho(ServerPlayer player) {
        if (!player.hasLineOfSight(this)) {
            return false;
        }
        Vec3 viewVec = player.getViewVector(1.0F).normalize();
        Vec3 toEcho = this.getEyePosition().subtract(player.getEyePosition()).normalize();
        return viewVec.dot(toEcho) > 0.94D;
    }

    private void teleportSafelyAroundPlayer(ServerPlayer player, double minRadius, double maxRadius, boolean preferBehind) {
        if (!(this.level() instanceof ServerLevel serverLevel)) {
            return;
        }
        ThreadLocalRandom rng = ThreadLocalRandom.current();
        Vec3 look = player.getViewVector(1.0F);
        double baseAngle = Math.atan2(look.z, look.x);

        for (int attempt = 0; attempt < 16; attempt++) {
            double angleOffset = preferBehind && attempt < 10
                    ? Math.PI + rng.nextDouble(-0.75D, 0.75D)
                    : rng.nextDouble(0.0D, Math.PI * 2.0D);
            double dist = rng.nextDouble(minRadius, maxRadius);
            int tx = Mth.floor(player.getX() + Math.cos(baseAngle + angleOffset) * dist);
            int tz = Mth.floor(player.getZ() + Math.sin(baseAngle + angleOffset) * dist);
            int baseY = player.blockPosition().getY();

            for (int dy = 4; dy >= -4; dy--) {
                BlockPos candidate = new BlockPos(tx, baseY + dy, tz);
                if (!serverLevel.isLoaded(candidate)) {
                    continue;
                }
                BlockPos below = candidate.below();
                BlockPos above = candidate.above();
                if (!serverLevel.getBlockState(below).getCollisionShape(serverLevel, below).isEmpty()
                        && serverLevel.getBlockState(candidate).getCollisionShape(serverLevel, candidate).isEmpty()
                        && serverLevel.getBlockState(above).getCollisionShape(serverLevel, above).isEmpty()) {
                    this.moveTo(tx + 0.5D, candidate.getY(), tz + 0.5D, this.getYRot(), this.getXRot());
                    this.getNavigation().stop();
                    return;
                }
            }
        }
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        EchoPhase phase = this.getPhase();

        if (phase == EchoPhase.RED) {
            return false;
        }

        if (phase != EchoPhase.HORROR_FINAL && source.getEntity() instanceof Player player && this.isOwnedBy(player)) {
            return false;
        }

        if (phase == EchoPhase.HORROR_FINAL) {
            if (this.defeatTicks > 0) {
                return false;
            }
            if (this.stunnedTicks > 0) {
                amount *= 3.0F;
            }
            if (this.getHealth() - amount <= 0.0F) {
                this.setHealth(1.0F);
                startBossDefeatSequence();
                return true;
            }
        }

        if (!this.level().isClientSide) {
            this.setOrderedToSit(false);
            this.setInSittingPose(false);
        }
        return super.hurt(source, amount);
    }

    private void startBossDefeatSequence() {
        this.defeatTicks = 80;
        this.overloadTelegraphTicks = 0;
        this.stunnedTicks = 0;
        this.setBossAnimState(ANIM_STATE_DEATH, 85);
        this.bossEvent.setProgress(0.0F);
        this.getNavigation().stop();
        this.playSound(ModSounds.ECHO_BOSS_DEFEAT.get(), 1.2F, 1.0F);
    }

    private void completeBossDefeatSequence() {
        this.bossEvent.setVisible(false);
        this.bossEvent.removeAllPlayers();

        if (this.level() instanceof ServerLevel) {
            this.spawnAtLocation(new ItemStack(ModItems.ECHO_HEART.get(), 1));
            if (EchoConfig.COMMON.enablePurifiedPlush.get()) {
                this.spawnAtLocation(new ItemStack(ModItems.PURIFIED_ECHO_PLUSH.get(), 1));
            }
        }

        if (this.getOwner() instanceof ServerPlayer owner) {
            PhaseManager.setPhase(owner, EchoPhase.CUTE);
            owner.sendSystemMessage(
                    Component.translatable("message.echocat.boss.defeated")
                            .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD)
            );
        }

        this.remove(RemovalReason.DISCARDED);
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) {
            return InteractionResult.PASS;
        }
        if (this.getPhase().getId() >= EchoPhase.RED.getId() && !this.isPurified()) {
            return InteractionResult.PASS;
        }

        if (this.level().isClientSide) {
            boolean isOwner = this.isOwnedBy(player);
            return isOwner ? InteractionResult.CONSUME : InteractionResult.PASS;
        }

        if (this.isTame() && this.isOwnedBy(player)) {
            boolean nextSitting = !this.isOrderedToSit();
            this.setOrderedToSit(nextSitting);
            this.setInSittingPose(nextSitting);
            this.jumping = false;
            this.navigation.stop();

            String msgKey = nextSitting ? "message.echocat.sitting" : "message.echocat.following";
            player.displayClientMessage(Component.translatable(msgKey), true);
            this.playSound(ModSounds.ECHO_PURR.get(), 0.7F, 1.0F);
            return InteractionResult.SUCCESS;
        } else if (this.isTame()) {
            player.displayClientMessage(Component.translatable("message.echocat.not_owner"), true);
            return InteractionResult.FAIL;
        }

        return super.mobInteract(player, hand);
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    @Override
    public boolean isPersistenceRequired() {
        return true;
    }

    @Override
    public boolean isFood(ItemStack stack) {
        return false;
    }

    @Nullable
    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob otherParent) {
        return null;
    }

    @Nullable
    @Override
    protected SoundEvent getAmbientSound() {
        EchoPhase phase = this.getPhase();
        if (phase == EchoPhase.RED) {
            return ModSounds.ECHO_RED_BREATH.get();
        }
        return phase.getId() >= EchoPhase.GLITCH.getId()
                ? ModSounds.ECHO_GLITCH_VOICE.get()
                : ModSounds.ECHO_MEOW.get();
    }

    @Nullable
    @Override
    protected SoundEvent getHurtSound(DamageSource damageSource) {
        return this.getPhase() == EchoPhase.HORROR_FINAL
                ? ModSounds.ECHO_GLITCH_VOICE.get()
                : ModSounds.ECHO_MEOW.get();
    }

    @Nullable
    @Override
    protected SoundEvent getDeathSound() {
        return ModSounds.ECHO_BOSS_DEFEAT.get();
    }

    @Override
    public void addAdditionalSaveData(CompoundTag compound) {
        super.addAdditionalSaveData(compound);
        compound.putInt(TAG_DATA_VERSION, CURRENT_ENTITY_DATA_VERSION);
        compound.putInt(TAG_ECHO_PHASE, this.getPhaseId());
        compound.putBoolean(TAG_ECHO_SITTING, this.isOrderedToSit());
        compound.putFloat(TAG_RED_PROGRESS, this.getRedProgress());
        compound.putBoolean(TAG_PURIFIED, this.isPurified());
        compound.putInt(TAG_ATTACK_COUNTER, this.attackCounter);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag compound) {
        super.readAdditionalSaveData(compound);
        if (compound.contains(TAG_PURIFIED)) {
            this.setPurified(compound.getBoolean(TAG_PURIFIED));
        }
        if (compound.contains(TAG_RED_PROGRESS)) {
            this.setRedProgress(compound.getFloat(TAG_RED_PROGRESS));
        }
        if (compound.contains(TAG_ECHO_PHASE)) {
            this.setPhaseId(compound.getInt(TAG_ECHO_PHASE));
        }
        if (compound.contains(TAG_ECHO_SITTING)) {
            boolean sitting = compound.getBoolean(TAG_ECHO_SITTING);
            this.setOrderedToSit(sitting);
            this.setInSittingPose(sitting);
        }
        if (compound.contains(TAG_ATTACK_COUNTER)) {
            this.attackCounter = Math.max(0, compound.getInt(TAG_ATTACK_COUNTER));
        }
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "movement_controller", 4, this::movementPredicate));
        controllers.add(new AnimationController<>(this, "talk_controller", 2, this::talkPredicate));
    }

    private PlayState movementPredicate(AnimationState<EchoEntity> state) {
        boolean horrorModel = this.getPhase() == EchoPhase.HORROR_FINAL
                || (this.getPhase() == EchoPhase.RED && this.getRedProgress() >= 0.5F);

        if (horrorModel && !this.isPurified()) {
            int bossState = this.getBossAnimState();
            return switch (bossState) {
                case ANIM_STATE_DEATH -> state.setAndContinue(HORROR_DEATH);
                case ANIM_STATE_STUNNED -> state.setAndContinue(HORROR_STUNNED);
                case ANIM_STATE_OVERLOAD_TELEGRAPH -> state.setAndContinue(HORROR_OVERLOAD);
                case ANIM_STATE_JUMPSCARE -> state.setAndContinue(HORROR_JUMPSCARE);
                case ANIM_STATE_SWIPE -> state.setAndContinue(HORROR_SWIPE);
                case ANIM_STATE_BITE -> state.setAndContinue(HORROR_BITE);
                case ANIM_STATE_POUNCE -> state.setAndContinue(HORROR_POUNCE);
                case ANIM_STATE_TELEPORT_OUT -> state.setAndContinue(HORROR_TELEPORT_OUT);
                case ANIM_STATE_TELEPORT_IN -> state.setAndContinue(HORROR_TELEPORT_IN);
                default -> {
                    if (state.isMoving()) {
                        yield state.setAndContinue(this.isPhaseTwoBoss() ? HORROR_RUN : HORROR_WALK);
                    }
                    yield state.setAndContinue(HORROR_IDLE);
                }
            };
        }

        if (this.isInSittingPose()) {
            return state.setAndContinue(CUTE_SIT);
        }
        if (state.isMoving()) {
            return state.setAndContinue(CUTE_WALK);
        }
        return state.setAndContinue(CUTE_IDLE);
    }

    private PlayState talkPredicate(AnimationState<EchoEntity> state) {
        if (this.isTalking()) {
            return state.setAndContinue(CUTE_TALK);
        }
        state.getController().forceAnimationReset();
        return PlayState.STOP;
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.geoCache;
    }
}
