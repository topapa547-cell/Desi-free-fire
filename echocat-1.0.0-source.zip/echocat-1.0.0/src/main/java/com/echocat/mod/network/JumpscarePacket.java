package com.echocat.mod.network;

import com.echocat.mod.client.ClientPacketHandlers;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Server -> Client packet sent when the Phase 6 HORROR_FINAL boss first spots its owner.
 * Plays a jumpscare visual and stinger sound on the client ONLY if {@code enableJumpscares}
 * is true and {@code photosensitiveMode} is false.
 */
public class JumpscarePacket {
    private final int echoEntityId;

    public JumpscarePacket(int echoEntityId) {
        this.echoEntityId = echoEntityId;
    }

    public int getEchoEntityId() {
        return this.echoEntityId;
    }

    public static void encode(JumpscarePacket packet, FriendlyByteBuf buf) {
        buf.writeVarInt(packet.echoEntityId);
    }

    public static JumpscarePacket decode(FriendlyByteBuf buf) {
        return new JumpscarePacket(buf.readVarInt());
    }

    public static void handle(JumpscarePacket packet, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPacketHandlers.handleJumpscare(packet))
        );
        context.setPacketHandled(true);
    }
}
