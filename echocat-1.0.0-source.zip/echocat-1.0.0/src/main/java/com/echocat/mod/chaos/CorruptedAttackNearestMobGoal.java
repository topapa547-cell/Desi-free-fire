package com.echocat.mod.chaos;

import com.echocat.mod.entity.EchoEntity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.phys.AABB;

import java.util.EnumSet;
import java.util.List;

/**
 * Target goal injected into corrupted mobs during Phase 4 (CHAOS).
 * Causes the corrupted mob to target the nearest other eligible mob within 16 blocks
 * (excluding Echo, players, tamed pets, bosses, villagers, and iron golems).
 * Throttles target scans to once every 20 ticks for server performance.
 */
public class CorruptedAttackNearestMobGoal extends Goal {
    private final Mob mob;
    private LivingEntity selectedTarget;
    private int scanCooldown = 0;

    public CorruptedAttackNearestMobGoal(Mob mob) {
        this.mob = mob;
        this.setFlags(EnumSet.of(Goal.Flag.TARGET));
    }

    @Override
    public boolean canUse() {
        if (!ChaosCorruptionHandler.isCorrupted(this.mob)) {
            return false;
        }
        if (--this.scanCooldown > 0) {
            return false;
        }
        this.scanCooldown = 20; // Throttle scan to every 20 ticks

        AABB searchBox = this.mob.getBoundingBox().inflate(16.0D, 8.0D, 16.0D);
        List<Mob> candidates = this.mob.level().getEntitiesOfClass(
                Mob.class,
                searchBox,
                other -> other != this.mob
                        && other.isAlive()
                        && !(other instanceof EchoEntity)
                        && !(other instanceof TamableAnimal tamable && tamable.isTame())
                        && !ChaosCorruptionHandler.isExemptFromCorruption(other)
        );

        if (candidates.isEmpty()) {
            return false;
        }

        Mob nearest = null;
        double bestDistSqr = Double.MAX_VALUE;
        for (Mob candidate : candidates) {
            double d = this.mob.distanceToSqr(candidate);
            if (d < bestDistSqr) {
                bestDistSqr = d;
                nearest = candidate;
            }
        }

        this.selectedTarget = nearest;
        return this.selectedTarget != null;
    }

    @Override
    public boolean canContinueToUse() {
        if (!ChaosCorruptionHandler.isCorrupted(this.mob)) {
            return false;
        }
        LivingEntity target = this.mob.getTarget();
        return target != null && target.isAlive() && this.mob.distanceToSqr(target) <= (24.0D * 24.0D);
    }

    @Override
    public void start() {
        this.mob.setTarget(this.selectedTarget);
        super.start();
    }

    @Override
    public void stop() {
        this.selectedTarget = null;
        super.stop();
    }
}
