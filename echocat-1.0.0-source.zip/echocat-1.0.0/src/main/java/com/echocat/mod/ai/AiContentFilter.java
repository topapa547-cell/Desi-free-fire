package com.echocat.mod.ai;

import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Safety & Content Filter for external AI lines (Step 3 Content Rules):
 * Enforces:
 * - Maximum 8 words and maximum 120 characters.
 * - Blocks URLs / domain links (`http://`, `https://`, `www.`, `.com`, `.net`, `.org`).
 * - Blocks self-harm phrasing, real-world threat/doxxing phrasing, graphic gore phrasing, and slurs.
 * - Whenever a line is blocked, {@link HttpAIService} silently falls back to {@link LocalCreepyFallback}.
 */
public final class AiContentFilter {
    private static final Pattern URL_PATTERN = Pattern.compile(
            "(?i)(https?://|www\\.|\\b[a-z0-9-]+\\.(com|net|org|io|gg|xyz|ru|cn)\\b)"
    );

    private static final List<String> BLOCKED_SUBSTRINGS = List.of(
            // Self-harm / suicide phrasing
            "kill yourself", "kys", "hurt yourself", "end your life", "suicide", "self harm", "self-harm", "cut yourself",
            // Real-world threats / personal data / doxxing
            "in real life", "irl", "your address", "your house", "your family", "swat you", "find where you live", "ip address", "credit card", "password",
            // Graphic gore / extreme violence
            "blood", "bleed", "organs", "intestines", "guts", "mutilate", "dismember", "decapitate", "corpse", "viscera",
            // Slurs / hate speech roots
            "nigger", "nigga", "faggot", "retard", "kike", "chink", "spic", "tranny"
    );

    private AiContentFilter() {
    }

    /**
     * Returns true if the candidate AI line is safe to display in-game, or false if it violates
     * any content rule and must be replaced by {@link LocalCreepyFallback}.
     */
    public static boolean isSafeAiOutput(String candidate) {
        if (candidate == null || candidate.isBlank()) {
            return false;
        }
        String normalized = candidate.toLowerCase(Locale.ROOT).trim();
        if (normalized.length() > 120) {
            return false;
        }
        if (URL_PATTERN.matcher(normalized).find()) {
            return false;
        }
        for (String blocked : BLOCKED_SUBSTRINGS) {
            if (normalized.contains(blocked)) {
                return false;
            }
        }
        return true;
    }
}
