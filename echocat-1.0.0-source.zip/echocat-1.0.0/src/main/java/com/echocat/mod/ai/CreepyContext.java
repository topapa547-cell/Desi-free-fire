package com.echocat.mod.ai;

import com.echocat.mod.phase.EchoPhase;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.biome.Biome;

/**
 * Immutable snapshot of player and world context passed to {@link AIService#generateCreepyLine(CreepyContext)}.
 * Collected on the main server thread before dispatching asynchronous AI or fallback generation.
 */
public record CreepyContext(
        String playerName,
        long timeOfDay,
        String biome,
        String dimension,
        float health,
        int yLevel,
        boolean canSeeSky,
        String lastPlayerMessage,
        EchoPhase currentPhase
) {
    /**
     * Captures a thread-safe CreepyContext from a ServerPlayer on the server thread.
     */
    public static CreepyContext fromPlayer(ServerPlayer player, String sanitizedMessage, EchoPhase phase) {
        ServerLevel level = player.serverLevel();
        BlockPos pos = player.blockPosition();
        long dayTime = level.getDayTime() % 24000L;

        Holder<Biome> biomeHolder = level.getBiome(pos);
        String biomeId = biomeHolder.unwrapKey()
                .map(ResourceKey::location)
                .map(Object::toString)
                .orElse("minecraft:plains");

        String dimensionId = level.dimension().location().toString();
        float health = player.getHealth();
        int y = pos.getY();
        boolean sky = level.canSeeSky(pos);

        return new CreepyContext(
                player.getGameProfile().getName(),
                dayTime,
                biomeId,
                dimensionId,
                health,
                y,
                sky,
                sanitizedMessage,
                phase
        );
    }

    public boolean isNight() {
        return this.timeOfDay >= 13000L && this.timeOfDay <= 23000L;
    }

    public boolean isUndergroundCave() {
        return !this.canSeeSky && this.yLevel < 48 && "minecraft:overworld".equals(this.dimension);
    }

    public boolean isLowHealth() {
        return this.health <= 8.0F;
    }

    public boolean isNether() {
        return this.dimension.contains("the_nether");
    }

    public boolean isEnd() {
        return this.dimension.contains("the_end");
    }
}
