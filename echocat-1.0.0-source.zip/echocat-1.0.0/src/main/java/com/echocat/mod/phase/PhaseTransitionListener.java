package com.echocat.mod.phase;

import com.echocat.mod.entity.EchoEntity;
import com.echocat.mod.network.ModNetwork;
import com.echocat.mod.network.PhaseTransitionEffectPacket;
import com.echocat.mod.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.network.PacketDistributor;

import java.util.List;

/**
 * Hooks into {@link EchoPhaseChangeEvent} to trigger dramatic audiovisual transitions
 * when entering GLITCH, CHAOS, RED, and HORROR_FINAL.
 */
public class PhaseTransitionListener {

    @SubscribeEvent
    public void onEchoPhaseChange(final EchoPhaseChangeEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || player.server == null) {
            return;
        }

        EchoPhase newPhase = event.getNewPhase();
        switch (newPhase) {
            case GLITCH -> triggerGlitchTransition(player);
            case CHAOS -> triggerChaosTransition(player);
            case RED -> triggerRedTransition(player);
            case HORROR_FINAL -> triggerHorrorFinalTransition(player);
            default -> {}
        }
    }

    private static void triggerGlitchTransition(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        List<EchoEntity> echoes = PhaseManager.findPlayerEchoEntities(player.server, player.getUUID());

        for (EchoEntity echo : echoes) {
            if (echo.level() instanceof ServerLevel echoLevel) {
                echoLevel.sendParticles(
                        ParticleTypes.ELECTRIC_SPARK,
                        echo.getX(), echo.getY() + 0.5D, echo.getZ(),
                        24, 0.35D, 0.45D, 0.35D, 0.08D
                );
                echo.playSound(ModSounds.ECHO_STATIC_BURST.get(), 1.0F, 1.0F);
                echo.playSound(ModSounds.ECHO_GLITCH_VOICE.get(), 0.9F, 0.85F);
                echo.triggerTalkAnimation(40);
            }
        }

        if (echoes.isEmpty()) {
            level.playSound(null, player.blockPosition(), ModSounds.ECHO_STATIC_BURST.get(), SoundSource.HOSTILE, 0.9F, 1.0F);
        }

        player.sendSystemMessage(
                Component.translatable("message.echocat.transition.glitch").withStyle(ChatFormatting.AQUA)
        );

        ModNetwork.CHANNEL.send(
                PacketDistributor.PLAYER.with(() -> player),
                new PhaseTransitionEffectPacket(EchoPhase.GLITCH.getId(), 30)
        );
    }

    private static void triggerChaosTransition(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        List<EchoEntity> echoes = PhaseManager.findPlayerEchoEntities(player.server, player.getUUID());

        for (EchoEntity echo : echoes) {
            if (echo.level() instanceof ServerLevel echoLevel) {
                echoLevel.sendParticles(
                        ParticleTypes.LARGE_SMOKE,
                        echo.getX(), echo.getY() + 0.5D, echo.getZ(),
                        30, 0.45D, 0.45D, 0.45D, 0.04D
                );
                echoLevel.sendParticles(
                        ParticleTypes.SOUL_FIRE_FLAME,
                        echo.getX(), echo.getY() + 0.5D, echo.getZ(),
                        18, 0.35D, 0.35D, 0.35D, 0.03D
                );
                echo.playSound(ModSounds.ECHO_CHAOS_HUM.get(), 1.0F, 0.80F);
                echo.playSound(ModSounds.ECHO_STATIC_BURST.get(), 0.9F, 0.70F);
                echo.triggerTalkAnimation(50);
            }
        }

        if (echoes.isEmpty()) {
            level.playSound(null, player.blockPosition(), ModSounds.ECHO_CHAOS_HUM.get(), SoundSource.HOSTILE, 1.0F, 0.80F);
        }

        player.sendSystemMessage(
                Component.translatable("message.echocat.transition.chaos").withStyle(ChatFormatting.DARK_RED)
        );

        ModNetwork.CHANNEL.send(
                PacketDistributor.PLAYER.with(() -> player),
                new PhaseTransitionEffectPacket(EchoPhase.CHAOS.getId(), 40)
        );
    }

    private static void triggerRedTransition(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        List<EchoEntity> echoes = PhaseManager.findPlayerEchoEntities(player.server, player.getUUID());

        for (EchoEntity echo : echoes) {
            echo.setOrderedToSit(false);
            echo.setInSittingPose(false);
            echo.playSound(ModSounds.ECHO_RED_BREATH.get(), 1.0F, 0.85F);
        }

        if (echoes.isEmpty()) {
            level.playSound(null, player.blockPosition(), ModSounds.ECHO_RED_BREATH.get(), SoundSource.HOSTILE, 1.0F, 0.85F);
        }

        player.sendSystemMessage(
                Component.translatable("message.echocat.transition.red").withStyle(ChatFormatting.RED)
        );

        ModNetwork.CHANNEL.send(
                PacketDistributor.PLAYER.with(() -> player),
                new PhaseTransitionEffectPacket(EchoPhase.RED.getId(), 35)
        );
    }

    private static void triggerHorrorFinalTransition(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        List<EchoEntity> echoes = PhaseManager.findPlayerEchoEntities(player.server, player.getUUID());

        for (EchoEntity echo : echoes) {
            if (echo.level() instanceof ServerLevel echoLevel) {
                echoLevel.sendParticles(
                        ParticleTypes.SOUL_FIRE_FLAME,
                        echo.getX(), echo.getY() + 1.0D, echo.getZ(),
                        40, 0.5D, 0.8D, 0.5D, 0.06D
                );
            }
            echo.playSound(ModSounds.ECHO_BOSS_LOOP.get(), 1.0F, 1.0F);
        }

        if (echoes.isEmpty()) {
            level.playSound(null, player.blockPosition(), ModSounds.ECHO_BOSS_LOOP.get(), SoundSource.HOSTILE, 1.0F, 1.0F);
        }

        player.sendSystemMessage(
                Component.translatable("message.echocat.transition.horror_final")
                        .withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD)
        );

        ModNetwork.CHANNEL.send(
                PacketDistributor.PLAYER.with(() -> player),
                new PhaseTransitionEffectPacket(EchoPhase.HORROR_FINAL.getId(), 50)
        );
    }
}
