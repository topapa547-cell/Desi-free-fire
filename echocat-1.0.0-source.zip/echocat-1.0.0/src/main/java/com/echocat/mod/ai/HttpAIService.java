package com.echocat.mod.ai;

import com.echocat.mod.EchoCatMod;
import com.echocat.mod.config.EchoConfig;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.server.MinecraftServer;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * OpenAI-compatible HTTP chat-completions implementation of {@link AIService} (v1.0.0).
 * Includes {@link AiContentFilter} output validation and clean rate-limiter reset on server stop.
 */
public class HttpAIService implements AIService {
    private static final String SYSTEM_PROMPT =
            "You are Echo, a pet cat in Minecraft that is slowly becoming eerie and wrong. "
            + "Reply with ONE short unsettling sentence (maximum 8 words). "
            + "Never be gory, never be graphic, never make real-world threats, and never use personal data. "
            + "Examples: 'why did you leave me', 'I see you', 'behind you', 'wake up'.";

    private static final long PLAYER_RATE_LIMIT_MS = 3000L;
    private static final Duration TIMEOUT = Duration.ofSeconds(5);
    private static final Gson GSON = new Gson();
    public static final HttpAIService INSTANCE = new HttpAIService();

    private final ExecutorService executor = Executors.newFixedThreadPool(2, runnable -> {
        Thread thread = new Thread(runnable, "EchoCat-AI-Worker");
        thread.setDaemon(true);
        return thread;
    });

    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(TIMEOUT)
            .executor(this.executor)
            .build();

    private final Map<UUID, Long> lastPlayerRequestMs = new ConcurrentHashMap<>();

    private HttpAIService() {
    }

    public void clearRateLimitCache() {
        this.lastPlayerRequestMs.clear();
    }

    public CompletableFuture<String> generateForPlayer(MinecraftServer server, UUID playerUuid, CreepyContext ctx) {
        String provider = EchoConfig.COMMON.apiProvider.get();
        String apiKey = EchoConfig.COMMON.apiKey.get();
        String endpoint = EchoConfig.COMMON.apiEndpoint.get();

        if (provider == null || "none".equalsIgnoreCase(provider.trim())
                || apiKey == null || apiKey.isBlank()
                || endpoint == null || endpoint.isBlank()) {
            logDebug("AI source: LocalCreepyFallback (apiProvider is 'none' or apiKey is empty)");
            return CompletableFuture.completedFuture(LocalCreepyFallback.pickContextualLine(ctx));
        }

        long now = System.currentTimeMillis();
        Long lastReq = this.lastPlayerRequestMs.get(playerUuid);
        if (lastReq != null && (now - lastReq) < PLAYER_RATE_LIMIT_MS) {
            logDebug("AI source: LocalCreepyFallback (per-player 3s rate limit active)");
            return CompletableFuture.completedFuture(LocalCreepyFallback.pickContextualLine(ctx));
        }

        int maxDaily = EchoConfig.COMMON.maxAiRequestsPerDay.get();
        if (server != null && !DailyAiRequestData.get(server).tryConsumeQuota(maxDaily)) {
            logDebug("AI source: LocalCreepyFallback (daily AI request cap reached: " + maxDaily + ")");
            return CompletableFuture.completedFuture(LocalCreepyFallback.pickContextualLine(ctx));
        }

        this.lastPlayerRequestMs.put(playerUuid, now);
        return generateCreepyLine(ctx);
    }

    @Override
    public CompletableFuture<String> generateCreepyLine(CreepyContext ctx) {
        String provider = EchoConfig.COMMON.apiProvider.get();
        String apiKey = EchoConfig.COMMON.apiKey.get();
        String endpoint = EchoConfig.COMMON.apiEndpoint.get();
        String model = EchoConfig.COMMON.apiModel.get();

        if (provider == null || "none".equalsIgnoreCase(provider.trim())
                || apiKey == null || apiKey.isBlank()
                || endpoint == null || endpoint.isBlank()) {
            return CompletableFuture.completedFuture(LocalCreepyFallback.pickContextualLine(ctx));
        }

        return CompletableFuture.supplyAsync(() -> {
            try {
                JsonObject payload = buildRequestPayload(model, ctx);
                String jsonBody = GSON.toJson(payload);

                HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(endpoint.trim()))
                        .timeout(TIMEOUT)
                        .header("Content-Type", "application/json")
                        .header("Authorization", "Bearer " + apiKey.trim())
                        .POST(HttpRequest.BodyPublishers.ofString(jsonBody, StandardCharsets.UTF_8))
                        .build();

                HttpResponse<String> response = this.httpClient.send(
                        request,
                        HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8)
                );

                if (response.statusCode() >= 200 && response.statusCode() < 300) {
                    String parsed = parseChatCompletionContent(response.body());
                    if (parsed != null && !parsed.isBlank()) {
                        String cleaned = sanitizeAiLine(parsed);
                        if (AiContentFilter.isSafeAiOutput(cleaned)) {
                            logDebug("AI source: External API (HTTP " + response.statusCode() + ")");
                            return cleaned;
                        } else {
                            logDebug("AI source: LocalCreepyFallback (AI output blocked by AiContentFilter)");
                        }
                    }
                } else {
                    logDebug("AI source: LocalCreepyFallback (API returned HTTP " + response.statusCode() + ")");
                }
            } catch (Exception ex) {
                logDebug("AI source: LocalCreepyFallback (API exception: " + ex.getClass().getSimpleName() + ")");
            }
            return LocalCreepyFallback.pickContextualLine(ctx);
        }, this.executor);
    }

    private static JsonObject buildRequestPayload(String model, CreepyContext ctx) {
        JsonObject root = new JsonObject();
        root.addProperty("model", (model == null || model.isBlank()) ? "gpt-4o-mini" : model.trim());
        root.addProperty("max_tokens", 24);
        root.addProperty("temperature", 0.85);

        JsonArray messages = new JsonArray();

        JsonObject sysMsg = new JsonObject();
        sysMsg.addProperty("role", "system");
        sysMsg.addProperty("content", SYSTEM_PROMPT);
        messages.add(sysMsg);

        JsonObject userMsg = new JsonObject();
        userMsg.addProperty("role", "user");
        // Privacy & logging audit: we only send non-identifying game state context (time, biome, dimension, health, phase)
        String userPrompt = String.format(
                "Context: time=%d (%s), biome=%s, dimension=%s, playerHealth=%.1f, phase=%s. Generate 1 short unsettling sentence (max 8 words).",
                ctx.timeOfDay(),
                ctx.isNight() ? "night" : "day",
                ctx.biome(),
                ctx.dimension(),
                ctx.health(),
                ctx.currentPhase().name()
        );
        userMsg.addProperty("content", userPrompt);
        messages.add(userMsg);

        root.add("messages", messages);
        return root;
    }

    private static String parseChatCompletionContent(String responseJson) {
        JsonElement element = JsonParser.parseString(responseJson);
        if (!element.isJsonObject()) {
            return null;
        }
        JsonObject obj = element.getAsJsonObject();
        if (!obj.has("choices") || !obj.get("choices").isJsonArray()) {
            return null;
        }
        JsonArray choices = obj.getAsJsonArray("choices");
        if (choices.isEmpty() || !choices.get(0).isJsonObject()) {
            return null;
        }
        JsonObject firstChoice = choices.get(0).getAsJsonObject();
        if (!firstChoice.has("message") || !firstChoice.get("message").isJsonObject()) {
            return null;
        }
        JsonObject message = firstChoice.getAsJsonObject("message");
        if (!message.has("content") || message.get("content").isJsonNull()) {
            return null;
        }
        return message.get("content").getAsString();
    }

    public static String sanitizeAiLine(String raw) {
        if (raw == null) {
            return "";
        }
        String stripped = raw.replaceAll("(?i)\\u00A7[0-9A-FK-OR]", "")
                .replace("\"", "")
                .replace("\r", " ")
                .replace("\n", " ")
                .trim();
        String[] words = stripped.split("\\s+");
        StringBuilder sb = new StringBuilder();
        int limit = Math.min(words.length, 8);
        for (int i = 0; i < limit; i++) {
            if (i > 0) {
                sb.append(' ');
            }
            sb.append(words[i]);
        }
        String result = sb.toString();
        if (result.length() > 120) {
            result = result.substring(0, 120).trim();
        }
        return result;
    }

    private static void logDebug(String message) {
        if (EchoConfig.COMMON.debugMode.get()) {
            EchoCatMod.LOGGER.info("[EchoCat AI Debug] {}", message);
        }
    }
}
