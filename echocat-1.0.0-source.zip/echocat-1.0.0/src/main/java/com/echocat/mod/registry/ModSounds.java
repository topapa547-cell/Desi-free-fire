package com.echocat.mod.registry;

import com.echocat.mod.EchoCatMod;
import com.echocat.mod.util.EchoConstants;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUND_EVENTS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, EchoCatMod.MOD_ID);

    public static final RegistryObject<SoundEvent> ECHO_MEOW = registerSound("echo_meow");
    public static final RegistryObject<SoundEvent> ECHO_PURR = registerSound("echo_purr");
    public static final RegistryObject<SoundEvent> ECHO_TALK = registerSound("echo_talk");
    public static final RegistryObject<SoundEvent> ECHO_GLITCH = registerSound("echo_glitch");

    // Phase 3 Glitch & Chaos original procedural OGG sounds
    public static final RegistryObject<SoundEvent> ECHO_GLITCH_VOICE = registerSound("echo_glitch_voice");
    public static final RegistryObject<SoundEvent> ECHO_STATIC_BURST = registerSound("echo_static_burst");
    public static final RegistryObject<SoundEvent> ECHO_STUTTER = registerSound("echo_stutter");
    public static final RegistryObject<SoundEvent> ECHO_CHAOS_HUM = registerSound("echo_chaos_hum");

    // Phase 4 Red Phase & Boss Fight original procedural OGG sounds
    public static final RegistryObject<SoundEvent> ECHO_RED_BREATH = registerSound("echo_red_breath");
    public static final RegistryObject<SoundEvent> ECHO_OVERLOAD_CHARGE = registerSound("echo_overload_charge");
    public static final RegistryObject<SoundEvent> ECHO_STUNNED = registerSound("echo_stunned");
    public static final RegistryObject<SoundEvent> ECHO_JUMPSCARE = registerSound("echo_jumpscare");
    public static final RegistryObject<SoundEvent> ECHO_BOSS_LOOP = registerSound("echo_boss_loop");
    public static final RegistryObject<SoundEvent> ECHO_BOSS_DEFEAT = registerSound("echo_boss_defeat");

    private ModSounds() {
    }

    private static RegistryObject<SoundEvent> registerSound(String name) {
        return SOUND_EVENTS.register(name, () -> SoundEvent.createVariableRangeEvent(EchoConstants.rl(name)));
    }

    public static void register(IEventBus eventBus) {
        SOUND_EVENTS.register(eventBus);
    }
}
