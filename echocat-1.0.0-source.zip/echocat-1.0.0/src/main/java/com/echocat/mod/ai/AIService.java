package com.echocat.mod.ai;

import java.util.concurrent.CompletableFuture;

/**
 * Service interface for generating short, atmospheric unsettling lines spoken by Echo
 * starting in Phase 2 (WEIRD).
 */
public interface AIService {
    /**
     * Generates a single unsettling sentence asynchronously off the main server thread.
     *
     * @param ctx Thread-safe snapshot of player/world context.
     * @return CompletableFuture resolving to a sanitized short creepy sentence.
     */
    CompletableFuture<String> generateCreepyLine(CreepyContext ctx);
}
