package com.echocat.mod.network;

import com.echocat.mod.chat.ChatRepeatHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Supplier;

/**
 * Client -> Server packet carrying speech-to-text transcribed audio from push-to-talk.
 * Hardened in Step 1 Audit with server-side length validation, alive/null checks,
 * and a strict 1000ms packet rate limit before delegating to {@link ChatRepeatHandler}.
 */
public class VoiceTextPacket {
    private static final Map<UUID, Long> PACKET_RATE_LIMIT_MS = new ConcurrentHashMap<>();
    private final String transcribedText;

    public VoiceTextPacket(String transcribedText) {
        if (transcribedText == null) {
            this.transcribedText = "";
        } else if (transcribedText.length() > ChatRepeatHandler.MAX_MESSAGE_CHARS) {
            this.transcribedText = transcribedText.substring(0, ChatRepeatHandler.MAX_MESSAGE_CHARS);
        } else {
            this.transcribedText = transcribedText;
        }
    }

    public String getTranscribedText() {
        return this.transcribedText;
    }

    public static void encode(VoiceTextPacket packet, FriendlyByteBuf buf) {
        buf.writeUtf(packet.transcribedText, ChatRepeatHandler.MAX_MESSAGE_CHARS);
    }

    public static VoiceTextPacket decode(FriendlyByteBuf buf) {
        return new VoiceTextPacket(buf.readUtf(ChatRepeatHandler.MAX_MESSAGE_CHARS));
    }

    public static void handle(VoiceTextPacket packet, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> {
            ServerPlayer sender = context.getSender();
            if (sender == null || !sender.isAlive()) {
                return;
            }
            long now = System.currentTimeMillis();
            Long last = PACKET_RATE_LIMIT_MS.get(sender.getUUID());
            if (last != null && (now - last) < 1000L) {
                return;
            }
            PACKET_RATE_LIMIT_MS.put(sender.getUUID(), now);
            ChatRepeatHandler.handlePlayerUtterance(sender, packet.getTranscribedText(), true);
        });
        context.setPacketHandled(true);
    }
}
