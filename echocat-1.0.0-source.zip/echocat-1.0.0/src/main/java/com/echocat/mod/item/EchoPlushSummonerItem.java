package com.echocat.mod.item;

import com.echocat.mod.entity.EchoEntity;
import com.echocat.mod.phase.EchoPhase;
import com.echocat.mod.phase.PhaseManager;
import com.echocat.mod.registry.ModEntities;
import com.echocat.mod.registry.ModItems;
import com.echocat.mod.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * Summons Echo: The Talking Cat when right-clicked on a block.
 * Also automatically grants the player a copy of "Echo's Journal" on their first summon
 * if they don't already have one.
 */
public class EchoPlushSummonerItem extends Item {
    private static final String NBT_GAVE_JOURNAL = "EchoCatGaveJournal";

    public EchoPlushSummonerItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        if (!(level instanceof ServerLevel serverLevel)) {
            return InteractionResult.SUCCESS;
        }

        Player player = context.getPlayer();
        if (player == null) {
            return InteractionResult.PASS;
        }

        List<EchoEntity> existing = PhaseManager.findPlayerEchoEntities(serverLevel.getServer(), player.getUUID());
        if (!existing.isEmpty()) {
            player.sendSystemMessage(
                    Component.translatable("message.echocat.already_summoned").withStyle(ChatFormatting.RED)
            );
            return InteractionResult.FAIL;
        }

        BlockPos clickedPos = context.getClickedPos();
        Direction face = context.getClickedFace();
        BlockState clickedState = level.getBlockState(clickedPos);
        BlockPos spawnPos = clickedState.getCollisionShape(level, clickedPos).isEmpty()
                ? clickedPos
                : clickedPos.relative(face);

        EchoEntity echo = ModEntities.ECHO.get().create(serverLevel);
        if (echo == null) {
            return InteractionResult.FAIL;
        }

        echo.moveTo(
                spawnPos.getX() + 0.5D,
                spawnPos.getY(),
                spawnPos.getZ() + 0.5D,
                player.getYRot(),
                0.0F
        );
        echo.tame(player);
        echo.setOrderedToSit(false);
        echo.setInSittingPose(false);
        echo.setPersistenceRequired();

        EchoPhase currentPhase = PhaseManager.getPhase(player);
        echo.setPhase(currentPhase);

        serverLevel.addFreshEntity(echo);
        serverLevel.playSound(
                null,
                spawnPos,
                ModSounds.ECHO_MEOW.get(),
                SoundSource.NEUTRAL,
                1.0F,
                1.0F
        );

        player.sendSystemMessage(
                Component.translatable("message.echocat.summoned").withStyle(ChatFormatting.GOLD)
        );

        // Automatically grant Echo's Journal on first summon
        if (!player.getPersistentData().getBoolean(NBT_GAVE_JOURNAL)) {
            player.getPersistentData().putBoolean(NBT_GAVE_JOURNAL, true);
            ItemStack journal = new ItemStack(ModItems.ECHO_JOURNAL.get());
            if (!player.getInventory().add(journal)) {
                player.drop(journal, false);
            }
            player.sendSystemMessage(
                    Component.translatable("message.echocat.journal_given").withStyle(ChatFormatting.YELLOW)
            );
        }

        ItemStack itemStack = context.getItemInHand();
        if (!player.getAbilities().instabuild) {
            itemStack.shrink(1);
        }

        return InteractionResult.CONSUME;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltipComponents, TooltipFlag isAdvanced) {
        tooltipComponents.add(
                Component.translatable("item.echocat.echo_plush_summoner.desc").withStyle(ChatFormatting.GRAY)
        );
    }
}
