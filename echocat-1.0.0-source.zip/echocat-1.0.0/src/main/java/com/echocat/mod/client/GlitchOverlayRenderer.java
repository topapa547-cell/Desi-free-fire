package com.echocat.mod.client;

import com.echocat.mod.config.EchoConfig;
import com.echocat.mod.entity.EchoEntity;
import com.echocat.mod.mission.MissionManager;
import com.echocat.mod.phase.EchoPhase;
import com.echocat.mod.phase.PhaseManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.gui.overlay.ForgeGui;

import java.util.List;
import java.util.Random;

/**
 * Renders client-side overlays:
 * 1. Optional compact Mission HUD tracker (`EchoConfig.CLIENT.showMissionHud`).
 * 2. Phase 3+ proximity scanlines & chromatic bars within 12 blocks of Echo.
 * 3. Phase transition pulses and Phase 6 Boss first-sight jumpscare visual
 *    (strictly respecting `enableJumpscares` and `photosensitiveMode`).
 */
@OnlyIn(Dist.CLIENT)
public final class GlitchOverlayRenderer {
    public static final double MAX_GLITCH_OVERLAY_DISTANCE = 12.0D;

    private static long transitionEndMs = 0L;
    private static int transitionPhaseId = 1;
    private static long jumpscareEndMs = 0L;

    private GlitchOverlayRenderer() {
    }

    public static void triggerPhaseTransitionPulse(int newPhaseId, int durationTicks) {
        transitionPhaseId = newPhaseId;
        long durationMs = Math.max(400L, durationTicks * 50L);
        transitionEndMs = System.currentTimeMillis() + durationMs;
    }

    public static void triggerJumpscareVisual() {
        if (!EchoConfig.CLIENT.enableJumpscares.get() || EchoConfig.CLIENT.photosensitiveMode.get()) {
            return;
        }
        jumpscareEndMs = System.currentTimeMillis() + 550L;
    }

    public static void renderGlitchOverlay(ForgeGui gui, GuiGraphics guiGraphics, float partialTick, int screenWidth, int screenHeight) {
        Minecraft mc = Minecraft.getInstance();
        Player player = mc.player;
        if (player == null || mc.level == null) {
            return;
        }

        // 1. Optional Mission HUD line in top-right corner
        if (EchoConfig.CLIENT.showMissionHud.get() && mc.screen == null) {
            renderMissionHudLine(mc.font, guiGraphics, screenWidth);
        }

        boolean photosensitive = EchoConfig.CLIENT.photosensitiveMode.get();
        int horrorIntensity = Math.max(1, Math.min(3, EchoConfig.COMMON.horrorIntensity.get()));
        long nowMs = System.currentTimeMillis();

        // 2. Boss First-Sight Jumpscare visual (only if enableJumpscares && !photosensitiveMode)
        if (!photosensitive && EchoConfig.CLIENT.enableJumpscares.get() && nowMs < jumpscareEndMs) {
            renderJumpscareFrame(guiGraphics, screenWidth, screenHeight);
        }

        long timeBucket = photosensitive ? (nowMs / 500L) : (nowMs / 80L);
        Random rng = new Random(timeBucket * 31L + 7L);

        // 3. Active phase transition pulse
        if (nowMs < transitionEndMs) {
            float progress = Math.min(1.0F, (float) (transitionEndMs - nowMs) / 1500.0F);
            renderScanlinesAndBars(guiGraphics, screenWidth, screenHeight, progress, horrorIntensity, photosensitive, transitionPhaseId >= EchoPhase.CHAOS.getId(), rng);
            return;
        }

        // 4. Proximity scanlines within 12 blocks of Echo in GLITCH+
        EchoPhase phase = PhaseManager.getClientCachedPhase();
        if (phase.getId() < EchoPhase.GLITCH.getId()) {
            return;
        }

        AABB searchBox = player.getBoundingBox().inflate(MAX_GLITCH_OVERLAY_DISTANCE);
        List<EchoEntity> nearbyEchoes = mc.level.getEntitiesOfClass(
                EchoEntity.class,
                searchBox,
                e -> e.isAlive() && !e.isPurified() && e.getPhase().getId() >= EchoPhase.GLITCH.getId()
        );
        if (nearbyEchoes.isEmpty()) {
            return;
        }

        double minDistance = MAX_GLITCH_OVERLAY_DISTANCE;
        for (EchoEntity echo : nearbyEchoes) {
            double dist = player.distanceTo(echo);
            if (dist < minDistance) {
                minDistance = dist;
            }
        }
        if (minDistance > MAX_GLITCH_OVERLAY_DISTANCE) {
            return;
        }

        float proximity = (float) Math.max(0.0D, (MAX_GLITCH_OVERLAY_DISTANCE - minDistance) / MAX_GLITCH_OVERLAY_DISTANCE);
        boolean isChaosOrHigher = phase.getId() >= EchoPhase.CHAOS.getId();

        renderScanlinesAndBars(guiGraphics, screenWidth, screenHeight, proximity, horrorIntensity, photosensitive, isChaosOrHigher, rng);
    }

    private static void renderMissionHudLine(Font font, GuiGraphics guiGraphics, int screenWidth) {
        int activeId = MissionManager.getClientActiveMissionId();
        Component text = (activeId >= 1 && activeId <= MissionManager.TOTAL_MISSIONS)
                ? Component.translatable("hud.echocat.mission_active", activeId, Component.translatable("mission.echocat." + activeId + ".title"))
                : Component.translatable("hud.echocat.mission_boss");

        int w = font.width(text) + 10;
        int x = screenWidth - w - 8;
        int y = 8;
        guiGraphics.fill(x, y, x + w, y + 14, 0x88120C14);
        guiGraphics.drawString(font, text, x + 5, y + 3, 0xFFFFDF99, true);
    }

    private static void renderJumpscareFrame(GuiGraphics guiGraphics, int screenWidth, int screenHeight) {
        // Dark crimson vignette + glowing silhouette eyes in center
        guiGraphics.fill(0, 0, screenWidth, screenHeight, 0x88240206);
        int cx = screenWidth / 2;
        int cy = screenHeight / 2 - 12;
        guiGraphics.fill(cx - 28, cy - 8, cx - 12, cy + 8, 0xFFFF1828);
        guiGraphics.fill(cx + 12, cy - 8, cx + 28, cy + 8, 0xFFFF1828);
    }

    private static void renderScanlinesAndBars(
            GuiGraphics guiGraphics,
            int screenWidth,
            int screenHeight,
            float strength,
            int horrorIntensity,
            boolean photosensitive,
            boolean crimsonTint,
            Random rng
    ) {
        float scaledStrength = strength * (0.45F + 0.25F * horrorIntensity);
        if (photosensitive) {
            scaledStrength *= 0.35F;
        }

        int tintAlpha = Math.min(photosensitive ? 22 : 55, (int) (scaledStrength * 42.0F));
        if (tintAlpha > 2) {
            int topBottomColor = crimsonTint
                    ? ((tintAlpha << 24) | 0x4A040A)
                    : ((tintAlpha << 24) | 0x082A38);
            int bandHeight = Math.max(12, screenHeight / 8);
            guiGraphics.fill(0, 0, screenWidth, bandHeight, topBottomColor);
            guiGraphics.fill(0, screenHeight - bandHeight, screenWidth, screenHeight, topBottomColor);
        }

        int scanlineSpacing = photosensitive ? 8 : 4;
        int scanlineAlpha = Math.min(photosensitive ? 18 : 44, (int) (scaledStrength * 34.0F));
        if (scanlineAlpha > 2) {
            int scanlineColor = (scanlineAlpha << 24) | 0x050508;
            for (int y = 0; y < screenHeight; y += scanlineSpacing) {
                guiGraphics.fill(0, y, screenWidth, y + 1, scanlineColor);
            }
        }

        int barCount = photosensitive ? 2 : (2 + horrorIntensity * 2);
        int barAlpha = Math.min(photosensitive ? 24 : 68, (int) (scaledStrength * 52.0F));
        if (barAlpha > 3) {
            int cyanBar = (barAlpha << 24) | 0x00E5FF;
            int redBar = (barAlpha << 24) | 0xFF1E56;

            for (int i = 0; i < barCount; i++) {
                if (rng.nextFloat() > (photosensitive ? 0.55F : 0.80F)) {
                    continue;
                }
                int barY = rng.nextInt(Math.max(1, screenHeight - 12));
                int barH = 2 + rng.nextInt(photosensitive ? 4 : 10);
                int barW = (screenWidth / 4) + rng.nextInt(Math.max(1, (screenWidth * 3) / 4));
                int barX = rng.nextInt(Math.max(1, screenWidth - barW / 2));

                int color = (i % 2 == 0) ? cyanBar : redBar;
                guiGraphics.fill(barX, barY, Math.min(screenWidth, barX + barW), Math.min(screenHeight, barY + barH), color);
            }
        }
    }
}
