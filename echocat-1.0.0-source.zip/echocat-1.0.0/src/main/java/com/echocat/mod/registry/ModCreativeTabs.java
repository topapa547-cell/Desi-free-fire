package com.echocat.mod.registry;

import com.echocat.mod.EchoCatMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> CREATIVE_MODE_TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, EchoCatMod.MOD_ID);

    public static final RegistryObject<CreativeModeTab> ECHO_TAB = CREATIVE_MODE_TABS.register(
            "echo_tab",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.echocat.echo_tab"))
                    .icon(() -> new ItemStack(ModItems.ECHO_PLUSH_SUMMONER.get()))
                    .displayItems((parameters, output) -> {
                        output.accept(ModItems.ECHO_PLUSH_SUMMONER.get());
                        output.accept(ModItems.PURIFIED_ECHO_PLUSH.get());
                        output.accept(ModItems.ECHO_JOURNAL.get());
                        output.accept(ModItems.ECHO_CIRCUIT.get());
                        output.accept(ModItems.GLITCH_SHARD.get());
                        output.accept(ModItems.CORRUPTED_CORE.get());
                        output.accept(ModItems.RED_CRYSTAL.get());
                        output.accept(ModItems.REMOTE_CASING.get());
                        output.accept(ModItems.THE_REMOTE.get());
                        output.accept(ModItems.ECHO_HEART.get());
                        output.accept(ModItems.STATIC_BLOCK_ITEM.get());
                        output.accept(ModItems.RED_CRYSTAL_ORE_ITEM.get());
                    })
                    .build()
    );

    private ModCreativeTabs() {
    }

    public static void register(IEventBus eventBus) {
        CREATIVE_MODE_TABS.register(eventBus);
    }
}
