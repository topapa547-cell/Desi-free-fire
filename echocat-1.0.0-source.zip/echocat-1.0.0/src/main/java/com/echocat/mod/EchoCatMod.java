package com.echocat.mod;

import com.echocat.mod.ai.HttpAIService;
import com.echocat.mod.chaos.ChaosCorruptionHandler;
import com.echocat.mod.chat.ChatRepeatHandler;
import com.echocat.mod.command.EchoCommands;
import com.echocat.mod.config.EchoConfig;
import com.echocat.mod.entity.EchoEntity;
import com.echocat.mod.mission.MissionManager;
import com.echocat.mod.network.ModNetwork;
import com.echocat.mod.phase.PhaseManager;
import com.echocat.mod.phase.PhaseTransitionListener;
import com.echocat.mod.registry.ModBlocks;
import com.echocat.mod.registry.ModCreativeTabs;
import com.echocat.mod.registry.ModEntities;
import com.echocat.mod.registry.ModItems;
import com.echocat.mod.registry.ModLootModifiers;
import com.echocat.mod.registry.ModSounds;
import com.mojang.logging.LogUtils;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;
import software.bernie.geckolib.GeckoLib;

@Mod(EchoCatMod.MOD_ID)
public class EchoCatMod {
    public static final String MOD_ID = "echocat";
    public static final Logger LOGGER = LogUtils.getLogger();

    public EchoCatMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        GeckoLib.initialize();

        ModBlocks.register(modEventBus);
        ModItems.register(modEventBus);
        ModEntities.register(modEventBus);
        ModSounds.register(modEventBus);
        ModCreativeTabs.register(modEventBus);
        ModLootModifiers.register(modEventBus);

        modEventBus.addListener(this::commonSetup);
        modEventBus.addListener(this::registerAttributes);

        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, EchoConfig.COMMON_SPEC, "echocat-common.toml");
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, EchoConfig.CLIENT_SPEC, "echocat-client.toml");

        MinecraftForge.EVENT_BUS.register(this);
        MinecraftForge.EVENT_BUS.register(new ChatRepeatHandler());
        MinecraftForge.EVENT_BUS.register(new ChaosCorruptionHandler());
        MinecraftForge.EVENT_BUS.register(new PhaseTransitionListener());
        MinecraftForge.EVENT_BUS.register(new MissionManager());

        LOGGER.info("Echo: The Talking Cat (v0.4.0 - Phase 4 Red, Boss, Missions & The Remote) initialized.");
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(ModNetwork::register);
    }

    private void registerAttributes(final EntityAttributeCreationEvent event) {
        event.put(ModEntities.ECHO.get(), EchoEntity.createAttributes().build());
    }

    @SubscribeEvent
    public void onRegisterCommands(final RegisterCommandsEvent event) {
        EchoCommands.register(event.getDispatcher());
    }

    @SubscribeEvent
    public void onPlayerLoggedIn(final PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer serverPlayer) {
            PhaseManager.syncToClient(serverPlayer, PhaseManager.getPhase(serverPlayer));
            MissionManager.syncToClient(serverPlayer);
        }
    }

    @SubscribeEvent
    public void onPlayerChangedDimension(final PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer serverPlayer) {
            PhaseManager.syncToClient(serverPlayer, PhaseManager.getPhase(serverPlayer));
            MissionManager.syncToClient(serverPlayer);
        }
    }

    @SubscribeEvent
    public void onServerStopping(final ServerStoppingEvent event) {
        ChatRepeatHandler.clearQueues();
        ChaosCorruptionHandler.clearAllActive();
        HttpAIService.INSTANCE.clearRateLimitCache();
    }

    @SubscribeEvent
    public void onPlayerRespawn(final PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer serverPlayer) {
            PhaseManager.syncToClient(serverPlayer, PhaseManager.getPhase(serverPlayer));
            MissionManager.syncToClient(serverPlayer);
        }
    }
}
