package com.echocat.mod.client;

import com.echocat.mod.mission.MissionManager;
import com.echocat.mod.phase.EchoPhase;
import com.echocat.mod.phase.PhaseManager;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

/**
 * Client GUI Screen opened by "Echo's Journal" (`echocat:echo_journal`).
 * Displays the player's current EchoPhase, active mission objective, survival hint,
 * and the 5-mission progression checklist.
 */
@OnlyIn(Dist.CLIENT)
public class EchoJournalScreen extends Screen {
    public EchoJournalScreen() {
        super(Component.translatable("screen.echocat.journal.title"));
    }

    @Override
    protected void init() {
        super.init();
        int btnWidth = 100;
        int btnX = (this.width - btnWidth) / 2;
        int btnY = this.height - 32;
        this.addRenderableWidget(
                Button.builder(Component.translatable("gui.done"), btn -> this.onClose())
                        .bounds(btnX, btnY, btnWidth, 20)
                        .build()
        );
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(guiGraphics);

        int panelW = 280;
        int panelH = 195;
        int x0 = (this.width - panelW) / 2;
        int y0 = (this.height - panelH) / 2 - 8;

        // Parchment-tinted dark journal panel with golden border
        guiGraphics.fill(x0 - 2, y0 - 2, x0 + panelW + 2, y0 + panelH + 2, 0xFFD4A44C);
        guiGraphics.fill(x0, y0, x0 + panelW, y0 + panelH, 0xEE181216);

        guiGraphics.drawCenteredString(this.font, this.title, this.width / 2, y0 + 10, 0xFFFFD87A);

        EchoPhase currentPhase = PhaseManager.getClientCachedPhase();
        Component phaseLine = Component.translatable(
                "screen.echocat.journal.current_phase",
                currentPhase.getId(),
                currentPhase.getDisplayComponent()
        );
        guiGraphics.drawString(this.font, phaseLine, x0 + 14, y0 + 28, 0xFF80E8FF, true);

        int activeMission = MissionManager.getClientActiveMissionId();
        int textY = y0 + 46;
        if (activeMission >= 1 && activeMission <= MissionManager.TOTAL_MISSIONS) {
            Component activeHeader = Component.translatable("screen.echocat.journal.active_header", activeMission)
                    .withStyle(ChatFormatting.GOLD);
            Component activeGoal = Component.translatable("mission.echocat." + activeMission + ".title")
                    .withStyle(ChatFormatting.WHITE);
            Component activeHint = Component.translatable("mission.echocat." + activeMission + ".hint")
                    .withStyle(ChatFormatting.GRAY);

            guiGraphics.drawString(this.font, activeHeader, x0 + 14, textY, 0xFFFFAA00, true);
            guiGraphics.drawString(this.font, activeGoal, x0 + 14, textY + 12, 0xFFFFFFFF, true);
            guiGraphics.drawString(this.font, activeHint, x0 + 14, textY + 24, 0xFFBBBBBB, false);
        } else {
            Component finalGoal = Component.translatable("mission.echocat.final_boss.title")
                    .withStyle(ChatFormatting.RED);
            Component finalHint = Component.translatable("mission.echocat.final_boss.hint")
                    .withStyle(ChatFormatting.GRAY);
            guiGraphics.drawString(this.font, finalGoal, x0 + 14, textY + 6, 0xFFFF4444, true);
            guiGraphics.drawString(this.font, finalHint, x0 + 14, textY + 20, 0xFFBBBBBB, false);
        }

        // Completed missions checklist
        int listY = y0 + 92;
        guiGraphics.drawString(
                this.font,
                Component.translatable("screen.echocat.journal.checklist"),
                x0 + 14,
                listY,
                0xFFE0C088,
                true
        );

        for (int m = 1; m <= MissionManager.TOTAL_MISSIONS; m++) {
            boolean done = MissionManager.isClientMissionCompleted(m) || (activeMission == 0) || (m < activeMission);
            String prefix = done ? "[x] " : "[ ] ";
            int color = done ? 0xFF55FF55 : (m == activeMission ? 0xFFFFFF55 : 0xFF888888);
            Component line = Component.literal(prefix).append(Component.translatable("mission.echocat." + m + ".title"));
            guiGraphics.drawString(this.font, line, x0 + 18, listY + 14 + (m - 1) * 14, color, false);
        }

        super.render(guiGraphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
