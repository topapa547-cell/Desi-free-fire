package com.echocat.mod.gametest;

import com.echocat.mod.EchoCatMod;
import com.echocat.mod.ai.AiContentFilter;
import com.echocat.mod.chat.ChatRepeatHandler;
import com.echocat.mod.entity.EchoEntity;
import com.echocat.mod.mission.PlayerMissionData;
import com.echocat.mod.phase.EchoPhase;
import com.echocat.mod.phase.PlayerPhaseData;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.gametest.GameTestHolder;
import net.minecraftforge.gametest.PrefixGameTestTemplate;

import java.util.UUID;

/**
 * Automated Forge GameTests (`runGameTestServer`) verifying core EchoCat invariants.
 */
@GameTestHolder(EchoCatMod.MOD_ID)
@PrefixGameTestTemplate(false)
public final class EchoGameTests {
    private EchoGameTests() {
    }

    @GameTest(template = "empty")
    public static void testPhaseEnumTransitions(GameTestHelper helper) {
        if (EchoPhase.CUTE.next() != EchoPhase.WEIRD) {
            helper.fail("Expected CUTE.next() == WEIRD");
            return;
        }
        if (EchoPhase.HORROR_FINAL.next() != EchoPhase.HORROR_FINAL) {
            helper.fail("Expected HORROR_FINAL.next() to clamp at HORROR_FINAL");
            return;
        }
        if (EchoPhase.CUTE.previous() != EchoPhase.CUTE) {
            helper.fail("Expected CUTE.previous() to clamp at CUTE");
            return;
        }
        helper.succeed();
    }

    @GameTest(template = "empty")
    public static void testDataVersionNbtRoundTrip(GameTestHelper helper) {
        UUID testPlayer = UUID.randomUUID();
        PlayerPhaseData phaseData = new PlayerPhaseData();
        phaseData.setPhase(testPlayer, EchoPhase.RED);

        CompoundTag savedPhaseTag = phaseData.save(new CompoundTag());
        PlayerPhaseData loadedPhaseData = PlayerPhaseData.load(savedPhaseTag);

        if (loadedPhaseData.getDataVersion() != PlayerPhaseData.CURRENT_DATA_VERSION
                || loadedPhaseData.getPhase(testPlayer) != EchoPhase.RED) {
            helper.fail("PlayerPhaseData NBT round-trip failed");
            return;
        }

        PlayerMissionData missionData = new PlayerMissionData();
        missionData.markMissionCompleted(testPlayer, 1);
        missionData.markMissionCompleted(testPlayer, 2);

        CompoundTag savedMissionTag = missionData.save(new CompoundTag());
        PlayerMissionData loadedMissionData = PlayerMissionData.load(savedMissionTag);

        if (loadedMissionData.getDataVersion() != PlayerMissionData.CURRENT_DATA_VERSION
                || !loadedMissionData.isMissionCompleted(testPlayer, 1)
                || !loadedMissionData.isMissionCompleted(testPlayer, 2)
                || loadedMissionData.isMissionCompleted(testPlayer, 3)) {
            helper.fail("PlayerMissionData NBT round-trip failed");
            return;
        }

        helper.succeed();
    }

    @GameTest(template = "empty")
    public static void testAiContentFilterAndSanitizer(GameTestHelper helper) {
        if (!AiContentFilter.isSafeAiOutput("why did you leave me alone")) {
            helper.fail("Safe atmospheric line was erroneously blocked");
            return;
        }
        if (AiContentFilter.isSafeAiOutput("visit https://malicious.com now")) {
            helper.fail("URL should be blocked by AiContentFilter");
            return;
        }
        if (AiContentFilter.isSafeAiOutput("i know your address in real life")) {
            helper.fail("Real-world threat/personal data phrase should be blocked");
            return;
        }
        if (!ChatRepeatHandler.sanitizePlayerMessage("/op player").isEmpty()) {
            helper.fail("Slash commands must be ignored by ChatRepeatHandler");
            return;
        }
        if (EchoEntity.CURRENT_ENTITY_DATA_VERSION != 1) {
            helper.fail("Unexpected entity data version");
            return;
        }
        helper.succeed();
    }
}
