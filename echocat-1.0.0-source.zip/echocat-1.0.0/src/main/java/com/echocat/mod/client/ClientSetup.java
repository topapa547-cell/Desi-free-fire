package com.echocat.mod.client;

import com.echocat.mod.EchoCatMod;
import com.echocat.mod.client.voice.VoiceInputHandler;
import com.echocat.mod.registry.ModEntities;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

/**
 * Client-only mod bus event subscriber for registering GeckoLib entity renderers,
 * push-to-talk keybindings (V key under category "Echo"), the recording HUD overlay,
 * and the Phase 3+ screen glitch scanline overlay.
 */
@Mod.EventBusSubscriber(modid = EchoCatMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {
    private ClientSetup() {
    }

    @SubscribeEvent
    public static void onClientSetup(final FMLClientSetupEvent event) {
        MinecraftForge.EVENT_BUS.register(VoiceInputHandler.INSTANCE);
    }

    @SubscribeEvent
    public static void registerRenderers(final EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.ECHO.get(), EchoRenderer::new);
    }

    @SubscribeEvent
    public static void registerKeyMappings(final RegisterKeyMappingsEvent event) {
        event.register(VoiceInputHandler.PUSH_TO_TALK_KEY);
        event.register(VoiceInputHandler.CALM_ECHO_KEY);
    }

    @SubscribeEvent
    public static void registerGuiOverlays(final RegisterGuiOverlaysEvent event) {
        event.registerAboveAll("echo_glitch_overlay", GlitchOverlayRenderer::renderGlitchOverlay);
        event.registerAboveAll("echo_voice_indicator", VoiceInputHandler::renderRecordingHud);
    }
}
