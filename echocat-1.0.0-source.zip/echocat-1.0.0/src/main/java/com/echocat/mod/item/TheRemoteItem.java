package com.echocat.mod.item;

import com.echocat.mod.config.EchoConfig;
import com.echocat.mod.entity.EchoEntity;
import com.echocat.mod.phase.EchoPhase;
import com.echocat.mod.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * "The Remote" — crafted from all 5 mission components.
 * - Not consumed on use.
 * - When used within 8 blocks of Echo during its 3-second 5th-attack Overload telegraph window:
 *   stuns Echo for {@code stunDuration} seconds (default 12s), multiplies damage taken by Echo by 3x,
 *   resets the boss attack counter, and applies a {@code remoteCooldown} (default 20s).
 * - When used outside the telegraph window: plays a click sound and tells the player "Not yet..."
 *   without consuming the 20s cooldown.
 */
public class TheRemoteItem extends Item {
    public static final double MAX_COUNTER_DISTANCE = 8.0D;

    public TheRemoteItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand usedHand) {
        ItemStack stack = player.getItemInHand(usedHand);
        if (level.isClientSide) {
            return InteractionResultHolder.success(stack);
        }

        if (player.getCooldowns().isOnCooldown(this)) {
            return InteractionResultHolder.fail(stack);
        }

        AABB searchBox = player.getBoundingBox().inflate(MAX_COUNTER_DISTANCE);
        List<EchoEntity> nearbyEchoes = level.getEntitiesOfClass(
                EchoEntity.class,
                searchBox,
                e -> e.isAlive() && player.distanceTo(e) <= MAX_COUNTER_DISTANCE
        );

        for (EchoEntity echo : nearbyEchoes) {
            if (echo.getPhase() == EchoPhase.HORROR_FINAL && echo.isOverloadCharging()) {
                echo.triggerRemoteCounterStun(player);
                int cooldownTicks = EchoConfig.COMMON.remoteCooldown.get() * 20;
                player.getCooldowns().addCooldown(this, cooldownTicks);
                return InteractionResultHolder.consume(stack);
            }
        }

        // Used outside the overload telegraph window
        level.playSound(null, player.blockPosition(), SoundEvents.DISPENSER_FAIL, SoundSource.PLAYERS, 0.7F, 1.2F);
        player.displayClientMessage(
                Component.translatable("message.echocat.remote.not_yet").withStyle(ChatFormatting.YELLOW),
                true
        );
        return InteractionResultHolder.pass(stack);
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity interactionTarget, InteractionHand usedHand) {
        if (interactionTarget instanceof EchoEntity) {
            InteractionResultHolder<ItemStack> result = this.use(player.level(), player, usedHand);
            return result.getResult();
        }
        return super.interactLivingEntity(stack, player, interactionTarget, usedHand);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltipComponents, TooltipFlag isAdvanced) {
        tooltipComponents.add(Component.translatable("item.echocat.the_remote.desc").withStyle(ChatFormatting.GRAY));
        tooltipComponents.add(Component.translatable("item.echocat.the_remote.hint").withStyle(ChatFormatting.AQUA));
    }
}
