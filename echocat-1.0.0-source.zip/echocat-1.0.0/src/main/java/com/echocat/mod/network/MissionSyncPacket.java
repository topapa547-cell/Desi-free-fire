package com.echocat.mod.network;

import com.echocat.mod.client.ClientPacketHandlers;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Server -> Client packet syncing the bitmask of completed missions (bits 1..5)
 * so Echo's Journal screen and the optional Mission HUD always display accurate state.
 */
public class MissionSyncPacket {
    private final int completedMask;

    public MissionSyncPacket(int completedMask) {
        this.completedMask = completedMask;
    }

    public int getCompletedMask() {
        return this.completedMask;
    }

    public static void encode(MissionSyncPacket packet, FriendlyByteBuf buf) {
        buf.writeVarInt(packet.completedMask);
    }

    public static MissionSyncPacket decode(FriendlyByteBuf buf) {
        return new MissionSyncPacket(buf.readVarInt());
    }

    public static void handle(MissionSyncPacket packet, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPacketHandlers.handleMissionSync(packet))
        );
        context.setPacketHandled(true);
    }
}
