package com.echocat.mod.client;

import com.echocat.mod.config.EchoConfig;
import com.echocat.mod.entity.EchoEntity;
import com.echocat.mod.phase.EchoPhase;
import com.echocat.mod.util.EchoConstants;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import software.bernie.geckolib.constant.DataTickets;
import software.bernie.geckolib.core.animatable.model.CoreGeoBone;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.model.data.EntityModelData;

/**
 * GeckoLib 4 GeoModel for Echo: The Talking Cat (v0.4.0).
 * Dynamically switches between the cute model (`echo.geo.json`) and the 2.4-block horror model
 * (`echo_horror.geo.json`) as `redProgress` crosses 0.5 -> 0.9 in Phase 5 (RED) and in Phase 6 (`HORROR_FINAL`).
 */
public class EchoModel extends GeoModel<EchoEntity> {
    private static final ResourceLocation CUTE_MODEL =
            EchoConstants.rl("geo/entity/echo.geo.json");
    private static final ResourceLocation CUTE_ANIMATION =
            EchoConstants.rl("animations/entity/echo.animation.json");

    private static final ResourceLocation HORROR_MODEL =
            EchoConstants.rl("geo/entity/echo_horror.geo.json");
    private static final ResourceLocation HORROR_ANIMATION =
            EchoConstants.rl("animations/entity/echo_horror.animation.json");

    @Override
    public ResourceLocation getModelResource(EchoEntity animatable) {
        boolean photosensitive = EchoConfig.CLIENT.photosensitiveMode.get();
        if (animatable.shouldRenderHorrorModel(photosensitive)) {
            return HORROR_MODEL;
        }
        return CUTE_MODEL;
    }

    @Override
    public ResourceLocation getTextureResource(EchoEntity animatable) {
        boolean photosensitive = EchoConfig.CLIENT.photosensitiveMode.get();
        if (animatable.shouldRenderHorrorModel(photosensitive)) {
            return EchoPhase.HORROR_FINAL.getTextureLocation();
        }

        EchoPhase phase = animatable.getPhase();
        if (phase.getId() >= EchoPhase.GLITCH.getId()) {
            long bucket = photosensitive
                    ? (System.currentTimeMillis() / 500L)
                    : (System.currentTimeMillis() / 90L);
            long hash = (bucket * 2654435761L) ^ animatable.getId();
            if (Math.floorMod(hash, 11) < 2) {
                return EchoPhase.CUTE.getTextureLocation();
            }
        }
        return phase.getTextureLocation();
    }

    @Override
    public ResourceLocation getAnimationResource(EchoEntity animatable) {
        boolean photosensitive = EchoConfig.CLIENT.photosensitiveMode.get();
        if (animatable.shouldRenderHorrorModel(photosensitive)) {
            return HORROR_ANIMATION;
        }
        return CUTE_ANIMATION;
    }

    @Override
    public void setCustomAnimations(EchoEntity animatable, long instanceId, AnimationState<EchoEntity> animationState) {
        super.setCustomAnimations(animatable, instanceId, animationState);

        CoreGeoBone head = getAnimationProcessor().getBone("head");
        if (head != null) {
            EntityModelData entityData = animationState.getData(DataTickets.ENTITY_MODEL_DATA);
            if (entityData != null) {
                head.setRotX(entityData.headPitch() * Mth.DEG_TO_RAD);
                head.setRotY(entityData.netHeadYaw() * Mth.DEG_TO_RAD);
            }
        }

        EchoPhase phase = animatable.getPhase();
        if (phase.getId() >= EchoPhase.GLITCH.getId() && !animatable.isPurified()) {
            applyGlitchBoneJitter(animatable, head);
        }
    }

    private void applyGlitchBoneJitter(EchoEntity animatable, CoreGeoBone head) {
        boolean photosensitive = EchoConfig.CLIENT.photosensitiveMode.get();
        int intensity = Math.max(1, Math.min(3, EchoConfig.COMMON.horrorIntensity.get()));

        long bucket = photosensitive
                ? (System.currentTimeMillis() / 500L)
                : (System.currentTimeMillis() / 70L);
        long seed = (bucket * 1103515245L + 12345L) ^ animatable.getId();

        if (Math.floorMod(seed, 10) >= 3) {
            return;
        }

        float scale = (photosensitive ? 0.06F : 0.16F) * (0.6F + 0.25F * intensity);
        float jitterX = (((seed >> 4) & 0x7) - 3.5F) * scale * 0.25F;
        float jitterZ = (((seed >> 8) & 0x7) - 3.5F) * scale * 0.35F;

        if (head != null) {
            head.setRotZ(jitterZ);
            head.setRotX(head.getRotX() + jitterX * 0.5F);
        }

        CoreGeoBone earLeft = getAnimationProcessor().getBone("ear_left");
        if (earLeft != null) {
            earLeft.setRotZ(jitterX * 0.8F);
        }

        CoreGeoBone earRight = getAnimationProcessor().getBone("ear_right");
        if (earRight != null) {
            earRight.setRotZ(-jitterZ * 0.8F);
        }
    }
}
