package com.echocat.mod.item;

import com.echocat.mod.config.EchoConfig;
import com.echocat.mod.entity.EchoEntity;
import com.echocat.mod.phase.EchoPhase;
import com.echocat.mod.phase.PhaseManager;
import com.echocat.mod.registry.ModEntities;
import com.echocat.mod.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * Reward item dropped upon defeating the Phase 6 HORROR_FINAL boss.
 * Summons a permanently CUTE, friendly Echo companion (`setPurified(true)`) that never
 * enters horror phases, while still repeating player chat and voice messages.
 */
public class PurifiedEchoPlushItem extends Item {
    public PurifiedEchoPlushItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        if (!(level instanceof ServerLevel serverLevel)) {
            return InteractionResult.SUCCESS;
        }

        Player player = context.getPlayer();
        if (player == null) {
            return InteractionResult.PASS;
        }

        if (!EchoConfig.COMMON.enablePurifiedPlush.get()) {
            player.sendSystemMessage(
                    Component.translatable("message.echocat.purified_disabled").withStyle(ChatFormatting.RED)
            );
            return InteractionResult.FAIL;
        }

        List<EchoEntity> existing = PhaseManager.findPlayerEchoEntities(serverLevel.getServer(), player.getUUID());
        if (!existing.isEmpty()) {
            player.sendSystemMessage(
                    Component.translatable("message.echocat.already_summoned").withStyle(ChatFormatting.RED)
            );
            return InteractionResult.FAIL;
        }

        BlockPos clickedPos = context.getClickedPos();
        Direction face = context.getClickedFace();
        BlockState clickedState = level.getBlockState(clickedPos);
        BlockPos spawnPos = clickedState.getCollisionShape(level, clickedPos).isEmpty()
                ? clickedPos
                : clickedPos.relative(face);

        EchoEntity echo = ModEntities.ECHO.get().create(serverLevel);
        if (echo == null) {
            return InteractionResult.FAIL;
        }

        echo.moveTo(
                spawnPos.getX() + 0.5D,
                spawnPos.getY(),
                spawnPos.getZ() + 0.5D,
                player.getYRot(),
                0.0F
        );
        echo.tame(player);
        echo.setOrderedToSit(false);
        echo.setInSittingPose(false);
        echo.setPersistenceRequired();
        echo.setPurified(true);
        echo.setPhase(EchoPhase.CUTE);

        PhaseManager.setPhase(player, EchoPhase.CUTE);

        serverLevel.addFreshEntity(echo);
        serverLevel.playSound(null, spawnPos, ModSounds.ECHO_PURR.get(), SoundSource.NEUTRAL, 1.0F, 1.15F);

        player.sendSystemMessage(
                Component.translatable("message.echocat.purified_summoned").withStyle(ChatFormatting.AQUA)
        );

        ItemStack itemStack = context.getItemInHand();
        if (!player.getAbilities().instabuild) {
            itemStack.shrink(1);
        }

        return InteractionResult.CONSUME;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltipComponents, TooltipFlag isAdvanced) {
        tooltipComponents.add(
                Component.translatable("item.echocat.purified_echo_plush.desc").withStyle(ChatFormatting.AQUA)
        );
    }
}
