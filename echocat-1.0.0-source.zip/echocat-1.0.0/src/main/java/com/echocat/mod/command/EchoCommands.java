package com.echocat.mod.command;

import com.echocat.mod.chaos.ChaosCorruptionHandler;
import com.echocat.mod.entity.EchoEntity;
import com.echocat.mod.mission.MissionManager;
import com.echocat.mod.phase.EchoPhase;
import com.echocat.mod.phase.PhaseManager;
import com.echocat.mod.registry.ModItems;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.List;
import java.util.Locale;

/**
 * Registers commands for Echo: The Talking Cat (v1.0.0):
 * - `/echo calm` (permission level 0 — ANY player can use this panic button on their own Echo!)
 * - Operator commands (permission level 2):
 *   - `/echo phase get`
 *   - `/echo phase set <1-6>`
 *   - `/echo phase next`
 *   - `/echo mission complete <1-5>`
 *   - `/echo mission list`
 *   - `/echo give <item|all>`
 *   - `/echo debug corrupted`
 *   - `/echo summon`
 *   - `/echo reset`
 */
public final class EchoCommands {
    private EchoCommands() {
    }

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(
                Commands.literal("echo")
                        // Panic button usable by ANY player (permission level 0)
                        .then(Commands.literal("calm")
                                .executes(EchoCommands::calmEchoCommand))
                        // Operator subcommands (permission level 2)
                        .then(Commands.literal("phase")
                                .requires(source -> source.hasPermission(2))
                                .then(Commands.literal("get")
                                        .executes(EchoCommands::getPhase))
                                .then(Commands.literal("set")
                                        .then(Commands.argument("level", IntegerArgumentType.integer(1, 6))
                                                .executes(EchoCommands::setPhase)))
                                .then(Commands.literal("next")
                                        .executes(EchoCommands::nextPhase)))
                        .then(Commands.literal("mission")
                                .requires(source -> source.hasPermission(2))
                                .then(Commands.literal("complete")
                                        .then(Commands.argument("id", IntegerArgumentType.integer(1, 5))
                                                .executes(EchoCommands::completeMission)))
                                .then(Commands.literal("list")
                                        .executes(EchoCommands::listMissions)))
                        .then(Commands.literal("give")
                                .requires(source -> source.hasPermission(2))
                                .then(Commands.argument("item", StringArgumentType.word())
                                        .executes(EchoCommands::giveItem)))
                        .then(Commands.literal("debug")
                                .requires(source -> source.hasPermission(2))
                                .then(Commands.literal("corrupted")
                                        .executes(EchoCommands::debugCorrupted)))
                        .then(Commands.literal("summon")
                                .requires(source -> source.hasPermission(2))
                                .executes(EchoCommands::giveSummoner))
                        .then(Commands.literal("reset")
                                .requires(source -> source.hasPermission(2))
                                .executes(EchoCommands::resetEcho))
        );
    }

    private static int calmEchoCommand(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = ctx.getSource().getPlayerOrException();
        executeCalmForPlayer(player);
        return 1;
    }

    /**
     * Shared panic-button implementation invoked by `/echo calm` or `CalmEchoPacket` (`K` keybind).
     * Immediately returns the player's Echo to a harmless Phase 1 (CUTE) state for the session,
     * uncorrupts all mobs affected by their Echo, and hides any active boss bar.
     */
    public static void executeCalmForPlayer(ServerPlayer player) {
        if (player == null || player.server == null) {
            return;
        }
        ChaosCorruptionHandler.restoreAllForOwner(player.getUUID());
        PhaseManager.setPhase(player, EchoPhase.CUTE);

        List<EchoEntity> echoes = PhaseManager.findPlayerEchoEntities(player.server, player.getUUID());
        for (EchoEntity echo : echoes) {
            echo.calmToCuteState();
        }

        player.sendSystemMessage(
                Component.translatable("command.echocat.calm.success").withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD)
        );
    }

    private static int getPhase(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = ctx.getSource().getPlayerOrException();
        EchoPhase phase = PhaseManager.getPhase(player);
        ctx.getSource().sendSuccess(
                () -> Component.translatable("command.echocat.phase.get", phase.getId(), phase.getDisplayComponent())
                        .withStyle(ChatFormatting.AQUA),
                false
        );
        return phase.getId();
    }

    private static int setPhase(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = ctx.getSource().getPlayerOrException();
        int level = IntegerArgumentType.getInteger(ctx, "level");
        EchoPhase phase = EchoPhase.byId(level);
        PhaseManager.setPhase(player, phase);

        ctx.getSource().sendSuccess(
                () -> Component.translatable("command.echocat.phase.set", phase.getId(), phase.getDisplayComponent())
                        .withStyle(ChatFormatting.GREEN),
                true
        );
        return 1;
    }

    private static int nextPhase(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = ctx.getSource().getPlayerOrException();
        EchoPhase next = PhaseManager.advance(player);

        ctx.getSource().sendSuccess(
                () -> Component.translatable("command.echocat.phase.next", next.getId(), next.getDisplayComponent())
                        .withStyle(ChatFormatting.GOLD),
                true
        );
        return 1;
    }

    private static int completeMission(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = ctx.getSource().getPlayerOrException();
        int missionId = IntegerArgumentType.getInteger(ctx, "id");
        MissionManager.completeMission(player, missionId);
        EchoPhase updatedPhase = PhaseManager.getPhase(player);

        ctx.getSource().sendSuccess(
                () -> Component.translatable(
                        "command.echocat.mission.complete",
                        missionId,
                        updatedPhase.getId(),
                        updatedPhase.getDisplayComponent()
                ).withStyle(ChatFormatting.GREEN),
                true
        );
        return 1;
    }

    private static int listMissions(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = ctx.getSource().getPlayerOrException();
        int activeId = MissionManager.getActiveMissionId(player);

        player.sendSystemMessage(Component.translatable("command.echocat.mission.list_header").withStyle(ChatFormatting.GOLD));
        for (int m = 1; m <= MissionManager.TOTAL_MISSIONS; m++) {
            boolean done = MissionManager.isMissionCompleted(player, m) || (activeId == 0) || (m < activeId);
            String status = done ? "[COMPLETED]" : (m == activeId ? "[ACTIVE]" : "[LOCKED]");
            ChatFormatting color = done ? ChatFormatting.GREEN : (m == activeId ? ChatFormatting.YELLOW : ChatFormatting.GRAY);
            player.sendSystemMessage(
                    Component.literal(" #" + m + " " + status + " - ")
                            .append(Component.translatable("mission.echocat." + m + ".title"))
                            .withStyle(color)
            );
        }
        return 1;
    }

    private static int giveItem(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = ctx.getSource().getPlayerOrException();
        String name = StringArgumentType.getString(ctx, "item").toLowerCase(Locale.ROOT);

        if ("all".equals(name) || "kit".equals(name)) {
            giveStack(player, ModItems.ECHO_CIRCUIT.get());
            giveStack(player, ModItems.GLITCH_SHARD.get());
            giveStack(player, ModItems.CORRUPTED_CORE.get());
            giveStack(player, ModItems.RED_CRYSTAL.get());
            giveStack(player, ModItems.REMOTE_CASING.get());
            giveStack(player, ModItems.THE_REMOTE.get());
            giveStack(player, ModItems.ECHO_JOURNAL.get());
            ctx.getSource().sendSuccess(
                    () -> Component.translatable("command.echocat.give.all").withStyle(ChatFormatting.GREEN),
                    false
            );
            return 1;
        }

        Item target = switch (name) {
            case "echo_circuit", "circuit" -> ModItems.ECHO_CIRCUIT.get();
            case "glitch_shard", "shard" -> ModItems.GLITCH_SHARD.get();
            case "corrupted_core", "core" -> ModItems.CORRUPTED_CORE.get();
            case "red_crystal", "crystal" -> ModItems.RED_CRYSTAL.get();
            case "remote_casing", "casing" -> ModItems.REMOTE_CASING.get();
            case "the_remote", "remote" -> ModItems.THE_REMOTE.get();
            case "echo_journal", "journal" -> ModItems.ECHO_JOURNAL.get();
            case "echo_heart", "heart" -> ModItems.ECHO_HEART.get();
            case "purified_echo_plush", "purified" -> ModItems.PURIFIED_ECHO_PLUSH.get();
            case "static_block" -> ModItems.STATIC_BLOCK_ITEM.get();
            case "red_crystal_ore" -> ModItems.RED_CRYSTAL_ORE_ITEM.get();
            case "echo_plush_summoner", "plush" -> ModItems.ECHO_PLUSH_SUMMONER.get();
            default -> null;
        };

        if (target == null) {
            ctx.getSource().sendSuccess(
                    () -> Component.translatable("command.echocat.give.unknown", name).withStyle(ChatFormatting.RED),
                    false
            );
            return 0;
        }

        giveStack(player, target);
        ctx.getSource().sendSuccess(
                () -> Component.translatable("command.echocat.give.success", new ItemStack(target).getHoverName())
                        .withStyle(ChatFormatting.GREEN),
                false
        );
        return 1;
    }

    private static void giveStack(ServerPlayer player, Item item) {
        ItemStack stack = new ItemStack(item);
        if (!player.getInventory().add(stack)) {
            player.drop(stack, false);
        }
    }

    private static int debugCorrupted(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = ctx.getSource().getPlayerOrException();
        List<Mob> corrupted = ChaosCorruptionHandler.getCorruptedMobsForOwner(player.getUUID());
        int count = corrupted.size();

        ctx.getSource().sendSuccess(
                () -> Component.translatable("command.echocat.debug.corrupted", count)
                        .withStyle(count > 0 ? ChatFormatting.RED : ChatFormatting.GREEN),
                false
        );
        return count;
    }

    private static int giveSummoner(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = ctx.getSource().getPlayerOrException();
        giveStack(player, ModItems.ECHO_PLUSH_SUMMONER.get());

        ctx.getSource().sendSuccess(
                () -> Component.translatable("command.echocat.summon.given").withStyle(ChatFormatting.GREEN),
                false
        );
        return 1;
    }

    private static int resetEcho(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = ctx.getSource().getPlayerOrException();

        ChaosCorruptionHandler.restoreAllForOwner(player.getUUID());

        List<EchoEntity> entities = PhaseManager.findPlayerEchoEntities(player.server, player.getUUID());
        int removedCount = entities.size();
        for (EchoEntity echo : entities) {
            echo.remove(Entity.RemovalReason.DISCARDED);
        }

        MissionManager.resetMissions(player);
        PhaseManager.setPhase(player, EchoPhase.CUTE);

        ctx.getSource().sendSuccess(
                () -> Component.translatable("command.echocat.reset.success", removedCount)
                        .withStyle(ChatFormatting.YELLOW),
                true
        );
        return 1;
    }
}
