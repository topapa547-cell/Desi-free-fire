package com.echocat.mod.chat;

import com.echocat.mod.ai.CreepyContext;
import com.echocat.mod.ai.HttpAIService;
import com.echocat.mod.config.EchoConfig;
import com.echocat.mod.entity.EchoEntity;
import com.echocat.mod.network.EchoSpeechBubblePacket;
import com.echocat.mod.network.ModNetwork;
import com.echocat.mod.phase.EchoPhase;
import com.echocat.mod.phase.PhaseManager;
import com.echocat.mod.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.network.PacketDistributor;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Handles server-side player chat and voice transcript repetition across phases:
 * - Phase 1 (CUTE): exact repetition after 0.5-1.5s delay + 4s floating bubble.
 * - Phase 2 (WEIRD): exact repetition + 35% chance to append an asynchronous creepy line.
 * - Phase 3+ (GLITCH+): applies {@link GlitchTextModifier} (stuttered syllables, char swaps,
 *   occasional §k obfuscation) and plays rapid stuttering audio bursts (`echo_stutter` + `echo_glitch_voice`).
 */
public class ChatRepeatHandler {
    public static final double MAX_LISTEN_DISTANCE = 16.0D;
    public static final double MAX_LISTEN_DISTANCE_SQR = MAX_LISTEN_DISTANCE * MAX_LISTEN_DISTANCE;
    public static final int MAX_MESSAGE_CHARS = 120;
    public static final int BUBBLE_DURATION_TICKS = 80; // 4 seconds

    private static final Map<UUID, Long> PLAYER_COOLDOWNS_MS = new ConcurrentHashMap<>();
    private static final ConcurrentLinkedQueue<ScheduledEchoSpeech> PENDING_SPEECH = new ConcurrentLinkedQueue<>();
    private static final ConcurrentLinkedQueue<ScheduledStutterSound> PENDING_STUTTERS = new ConcurrentLinkedQueue<>();

    private record ScheduledEchoSpeech(
            UUID ownerUuid,
            int echoEntityId,
            String text,
            boolean isCreepyLine,
            long executeAtTick
    ) {}

    private record ScheduledStutterSound(
            UUID ownerUuid,
            int echoEntityId,
            float pitch,
            long executeAtTick
    ) {}

    public static void clearQueues() {
        PLAYER_COOLDOWNS_MS.clear();
        PENDING_SPEECH.clear();
        PENDING_STUTTERS.clear();
    }

    @SubscribeEvent
    public void onServerChat(final ServerChatEvent event) {
        if (!EchoConfig.COMMON.enableChat.get()) {
            return;
        }
        ServerPlayer player = event.getPlayer();
        if (player == null) {
            return;
        }
        handlePlayerUtterance(player, event.getRawText(), false);
    }

    public static void handlePlayerUtterance(ServerPlayer player, String rawInput, boolean fromVoice) {
        if (player == null || player.server == null) {
            return;
        }
        if (fromVoice && !EchoConfig.COMMON.enableVoice.get()) {
            return;
        }
        if (!fromVoice && !EchoConfig.COMMON.enableChat.get()) {
            return;
        }

        String sanitized = sanitizePlayerMessage(rawInput);
        if (sanitized.isEmpty()) {
            return;
        }

        long now = System.currentTimeMillis();
        int cooldownMs = EchoConfig.COMMON.chatCooldownMs.get();
        UUID playerUuid = player.getUUID();
        Long lastUsed = PLAYER_COOLDOWNS_MS.get(playerUuid);
        if (lastUsed != null && (now - lastUsed) < cooldownMs) {
            return;
        }

        EchoEntity nearbyEcho = findNearbyOwnedEcho(player);
        if (nearbyEcho == null) {
            return;
        }

        PLAYER_COOLDOWNS_MS.put(playerUuid, now);

        MinecraftServer server = player.server;
        long currentTick = server.getTickCount();
        int delayTicks = ThreadLocalRandom.current().nextInt(10, 31);
        long repeatTick = currentTick + delayTicks;

        PENDING_SPEECH.add(new ScheduledEchoSpeech(
                playerUuid,
                nearbyEcho.getId(),
                sanitized,
                false,
                repeatTick
        ));

        EchoPhase phase = PhaseManager.getPhase(player);
        if (phase.getId() >= EchoPhase.WEIRD.getId()) {
            double chance = EchoConfig.COMMON.weirdCreepyChance.get();
            if (ThreadLocalRandom.current().nextDouble() < chance) {
                CreepyContext ctx = CreepyContext.fromPlayer(player, sanitized, phase);
                int echoId = nearbyEcho.getId();

                HttpAIService.INSTANCE.generateForPlayer(server, playerUuid, ctx)
                        .thenAccept(creepyLine -> {
                            if (creepyLine == null || creepyLine.isBlank()) {
                                return;
                            }
                            server.execute(() -> {
                                long followUpTick = Math.max(server.getTickCount() + 15, repeatTick + 28);
                                PENDING_SPEECH.add(new ScheduledEchoSpeech(
                                        playerUuid,
                                        echoId,
                                        creepyLine,
                                        true,
                                        followUpTick
                                ));
                            });
                        });
            }
        }
    }

    @SubscribeEvent
    public void onServerTick(final TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        MinecraftServer server = event.getServer();
        if (server == null) {
            return;
        }
        long currentTick = server.getTickCount();

        if (!PENDING_SPEECH.isEmpty()) {
            Iterator<ScheduledEchoSpeech> it = PENDING_SPEECH.iterator();
            while (it.hasNext()) {
                ScheduledEchoSpeech item = it.next();
                if (currentTick >= item.executeAtTick()) {
                    it.remove();
                    deliverEchoSpeech(server, item, currentTick);
                }
            }
        }

        if (!PENDING_STUTTERS.isEmpty()) {
            Iterator<ScheduledStutterSound> sit = PENDING_STUTTERS.iterator();
            while (sit.hasNext()) {
                ScheduledStutterSound s = sit.next();
                if (currentTick >= s.executeAtTick()) {
                    sit.remove();
                    playScheduledStutter(server, s);
                }
            }
        }
    }

    private static void deliverEchoSpeech(MinecraftServer server, ScheduledEchoSpeech speech, long currentTick) {
        ServerPlayer owner = server.getPlayerList().getPlayer(speech.ownerUuid());
        if (owner == null || !owner.isAlive()) {
            return;
        }
        if (!(owner.level().getEntity(speech.echoEntityId()) instanceof EchoEntity echo) || !echo.isAlive()) {
            return;
        }
        if (echo.distanceToSqr(owner) > MAX_LISTEN_DISTANCE_SQR) {
            return;
        }

        EchoPhase phase = PhaseManager.getPhase(owner);
        boolean isGlitchOrHigher = phase.getId() >= EchoPhase.GLITCH.getId();
        int intensity = EchoConfig.COMMON.horrorIntensity.get();

        String chatDisplayText = speech.text();
        String bubbleDisplayText = speech.text();

        if (isGlitchOrHigher) {
            ThreadLocalRandom rng = ThreadLocalRandom.current();
            chatDisplayText = GlitchTextModifier.glitchify(speech.text(), intensity, true, rng);
            bubbleDisplayText = GlitchTextModifier.glitchify(speech.text(), intensity, false, rng);
        }

        int animTicks = Math.max(30, Math.min(70, speech.text().length() * 2));
        echo.triggerTalkAnimation(animTicks);

        if (isGlitchOrHigher) {
            // Play glitched vocalization + queue 3 rapid stutter bursts (every 3 ticks)
            echo.playSound(ModSounds.ECHO_GLITCH_VOICE.get(), 0.85F, 0.9F + ThreadLocalRandom.current().nextFloat() * 0.3F);
            int stutterCount = 2 + Math.min(2, intensity);
            for (int i = 1; i <= stutterCount; i++) {
                float pitch = 0.75F + (i * 0.18F);
                PENDING_STUTTERS.add(new ScheduledStutterSound(
                        speech.ownerUuid(),
                        echo.getId(),
                        pitch,
                        currentTick + (i * 3L)
                ));
            }
        } else {
            float pitch = speech.isCreepyLine() ? 0.78F : 1.15F;
            echo.playSound(ModSounds.ECHO_TALK.get(), 0.85F, pitch);
        }

        ChatFormatting color = speech.isCreepyLine()
                ? ChatFormatting.GRAY
                : (isGlitchOrHigher ? ChatFormatting.AQUA : ChatFormatting.WHITE);

        Component chatComponent = Component.translatable("chat.echocat.echo_format", chatDisplayText)
                .withStyle(color);
        for (ServerPlayer listener : owner.serverLevel().players()) {
            if (listener.distanceToSqr(echo) <= MAX_LISTEN_DISTANCE_SQR) {
                listener.sendSystemMessage(chatComponent);
            }
        }

        ModNetwork.CHANNEL.send(
                PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> echo),
                new EchoSpeechBubblePacket(echo.getId(), bubbleDisplayText, BUBBLE_DURATION_TICKS, speech.isCreepyLine() || isGlitchOrHigher)
        );
    }

    private static void playScheduledStutter(MinecraftServer server, ScheduledStutterSound stutter) {
        ServerPlayer owner = server.getPlayerList().getPlayer(stutter.ownerUuid());
        if (owner == null || !owner.isAlive()) {
            return;
        }
        if (owner.level().getEntity(stutter.echoEntityId()) instanceof EchoEntity echo && echo.isAlive()) {
            echo.playSound(ModSounds.ECHO_STUTTER.get(), 0.75F, stutter.pitch());
        }
    }

    public static EchoEntity findNearbyOwnedEcho(ServerPlayer player) {
        List<EchoEntity> owned = PhaseManager.findPlayerEchoEntities(player.server, player.getUUID());
        for (EchoEntity echo : owned) {
            if (echo.level() == player.level() && echo.isAlive()
                    && echo.distanceToSqr(player) <= MAX_LISTEN_DISTANCE_SQR) {
                return echo;
            }
        }
        return null;
    }

    public static String sanitizePlayerMessage(String raw) {
        if (raw == null) {
            return "";
        }
        String trimmed = raw.trim();
        if (trimmed.isEmpty() || trimmed.startsWith("/") || trimmed.startsWith("<Echo>")) {
            return "";
        }
        String stripped = trimmed
                .replaceAll("(?i)\\u00A7[0-9A-FK-OR]", "")
                .replaceAll("[\\p{Cntrl}]", " ")
                .replaceAll("\\s+", " ")
                .trim();

        if (stripped.isEmpty()) {
            return "";
        }
        if (stripped.length() > MAX_MESSAGE_CHARS) {
            stripped = stripped.substring(0, MAX_MESSAGE_CHARS).trim();
        }
        return stripped;
    }
}
