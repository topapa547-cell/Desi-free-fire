package com.echocat.mod.util;

import com.echocat.mod.EchoCatMod;
import net.minecraft.resources.ResourceLocation;

/**
 * Shared constants and ResourceLocation builders for Echo: The Talking Cat.
 */
public final class EchoConstants {
    private EchoConstants() {
    }

    public static ResourceLocation rl(String path) {
        return new ResourceLocation(EchoCatMod.MOD_ID, path);
    }
}
