package com.echocat.mod.network;

import com.echocat.mod.util.EchoConstants;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * SimpleChannel network wrapper for Echo: The Talking Cat (v1.0.0).
 * Registers:
 * 0: PhaseSyncPacket (PLAY_TO_CLIENT)
 * 1: EchoSpeechBubblePacket (PLAY_TO_CLIENT)
 * 2: VoiceTextPacket (PLAY_TO_SERVER)
 * 3: PhaseTransitionEffectPacket (PLAY_TO_CLIENT)
 * 4: MissionSyncPacket (PLAY_TO_CLIENT)
 * 5: JumpscarePacket (PLAY_TO_CLIENT)
 * 6: CalmEchoPacket (PLAY_TO_SERVER)
 */
public final class ModNetwork {
    private static final String PROTOCOL_VERSION = "5";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            EchoConstants.rl("main"),
            () -> PROTOCOL_VERSION,
            PROTOCOL_VERSION::equals,
            PROTOCOL_VERSION::equals
    );

    private static int packetId = 0;

    private ModNetwork() {
    }

    public static void register() {
        packetId = 0;
        registerPacket(
                PhaseSyncPacket.class,
                PhaseSyncPacket::encode,
                PhaseSyncPacket::decode,
                PhaseSyncPacket::handle,
                NetworkDirection.PLAY_TO_CLIENT
        );
        registerPacket(
                EchoSpeechBubblePacket.class,
                EchoSpeechBubblePacket::encode,
                EchoSpeechBubblePacket::decode,
                EchoSpeechBubblePacket::handle,
                NetworkDirection.PLAY_TO_CLIENT
        );
        registerPacket(
                VoiceTextPacket.class,
                VoiceTextPacket::encode,
                VoiceTextPacket::decode,
                VoiceTextPacket::handle,
                NetworkDirection.PLAY_TO_SERVER
        );
        registerPacket(
                PhaseTransitionEffectPacket.class,
                PhaseTransitionEffectPacket::encode,
                PhaseTransitionEffectPacket::decode,
                PhaseTransitionEffectPacket::handle,
                NetworkDirection.PLAY_TO_CLIENT
        );
        registerPacket(
                MissionSyncPacket.class,
                MissionSyncPacket::encode,
                MissionSyncPacket::decode,
                MissionSyncPacket::handle,
                NetworkDirection.PLAY_TO_CLIENT
        );
        registerPacket(
                JumpscarePacket.class,
                JumpscarePacket::encode,
                JumpscarePacket::decode,
                JumpscarePacket::handle,
                NetworkDirection.PLAY_TO_CLIENT
        );
        registerPacket(
                CalmEchoPacket.class,
                CalmEchoPacket::encode,
                CalmEchoPacket::decode,
                CalmEchoPacket::handle,
                NetworkDirection.PLAY_TO_SERVER
        );
    }

    public static <MSG> void registerPacket(
            Class<MSG> messageType,
            BiConsumer<MSG, FriendlyByteBuf> encoder,
            Function<FriendlyByteBuf, MSG> decoder,
            BiConsumer<MSG, Supplier<NetworkEvent.Context>> messageConsumer,
            NetworkDirection direction
    ) {
        CHANNEL.registerMessage(
                packetId++,
                messageType,
                encoder,
                decoder,
                messageConsumer,
                Optional.of(direction)
        );
    }
}
