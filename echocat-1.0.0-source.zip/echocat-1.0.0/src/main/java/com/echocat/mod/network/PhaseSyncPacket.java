package com.echocat.mod.network;

import com.echocat.mod.client.ClientPacketHandlers;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Synchronizes the player's current EchoPhase ID (1..6) from the server to the client.
 * Uses {@link DistExecutor#unsafeRunWhenOn} to guarantee no client-only classes are loaded
 * on a dedicated server.
 */
public class PhaseSyncPacket {
    private final int phaseId;

    public PhaseSyncPacket(int phaseId) {
        this.phaseId = phaseId;
    }

    public int getPhaseId() {
        return this.phaseId;
    }

    public static void encode(PhaseSyncPacket packet, FriendlyByteBuf buf) {
        buf.writeVarInt(packet.phaseId);
    }

    public static PhaseSyncPacket decode(FriendlyByteBuf buf) {
        return new PhaseSyncPacket(buf.readVarInt());
    }

    public static void handle(PhaseSyncPacket packet, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPacketHandlers.handlePhaseSync(packet))
        );
        context.setPacketHandled(true);
    }
}
