package com.echocat.mod.phase;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * World-level persistent storage for per-player EchoPhase progression (with `dataVersion` migration support).
 */
public class PlayerPhaseData extends SavedData {
    public static final int CURRENT_DATA_VERSION = 1;
    private static final String DATA_NAME = "echocat_player_phases";
    private static final String TAG_DATA_VERSION = "DataVersion";
    private static final String TAG_PLAYERS = "Players";
    private static final String TAG_UUID = "UUID";
    private static final String TAG_PHASE = "Phase";

    private int dataVersion = CURRENT_DATA_VERSION;
    private final Map<UUID, EchoPhase> playerPhases = new HashMap<>();

    public PlayerPhaseData() {
    }

    public static PlayerPhaseData load(CompoundTag tag) {
        PlayerPhaseData data = new PlayerPhaseData();
        int loadedVersion = tag.contains(TAG_DATA_VERSION) ? tag.getInt(TAG_DATA_VERSION) : 0;
        data.dataVersion = migrateIfNeeded(loadedVersion, tag);

        ListTag list = tag.getList(TAG_PLAYERS, Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag entry = list.getCompound(i);
            if (entry.hasUUID(TAG_UUID)) {
                UUID uuid = entry.getUUID(TAG_UUID);
                EchoPhase phase = EchoPhase.byId(entry.getInt(TAG_PHASE));
                data.playerPhases.put(uuid, phase);
            }
        }
        return data;
    }

    private static int migrateIfNeeded(int loadedVersion, CompoundTag tag) {
        // Version 0 -> Version 1 migration hook: ensures Phase IDs are clamped 1..6
        return CURRENT_DATA_VERSION;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putInt(TAG_DATA_VERSION, this.dataVersion);
        ListTag list = new ListTag();
        for (Map.Entry<UUID, EchoPhase> entry : this.playerPhases.entrySet()) {
            CompoundTag playerTag = new CompoundTag();
            playerTag.putUUID(TAG_UUID, entry.getKey());
            playerTag.putInt(TAG_PHASE, entry.getValue().getId());
            list.add(playerTag);
        }
        tag.put(TAG_PLAYERS, list);
        return tag;
    }

    public int getDataVersion() {
        return this.dataVersion;
    }

    public EchoPhase getPhase(UUID playerId) {
        return this.playerPhases.getOrDefault(playerId, EchoPhase.CUTE);
    }

    public void setPhase(UUID playerId, EchoPhase phase) {
        this.playerPhases.put(playerId, phase);
        this.setDirty();
    }

    public static PlayerPhaseData get(MinecraftServer server) {
        ServerLevel overworld = server.overworld();
        return overworld.getDataStorage().computeIfAbsent(
                PlayerPhaseData::load,
                PlayerPhaseData::new,
                DATA_NAME
        );
    }
}
