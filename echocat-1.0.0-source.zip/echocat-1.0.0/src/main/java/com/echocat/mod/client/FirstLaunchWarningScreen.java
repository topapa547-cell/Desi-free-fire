package com.echocat.mod.client;

import com.echocat.mod.config.EchoConfig;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

/**
 * First-launch content & accessibility warning screen (Step 3 requirement):
 * Shown once on first world join when {@code EchoConfig.CLIENT.showFirstLaunchWarning} is true.
 * Explains horror themes, flashing effects, loud sounds, jumpscares, and opt-in voice privacy,
 * and provides direct "Open Settings" toggles for Photosensitive Mode, Jumpscares, and Horror Intensity,
 * plus a "Continue" button that saves `showFirstLaunchWarning = false`.
 */
@OnlyIn(Dist.CLIENT)
public class FirstLaunchWarningScreen extends Screen {
    private boolean settingsExpanded = false;

    public FirstLaunchWarningScreen() {
        super(Component.translatable("screen.echocat.first_warning.title").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
    }

    @Override
    protected void init() {
        super.init();
        int centerX = this.width / 2;
        int baseY = this.height / 2 + 28;

        if (!this.settingsExpanded) {
            this.addRenderableWidget(
                    Button.builder(Component.translatable("screen.echocat.first_warning.open_settings"), btn -> {
                        this.settingsExpanded = true;
                        this.rebuildWidgets();
                    }).bounds(centerX - 155, baseY, 150, 20).build()
            );
            this.addRenderableWidget(
                    Button.builder(Component.translatable("screen.echocat.first_warning.continue").withStyle(ChatFormatting.GREEN), btn -> {
                        EchoConfig.CLIENT.showFirstLaunchWarning.set(false);
                        EchoConfig.CLIENT.showFirstLaunchWarning.save();
                        this.onClose();
                    }).bounds(centerX + 5, baseY, 150, 20).build()
            );
        } else {
            boolean photo = EchoConfig.CLIENT.photosensitiveMode.get();
            boolean jumps = EchoConfig.CLIENT.enableJumpscares.get();
            int intensity = EchoConfig.COMMON.horrorIntensity.get();

            this.addRenderableWidget(
                    Button.builder(Component.translatable("screen.echocat.first_warning.toggle_photo", photo ? "ON" : "OFF"), btn -> {
                        EchoConfig.CLIENT.photosensitiveMode.set(!photo);
                        EchoConfig.CLIENT.photosensitiveMode.save();
                        this.rebuildWidgets();
                    }).bounds(centerX - 110, baseY - 26, 220, 20).build()
            );
            this.addRenderableWidget(
                    Button.builder(Component.translatable("screen.echocat.first_warning.toggle_jumpscares", jumps ? "ON" : "OFF"), btn -> {
                        EchoConfig.CLIENT.enableJumpscares.set(!jumps);
                        EchoConfig.CLIENT.enableJumpscares.save();
                        this.rebuildWidgets();
                    }).bounds(centerX - 110, baseY - 2, 220, 20).build()
            );
            this.addRenderableWidget(
                    Button.builder(Component.translatable("screen.echocat.first_warning.toggle_intensity", intensity), btn -> {
                        int next = (intensity % 3) + 1;
                        EchoConfig.COMMON.horrorIntensity.set(next);
                        EchoConfig.COMMON.horrorIntensity.save();
                        this.rebuildWidgets();
                    }).bounds(centerX - 110, baseY + 22, 220, 20).build()
            );
            this.addRenderableWidget(
                    Button.builder(Component.translatable("screen.echocat.first_warning.continue").withStyle(ChatFormatting.GREEN), btn -> {
                        EchoConfig.CLIENT.showFirstLaunchWarning.set(false);
                        EchoConfig.CLIENT.showFirstLaunchWarning.save();
                        this.onClose();
                    }).bounds(centerX - 75, baseY + 48, 150, 20).build()
            );
        }
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(guiGraphics);

        int panelW = 330;
        int panelH = this.settingsExpanded ? 210 : 155;
        int x0 = (this.width - panelW) / 2;
        int y0 = (this.height - panelH) / 2;

        guiGraphics.fill(x0 - 2, y0 - 2, x0 + panelW + 2, y0 + panelH + 2, 0xFFD4A44C);
        guiGraphics.fill(x0, y0, x0 + panelW, y0 + panelH, 0xF0140E14);

        guiGraphics.drawCenteredString(this.font, this.title, this.width / 2, y0 + 12, 0xFFFFD87A);
        guiGraphics.drawCenteredString(
                this.font,
                Component.translatable("screen.echocat.first_warning.line1"),
                this.width / 2,
                y0 + 34,
                0xFFFFFFFF
        );
        guiGraphics.drawCenteredString(
                this.font,
                Component.translatable("screen.echocat.first_warning.line2"),
                this.width / 2,
                y0 + 48,
                0xFFDDDDDD
        );
        guiGraphics.drawCenteredString(
                this.font,
                Component.translatable("screen.echocat.first_warning.line3"),
                this.width / 2,
                y0 + 62,
                0xFF88E8FF
        );
        guiGraphics.drawCenteredString(
                this.font,
                Component.translatable("screen.echocat.first_warning.line4"),
                this.width / 2,
                y0 + 78,
                0xFFAAFFAA
        );

        super.render(guiGraphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return true;
    }
}
