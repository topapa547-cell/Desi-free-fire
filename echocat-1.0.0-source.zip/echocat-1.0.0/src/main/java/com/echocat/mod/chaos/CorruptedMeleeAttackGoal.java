package com.echocat.mod.chaos;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;

import java.util.EnumSet;

/**
 * Temporary melee attack goal injected into corrupted mobs during Phase 4 (CHAOS).
 * Works for both hostile mobs and passive animals (such as cows, sheep, pigs) that lack
 * a native {@code MeleeAttackGoal} or {@code Attributes.ATTACK_DAMAGE} registration.
 */
public class CorruptedMeleeAttackGoal extends Goal {
    private final Mob mob;
    private final double speedModifier;
    private int attackCooldown = 0;
    private int repathCooldown = 0;

    public CorruptedMeleeAttackGoal(Mob mob, double speedModifier) {
        this.mob = mob;
        this.speedModifier = speedModifier;
        this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        if (!ChaosCorruptionHandler.isCorrupted(this.mob)) {
            return false;
        }
        LivingEntity target = this.mob.getTarget();
        return target != null && target.isAlive();
    }

    @Override
    public boolean canContinueToUse() {
        if (!ChaosCorruptionHandler.isCorrupted(this.mob)) {
            return false;
        }
        LivingEntity target = this.mob.getTarget();
        return target != null && target.isAlive() && this.mob.distanceToSqr(target) <= (28.0D * 28.0D);
    }

    @Override
    public void start() {
        this.repathCooldown = 0;
    }

    @Override
    public void stop() {
        this.mob.getNavigation().stop();
    }

    @Override
    public void tick() {
        LivingEntity target = this.mob.getTarget();
        if (target == null || !target.isAlive()) {
            return;
        }

        this.mob.getLookControl().setLookAt(target, 30.0F, 30.0F);

        if (--this.repathCooldown <= 0) {
            this.repathCooldown = 10; // Throttled pathfinding every 10 ticks
            this.mob.getNavigation().moveTo(target, this.speedModifier);
        }

        this.attackCooldown = Math.max(this.attackCooldown - 1, 0);
        double distSqr = this.mob.distanceToSqr(target);
        double reachSqr = getAttackReachSqr(target);

        if (distSqr <= reachSqr && this.attackCooldown <= 0) {
            this.attackCooldown = 20;
            this.mob.swing(InteractionHand.MAIN_HAND);
            performCorruptedStrike(target);
        }
    }

    private void performCorruptedStrike(LivingEntity target) {
        AttributeInstance attackAttr = this.mob.getAttribute(Attributes.ATTACK_DAMAGE);
        if (attackAttr != null) {
            this.mob.doHurtTarget(target);
        } else {
            // Passive animals (cows, pigs, sheep) don't register ATTACK_DAMAGE in their AttributeSupplier,
            // so we apply a direct mobAttack hurt call using the temporary corrupted base damage (3.0F).
            target.hurt(this.mob.damageSources().mobAttack(this.mob), 3.0F);
        }
    }

    private double getAttackReachSqr(LivingEntity target) {
        float width = this.mob.getBbWidth() * 2.0F;
        return (width * width) + target.getBbWidth() + 1.5D;
    }
}
