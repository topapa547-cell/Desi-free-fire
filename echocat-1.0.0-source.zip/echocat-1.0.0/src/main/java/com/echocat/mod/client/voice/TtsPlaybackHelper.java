package com.echocat.mod.client.voice;

import com.echocat.mod.EchoCatMod;
import com.echocat.mod.config.EchoConfig;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import java.io.ByteArrayInputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Optional client-side Text-to-Speech (TTS) synthesizer (`EchoConfig.CLIENT.enableTts`).
 * Requests WAV audio from `ttsEndpoint` and plays it in memory with a higher sample rate
 * (~1.30x for cute cat voice, ~0.88x for unsettling creepy lines).
 * If TTS is disabled or fails, silently falls back to chat + speech bubble only.
 */
@OnlyIn(Dist.CLIENT)
public final class TtsPlaybackHelper {
    private static final Gson GSON = new Gson();
    private static final ExecutorService TTS_EXECUTOR = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "EchoCat-Client-TTS");
        t.setDaemon(true);
        return t;
    });
    private static final HttpClient HTTP_CLIENT = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(5))
            .executor(TTS_EXECUTOR)
            .build();

    private TtsPlaybackHelper() {
    }

    public static void speakAsync(String text, boolean creepy) {
        if (!EchoConfig.CLIENT.enableTts.get() || text == null || text.isBlank()) {
            return;
        }
        String endpoint = EchoConfig.CLIENT.ttsEndpoint.get();
        String apiKey = VoiceInputHandler.resolveClientApiKey();
        if (endpoint == null || endpoint.isBlank() || apiKey.isBlank()) {
            return;
        }

        String model = EchoConfig.CLIENT.ttsModel.get();
        String voice = EchoConfig.CLIENT.ttsVoice.get();

        CompletableFuture.runAsync(() -> {
            try {
                JsonObject payload = new JsonObject();
                payload.addProperty("model", (model == null || model.isBlank()) ? "tts-1" : model.trim());
                payload.addProperty("voice", (voice == null || voice.isBlank()) ? "alloy" : voice.trim());
                payload.addProperty("input", text);
                payload.addProperty("response_format", "wav");

                HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(endpoint.trim()))
                        .timeout(Duration.ofSeconds(5))
                        .header("Authorization", "Bearer " + apiKey)
                        .header("Content-Type", "application/json")
                        .POST(HttpRequest.BodyPublishers.ofString(GSON.toJson(payload), StandardCharsets.UTF_8))
                        .build();

                HttpResponse<byte[]> response = HTTP_CLIENT.send(
                        request,
                        HttpResponse.BodyHandlers.ofByteArray()
                );

                if (response.statusCode() >= 200 && response.statusCode() < 300 && response.body() != null) {
                    playWavWithPitchShift(response.body(), creepy ? 0.88F : 1.30F);
                }
            } catch (Exception ex) {
                if (EchoConfig.COMMON.debugMode.get()) {
                    EchoCatMod.LOGGER.info("[EchoCat TTS Debug] TTS unavailable, falling back to chat only ({})",
                            ex.getClass().getSimpleName());
                }
            }
        }, TTS_EXECUTOR);
    }

    private static void playWavWithPitchShift(byte[] wavBytes, float pitchFactor) throws Exception {
        try (AudioInputStream in = AudioSystem.getAudioInputStream(new ByteArrayInputStream(wavBytes))) {
            AudioFormat baseFormat = in.getFormat();
            Clip clip = AudioSystem.getClip();
            clip.open(in);

            if (clip.isControlSupported(FloatControl.Type.SAMPLE_RATE)) {
                FloatControl rateControl = (FloatControl) clip.getControl(FloatControl.Type.SAMPLE_RATE);
                float targetRate = Math.max(rateControl.getMinimum(),
                        Math.min(rateControl.getMaximum(), baseFormat.getSampleRate() * pitchFactor));
                rateControl.setValue(targetRate);
            }
            clip.start();
        }
    }
}
