package com.echocat.mod.client;

import com.echocat.mod.client.voice.TtsPlaybackHelper;
import com.echocat.mod.config.EchoConfig;
import com.echocat.mod.entity.EchoEntity;
import com.echocat.mod.mission.MissionManager;
import com.echocat.mod.network.EchoSpeechBubblePacket;
import com.echocat.mod.network.JumpscarePacket;
import com.echocat.mod.network.MissionSyncPacket;
import com.echocat.mod.network.PhaseSyncPacket;
import com.echocat.mod.network.PhaseTransitionEffectPacket;
import com.echocat.mod.phase.EchoPhase;
import com.echocat.mod.phase.PhaseManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

/**
 * Client-side packet and UI handlers isolated from dedicated server classloading.
 */
@OnlyIn(Dist.CLIENT)
public final class ClientPacketHandlers {
    private ClientPacketHandlers() {
    }

    public static void handlePhaseSync(PhaseSyncPacket packet) {
        EchoPhase phase = EchoPhase.byId(packet.getPhaseId());
        PhaseManager.setClientCachedPhase(phase);
    }

    public static void handleSpeechBubble(EchoSpeechBubblePacket packet) {
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) {
            return;
        }
        Entity entity = level.getEntity(packet.getEntityId());
        if (entity instanceof EchoEntity echo) {
            echo.setSpeechBubble(packet.getText(), packet.getDurationTicks(), packet.isCreepy());
        }
        if (EchoConfig.CLIENT.enableTts.get()) {
            TtsPlaybackHelper.speakAsync(packet.getText(), packet.isCreepy());
        }
    }

    public static void handlePhaseTransitionEffect(PhaseTransitionEffectPacket packet) {
        GlitchOverlayRenderer.triggerPhaseTransitionPulse(packet.getNewPhaseId(), packet.getDurationTicks());
    }

    public static void handleMissionSync(MissionSyncPacket packet) {
        MissionManager.setClientCompletedMask(packet.getCompletedMask());
    }

    public static void handleJumpscare(JumpscarePacket packet) {
        GlitchOverlayRenderer.triggerJumpscareVisual();
    }

    public static void openEchoJournalScreen() {
        Minecraft.getInstance().setScreen(new EchoJournalScreen());
    }
}
