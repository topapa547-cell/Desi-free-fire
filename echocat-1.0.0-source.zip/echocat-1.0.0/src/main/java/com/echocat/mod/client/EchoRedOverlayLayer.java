package com.echocat.mod.client;

import com.echocat.mod.entity.EchoEntity;
import com.echocat.mod.phase.EchoPhase;
import com.echocat.mod.util.EchoConstants;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.renderer.GeoRenderer;
import software.bernie.geckolib.renderer.layer.GeoRenderLayer;

/**
 * GeckoLib render layer that renders `echo_red_overlay.png` over Echo during Phase 5 (RED)
 * with alpha directly equal to Echo's synced {@code redProgress} (0.0 to 1.0).
 */
public class EchoRedOverlayLayer extends GeoRenderLayer<EchoEntity> {
    private static final ResourceLocation RED_OVERLAY_TEXTURE =
            EchoConstants.rl("textures/entity/echo_red_overlay.png");

    public EchoRedOverlayLayer(GeoRenderer<EchoEntity> entityRendererIn) {
        super(entityRendererIn);
    }

    @Override
    public void render(PoseStack poseStack, EchoEntity animatable, BakedGeoModel bakedModel,
                       RenderType renderType, MultiBufferSource bufferSource, VertexConsumer buffer,
                       float partialTick, int packedLight, int packedOverlay) {
        if (animatable.isPurified() || animatable.getPhase() != EchoPhase.RED) {
            return;
        }
        float alpha = animatable.getRedProgress();
        if (alpha <= 0.01F) {
            return;
        }

        RenderType overlayType = RenderType.entityTranslucent(RED_OVERLAY_TEXTURE);
        VertexConsumer overlayBuffer = bufferSource.getBuffer(overlayType);
        getRenderer().reRender(
                bakedModel,
                poseStack,
                bufferSource,
                animatable,
                overlayType,
                overlayBuffer,
                partialTick,
                packedLight,
                OverlayTexture.NO_OVERLAY,
                1.0F,
                0.15F,
                0.20F,
                alpha
        );
    }
}
