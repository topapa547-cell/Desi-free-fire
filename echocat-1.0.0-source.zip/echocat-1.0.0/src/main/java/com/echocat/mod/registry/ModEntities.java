package com.echocat.mod.registry;

import com.echocat.mod.EchoCatMod;
import com.echocat.mod.entity.EchoEntity;
import com.echocat.mod.util.EchoConstants;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, EchoCatMod.MOD_ID);

    public static final RegistryObject<EntityType<EchoEntity>> ECHO = ENTITIES.register(
            "echo",
            () -> EntityType.Builder.of(EchoEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 0.85F)
                    .clientTrackingRange(10)
                    .build(EchoConstants.rl("echo").toString())
    );

    private ModEntities() {
    }

    public static void register(IEventBus eventBus) {
        ENTITIES.register(eventBus);
    }
}
