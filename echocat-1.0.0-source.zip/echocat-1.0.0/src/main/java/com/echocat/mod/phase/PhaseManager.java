package com.echocat.mod.phase;

import com.echocat.mod.EchoCatMod;
import com.echocat.mod.config.EchoConfig;
import com.echocat.mod.entity.EchoEntity;
import com.echocat.mod.network.ModNetwork;
import com.echocat.mod.network.PhaseSyncPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Central API for reading and updating a player's current EchoPhase,
 * syncing phase state to clients, and updating all Echo entities owned by the player.
 */
public final class PhaseManager {
    private static EchoPhase clientCachedPhase = EchoPhase.CUTE;

    private PhaseManager() {
    }

    /**
     * Gets the current EchoPhase for the given player.
     * Works on both logical server (via SavedData) and logical client (via synced cache).
     */
    public static EchoPhase getPhase(Player player) {
        if (player instanceof ServerPlayer serverPlayer && serverPlayer.getServer() != null) {
            return PlayerPhaseData.get(serverPlayer.getServer()).getPhase(serverPlayer.getUUID());
        }
        return clientCachedPhase;
    }

    /**
     * Updates the player's EchoPhase, saves it to persistent world data, fires
     * {@link EchoPhaseChangeEvent}, syncs to the player's client, and updates all
     * loaded Echo entities belonging to that player across all dimensions.
     */
    public static void setPhase(Player player, EchoPhase newPhase) {
        if (!(player instanceof ServerPlayer serverPlayer) || serverPlayer.getServer() == null) {
            clientCachedPhase = newPhase;
            return;
        }

        MinecraftServer server = serverPlayer.getServer();
        PlayerPhaseData data = PlayerPhaseData.get(server);
        UUID playerUuid = serverPlayer.getUUID();
        EchoPhase oldPhase = data.getPhase(playerUuid);

        data.setPhase(playerUuid, newPhase);

        // Update all loaded Echo entities owned by this player across all dimensions
        updatePlayerEchoEntities(server, playerUuid, newPhase);

        // Sync phase to the client
        syncToClient(serverPlayer, newPhase);

        if (oldPhase != newPhase) {
            if (EchoConfig.COMMON.debugMode.get()) {
                EchoCatMod.LOGGER.info("Player {} EchoPhase changed: {} -> {}",
                        serverPlayer.getGameProfile().getName(), oldPhase.name(), newPhase.name());
            }
            MinecraftForge.EVENT_BUS.post(new EchoPhaseChangeEvent(serverPlayer, oldPhase, newPhase));
        }
    }

    /**
     * Advances the player's EchoPhase by one step (clamped at HORROR_FINAL) and returns the new phase.
     */
    public static EchoPhase advance(Player player) {
        EchoPhase current = getPhase(player);
        EchoPhase next = current.next();
        setPhase(player, next);
        return next;
    }

    /**
     * Sends a PhaseSyncPacket from the server to the target player.
     */
    public static void syncToClient(ServerPlayer player, EchoPhase phase) {
        ModNetwork.CHANNEL.send(
                PacketDistributor.PLAYER.with(() -> player),
                new PhaseSyncPacket(phase.getId())
        );
    }

    /**
     * Called by client packet handler when receiving PhaseSyncPacket.
     */
    public static void setClientCachedPhase(EchoPhase phase) {
        clientCachedPhase = phase;
    }

    public static EchoPhase getClientCachedPhase() {
        return clientCachedPhase;
    }

    /**
     * Finds all loaded EchoEntity instances owned by the specified player UUID across all server levels.
     */
    public static List<EchoEntity> findPlayerEchoEntities(MinecraftServer server, UUID ownerUuid) {
        List<EchoEntity> result = new ArrayList<>();
        for (ServerLevel level : server.getAllLevels()) {
            for (Entity entity : level.getAllEntities()) {
                if (entity instanceof EchoEntity echo && echo.isAlive() && ownerUuid.equals(echo.getOwnerUUID())) {
                    result.add(echo);
                }
            }
        }
        return result;
    }

    /**
     * Updates the synced phase index on all loaded Echo entities belonging to the player.
     */
    public static void updatePlayerEchoEntities(MinecraftServer server, UUID ownerUuid, EchoPhase phase) {
        for (EchoEntity echo : findPlayerEchoEntities(server, ownerUuid)) {
            echo.setPhase(phase);
        }
    }
}
