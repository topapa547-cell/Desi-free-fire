package com.echocat.mod.network;

import com.echocat.mod.client.ClientPacketHandlers;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Server -> Client packet instructing tracking clients to display a 4-second floating
 * text bubble above the specified EchoEntity and optionally synthesize cat-pitched TTS.
 */
public class EchoSpeechBubblePacket {
    private final int entityId;
    private final String text;
    private final int durationTicks;
    private final boolean creepy;

    public EchoSpeechBubblePacket(int entityId, String text, int durationTicks, boolean creepy) {
        this.entityId = entityId;
        this.text = text;
        this.durationTicks = durationTicks;
        this.creepy = creepy;
    }

    public int getEntityId() {
        return this.entityId;
    }

    public String getText() {
        return this.text;
    }

    public int getDurationTicks() {
        return this.durationTicks;
    }

    public boolean isCreepy() {
        return this.creepy;
    }

    public static void encode(EchoSpeechBubblePacket packet, FriendlyByteBuf buf) {
        buf.writeVarInt(packet.entityId);
        buf.writeUtf(packet.text, 120);
        buf.writeVarInt(packet.durationTicks);
        buf.writeBoolean(packet.creepy);
    }

    public static EchoSpeechBubblePacket decode(FriendlyByteBuf buf) {
        int entityId = buf.readVarInt();
        String text = buf.readUtf(120);
        int durationTicks = buf.readVarInt();
        boolean creepy = buf.readBoolean();
        return new EchoSpeechBubblePacket(entityId, text, durationTicks, creepy);
    }

    public static void handle(EchoSpeechBubblePacket packet, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPacketHandlers.handleSpeechBubble(packet))
        );
        context.setPacketHandled(true);
    }
}
