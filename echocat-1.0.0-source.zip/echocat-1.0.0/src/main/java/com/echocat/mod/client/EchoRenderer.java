package com.echocat.mod.client;

import com.echocat.mod.config.EchoConfig;
import com.echocat.mod.entity.EchoEntity;
import com.echocat.mod.phase.EchoPhase;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.layer.AutoGlowingGeoLayer;

/**
 * GeckoLib 4 entity renderer for Echo: The Talking Cat (v0.4.0).
 * Includes:
 * - {@link AutoGlowingGeoLayer} for `echo_horror_glowing.png` (eyes, mouth interior, shard edges).
 * - {@link EchoRedOverlayLayer} for `echo_red_overlay.png` (alpha = redProgress).
 * - Phase 3+ invisibility flickers and RGB-split red/cyan ghost duplicates.
 * - Floating 4-second speech bubble above Echo's head.
 */
public class EchoRenderer extends GeoEntityRenderer<EchoEntity> {
    private int ghostPassMode = 0;

    public EchoRenderer(EntityRendererProvider.Context renderManager) {
        super(renderManager, new EchoModel());
        this.shadowRadius = 0.45F;
        this.addRenderLayer(new AutoGlowingGeoLayer<>(this));
        this.addRenderLayer(new EchoRedOverlayLayer(this));
    }

    @Override
    public ResourceLocation getTextureLocation(EchoEntity animatable) {
        return this.model.getTextureResource(animatable);
    }

    @Override
    public RenderType getRenderType(EchoEntity animatable, ResourceLocation texture,
                                    @Nullable MultiBufferSource bufferSource, float partialTick) {
        if (this.ghostPassMode != 0) {
            return RenderType.entityTranslucent(texture);
        }
        return super.getRenderType(animatable, texture, bufferSource, partialTick);
    }

    @Override
    public void render(EchoEntity entity, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource bufferSource, int packedLight) {
        EchoPhase phase = entity.getPhase();
        boolean isGlitchOrHigher = phase.getId() >= EchoPhase.GLITCH.getId() && !entity.isPurified();
        boolean photosensitive = EchoConfig.CLIENT.photosensitiveMode.get();

        if (isGlitchOrHigher && phase != EchoPhase.HORROR_FINAL) {
            long invisBucket = photosensitive
                    ? (System.currentTimeMillis() / 500L)
                    : (System.currentTimeMillis() / 160L);
            long invisHash = (invisBucket * 1664525L + 1013904223L) ^ entity.getId();
            if (!photosensitive && Math.floorMod(invisHash, 19) == 0) {
                renderSpeechBubbleIfPresent(entity, partialTick, poseStack, bufferSource, packedLight);
                return;
            }
        }

        this.ghostPassMode = 0;
        super.render(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);

        if (isGlitchOrHigher && shouldRenderRgbSplitGhost(entity, photosensitive)) {
            int intensity = Math.max(1, Math.min(3, EchoConfig.COMMON.horrorIntensity.get()));
            float offset = (photosensitive ? 0.045F : 0.085F) * (0.7F + 0.2F * intensity);

            poseStack.pushPose();
            poseStack.translate(offset, 0.01F, -offset * 0.5F);
            this.ghostPassMode = 1;
            super.render(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);
            poseStack.popPose();

            poseStack.pushPose();
            poseStack.translate(-offset, 0.01F, offset * 0.5F);
            this.ghostPassMode = 2;
            super.render(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);
            poseStack.popPose();

            this.ghostPassMode = 0;
        }

        renderSpeechBubbleIfPresent(entity, partialTick, poseStack, bufferSource, packedLight);
    }

    @Override
    public void actuallyRender(PoseStack poseStack, EchoEntity animatable, BakedGeoModel model,
                               RenderType renderType, MultiBufferSource bufferSource, VertexConsumer buffer,
                               boolean isReRender, float partialTick, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        if (this.ghostPassMode == 1) {
            super.actuallyRender(poseStack, animatable, model, renderType, bufferSource, buffer,
                    isReRender, partialTick, packedLight, packedOverlay, 1.0F, 0.15F, 0.25F, 0.38F);
        } else if (this.ghostPassMode == 2) {
            super.actuallyRender(poseStack, animatable, model, renderType, bufferSource, buffer,
                    isReRender, partialTick, packedLight, packedOverlay, 0.15F, 0.95F, 1.0F, 0.38F);
        } else {
            super.actuallyRender(poseStack, animatable, model, renderType, bufferSource, buffer,
                    isReRender, partialTick, packedLight, packedOverlay, red, green, blue, alpha);
        }
    }

    private boolean shouldRenderRgbSplitGhost(EchoEntity entity, boolean photosensitive) {
        if (EchoConfig.COMMON.performanceMode.get()) {
            return false;
        }
        long bucket = photosensitive
                ? (System.currentTimeMillis() / 500L)
                : (System.currentTimeMillis() / 110L);
        long hash = (bucket * 22695477L + 1L) ^ entity.getId();
        return Math.floorMod(hash, photosensitive ? 8 : 5) == 0;
    }

    private void renderSpeechBubbleIfPresent(EchoEntity entity, float partialTick, PoseStack poseStack,
                                             MultiBufferSource bufferSource, int packedLight) {
        int remaining = entity.getSpeechBubbleTicksRemaining();
        String bubbleText = entity.getSpeechBubbleText();
        if (remaining > 0 && bubbleText != null && !bubbleText.isEmpty()) {
            renderFloatingSpeechBubble(entity, bubbleText, remaining, partialTick, poseStack, bufferSource, packedLight);
        }
    }

    private void renderFloatingSpeechBubble(
            EchoEntity entity,
            String text,
            int remainingTicks,
            float partialTick,
            PoseStack poseStack,
            MultiBufferSource bufferSource,
            int packedLight
    ) {
        double distanceSqr = this.entityRenderDispatcher.distanceToSqr(entity);
        if (distanceSqr > 4096.0D) {
            return;
        }

        float effectiveRemaining = Math.max(0.0F, remainingTicks - partialTick);
        float alphaFactor = effectiveRemaining < 20.0F ? (effectiveRemaining / 20.0F) : 1.0F;
        int alpha = Math.max(8, Math.min(255, (int) (alphaFactor * 255.0F)));

        int baseRgb = entity.isSpeechBubbleCreepy() ? 0xFFAA99 : 0xFFFFFF;
        int textColor = (alpha << 24) | baseRgb;
        int bgAlpha = (int) (Minecraft.getInstance().options.getBackgroundOpacity(0.25F) * 255.0F * alphaFactor);
        int bgColor = (bgAlpha << 24);

        Component component = Component.literal(text);
        Font font = this.getFont();

        boolean horrorHeight = entity.shouldRenderHorrorModel(EchoConfig.CLIENT.photosensitiveMode.get());
        float yOffset = horrorHeight ? 2.65F : (entity.getBbHeight() + 0.55F);

        poseStack.pushPose();
        poseStack.translate(0.0F, yOffset, 0.0F);
        poseStack.mulPose(this.entityRenderDispatcher.cameraOrientation());
        poseStack.scale(-0.025F, -0.025F, 0.025F);

        Matrix4f matrix4f = poseStack.last().pose();
        float xOffset = (float) (-font.width(component) / 2);

        font.drawInBatch(
                component,
                xOffset,
                0.0F,
                textColor,
                false,
                matrix4f,
                bufferSource,
                Font.DisplayMode.NORMAL,
                bgColor,
                packedLight
        );
        poseStack.popPose();
    }
}
