package com.echocat.mod.network;

import com.echocat.mod.command.EchoCommands;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Supplier;

/**
 * Client -> Server panic-button packet triggered when the player presses the "Calm Echo"
 * keybind (`K` by default). Immediately returns that player's Echo to Phase 1 (CUTE) and
 * clears all horror effects for the session, with a 1-second server rate limit.
 */
public class CalmEchoPacket {
    private static final Map<UUID, Long> RATE_LIMIT_MS = new ConcurrentHashMap<>();

    public CalmEchoPacket() {
    }

    public static void encode(CalmEchoPacket packet, FriendlyByteBuf buf) {
    }

    public static CalmEchoPacket decode(FriendlyByteBuf buf) {
        return new CalmEchoPacket();
    }

    public static void handle(CalmEchoPacket packet, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> {
            ServerPlayer sender = context.getSender();
            if (sender == null || !sender.isAlive()) {
                return;
            }
            long now = System.currentTimeMillis();
            Long last = RATE_LIMIT_MS.get(sender.getUUID());
            if (last != null && (now - last) < 1000L) {
                return;
            }
            RATE_LIMIT_MS.put(sender.getUUID(), now);
            EchoCommands.executeCalmForPlayer(sender);
        });
        context.setPacketHandled(true);
    }
}
