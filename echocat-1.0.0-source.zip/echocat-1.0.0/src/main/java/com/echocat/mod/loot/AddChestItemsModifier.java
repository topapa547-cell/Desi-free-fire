package com.echocat.mod.loot;

import com.echocat.mod.registry.ModItems;
import com.google.common.base.Suppliers;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.common.loot.LootModifier;
import org.jetbrains.annotations.NotNull;

import java.util.function.Supplier;

/**
 * Forge Global Loot Modifier that injects Echo Circuit (Mission 1), Red Crystal (Mission 4),
 * and Remote Casing (Mission 5) into vanilla structure chest loot tables (`minecraft:chests/*`).
 */
public class AddChestItemsModifier extends LootModifier {
    public static final Supplier<Codec<AddChestItemsModifier>> CODEC = Suppliers.memoize(() ->
            RecordCodecBuilder.create(inst -> codecStart(inst).apply(inst, AddChestItemsModifier::new))
    );

    public AddChestItemsModifier(LootItemCondition[] conditionsIn) {
        super(conditionsIn);
    }

    @Override
    protected @NotNull ObjectArrayList<ItemStack> doApply(ObjectArrayList<ItemStack> generatedLoot, LootContext context) {
        ResourceLocation tableId = context.getQueriedLootTableId();
        if (tableId != null && tableId.getPath().startsWith("chests/")) {
            if (context.getRandom().nextFloat() < 0.25F) {
                generatedLoot.add(new ItemStack(ModItems.ECHO_CIRCUIT.get()));
            }
            if (context.getRandom().nextFloat() < 0.16F) {
                generatedLoot.add(new ItemStack(ModItems.REMOTE_CASING.get()));
            }
            if (context.getRandom().nextFloat() < 0.12F) {
                generatedLoot.add(new ItemStack(ModItems.RED_CRYSTAL.get()));
            }
        }
        return generatedLoot;
    }

    @Override
    public Codec<? extends IGlobalLootModifier> codec() {
        return CODEC.get();
    }
}
