package com.echocat.mod.phase;

import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.player.PlayerEvent;

/**
 * Fired on {@link net.minecraftforge.common.MinecraftForge#EVENT_BUS} whenever a player's
 * EchoPhase changes. Later prompts (AI chat/voice, glitch, chaos, boss fight) can subscribe
 * to this event to trigger phase transitions.
 */
public class EchoPhaseChangeEvent extends PlayerEvent {
    private final EchoPhase oldPhase;
    private final EchoPhase newPhase;

    public EchoPhaseChangeEvent(Player player, EchoPhase oldPhase, EchoPhase newPhase) {
        super(player);
        this.oldPhase = oldPhase;
        this.newPhase = newPhase;
    }

    public EchoPhase getOldPhase() {
        return this.oldPhase;
    }

    public EchoPhase getNewPhase() {
        return this.newPhase;
    }
}
