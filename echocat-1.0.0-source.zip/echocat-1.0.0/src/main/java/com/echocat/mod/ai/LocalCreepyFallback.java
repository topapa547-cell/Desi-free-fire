package com.echocat.mod.ai;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Provides 50 original, mild, atmospheric horror lines (max 8 words, no gore, no slurs,
 * no real-world threats) used whenever the external AI API is disabled ("none"), rate-limited,
 * over the daily cap, or times out.
 * Selects context-appropriate lines for night, caves, low health, the Nether, the End, or general play.
 */
public final class LocalCreepyFallback {

    // 10 Night-specific lines (indices 0..9)
    public static final List<String> NIGHT_LINES = List.of(
            "the moon is watching us tonight",
            "do not go to sleep yet",
            "something moved outside your window",
            "the dark is getting closer now",
            "why are the stars blinking out",
            "wake up before it finds you",
            "nighttime makes my shadow too long",
            "did you lock the door tonight",
            "the bed will not keep you safe",
            "someone is standing in the dark"
    );

    // 10 Cave / Underground lines (indices 10..19)
    public static final List<String> CAVE_LINES = List.of(
            "the stone is breathing down here",
            "we dug too deep this time",
            "do you hear footsteps behind us",
            "your torch is about to fade",
            "something is scratching inside the wall",
            "there is no way back up",
            "the echo down here is not mine",
            "stop digging toward that sound",
            "it is cold beneath the bedrock",
            "count our shadows on the wall"
    );

    // 8 Low-Health lines (indices 20..27)
    public static final List<String> LOW_HEALTH_LINES = List.of(
            "your heartbeat sounds so slow now",
            "you are fading away from me",
            "do not close your eyes yet",
            "i can hear your pulse stopping",
            "you look so fragile right now",
            "what happens when you break",
            "stay with me a little longer",
            "your hands are shaking again"
    );

    // 6 Nether / End dimension lines (indices 28..33)
    public static final List<String> OTHERWORLD_LINES = List.of(
            "we do not belong in this place",
            "the air tastes like old ash",
            "something ancient remembers your name here",
            "the void is staring back at us",
            "we should never have crossed over",
            "my voice sounds wrong in this world"
    );

    // 16 General atmospheric cat lines (indices 34..49) -> Total = 50 lines
    public static final List<String> GENERAL_LINES = List.of(
            "why did you leave me alone",
            "i see you when you turn",
            "look right behind you right now",
            "wake up please just wake up",
            "that is not what you meant",
            "who is standing beside you",
            "i remember what you did yesterday",
            "my eyes do not feel like mine",
            "someone else is wearing my fur",
            "you never noticed the extra footsteps",
            "do not look at the corner",
            "i was here before you spawned",
            "why are you pretending to smile",
            "the world stops when you leave",
            "listen closely to the quiet static",
            "i am not just a cat anymore"
    );

    public static final List<String> ALL_FIFTY_LINES;

    static {
        List<String> combined = new ArrayList<>(50);
        combined.addAll(NIGHT_LINES);
        combined.addAll(CAVE_LINES);
        combined.addAll(LOW_HEALTH_LINES);
        combined.addAll(OTHERWORLD_LINES);
        combined.addAll(GENERAL_LINES);
        ALL_FIFTY_LINES = Collections.unmodifiableList(combined);
    }

    private LocalCreepyFallback() {
    }

    /**
     * Selects a creepy line weighted by the current player context.
     */
    public static String pickContextualLine(CreepyContext ctx) {
        ThreadLocalRandom rng = ThreadLocalRandom.current();
        List<String> pool = new ArrayList<>(GENERAL_LINES);

        if (ctx != null) {
            if (ctx.isLowHealth()) {
                pool.addAll(LOW_HEALTH_LINES);
                pool.addAll(LOW_HEALTH_LINES); // weight higher when low HP
            }
            if (ctx.isUndergroundCave()) {
                pool.addAll(CAVE_LINES);
                pool.addAll(CAVE_LINES);
            }
            if (ctx.isNight()) {
                pool.addAll(NIGHT_LINES);
                pool.addAll(NIGHT_LINES);
            }
            if (ctx.isNether() || ctx.isEnd()) {
                pool.addAll(OTHERWORLD_LINES);
                pool.addAll(OTHERWORLD_LINES);
            }
        }

        return pool.get(rng.nextInt(pool.size()));
    }
}
