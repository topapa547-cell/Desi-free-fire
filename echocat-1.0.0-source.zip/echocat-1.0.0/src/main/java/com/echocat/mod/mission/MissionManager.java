package com.echocat.mod.mission;

import com.echocat.mod.EchoCatMod;
import com.echocat.mod.config.EchoConfig;
import com.echocat.mod.network.MissionSyncPacket;
import com.echocat.mod.network.ModNetwork;
import com.echocat.mod.phase.EchoPhase;
import com.echocat.mod.phase.PhaseManager;
import com.echocat.mod.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.network.PacketDistributor;

import java.util.Set;

/**
 * Manages the 5 survival missions and strict ordered phase progression:
 * - Mission 1 (CUTE -> WEIRD): Obtain 1x Echo Circuit (`echocat:echo_circuit`).
 * - Mission 2 (WEIRD -> GLITCH): Obtain 1x Glitch Shard (`echocat:glitch_shard`).
 * - Mission 3 (GLITCH -> CHAOS): Obtain 1x Corrupted Core (`echocat:corrupted_core`).
 * - Mission 4 (CHAOS -> RED): Obtain 1x Red Crystal (`echocat:red_crystal`).
 * - Mission 5 (RED -> HORROR_FINAL): Craft or obtain 1x The Remote (`echocat:the_remote`).
 *
 * Strict Ordering & Early Collection Rule:
 * Players cannot skip missions out of order. However, if a player obtains a later mission's
 * item early and keeps it in their inventory, our periodic inventory check (every 20 ticks)
 * and crafting/pickup hooks automatically complete that mission as soon as it becomes active.
 */
public class MissionManager {
    public static final int MISSION_1_ECHO_CIRCUIT = 1;
    public static final int MISSION_2_GLITCH_SHARD = 2;
    public static final int MISSION_3_CORRUPTED_CORE = 3;
    public static final int MISSION_4_RED_CRYSTAL = 4;
    public static final int MISSION_5_THE_REMOTE = 5;
    public static final int TOTAL_MISSIONS = 5;

    private static int clientCompletedMask = 0;

    @SubscribeEvent
    public void onItemCrafted(final PlayerEvent.ItemCraftedEvent event) {
        if (event.getEntity() instanceof ServerPlayer serverPlayer) {
            checkInventoryForActiveMission(serverPlayer, event.getCrafting());
        }
    }

    @SubscribeEvent
    public void onItemPickup(final PlayerEvent.ItemPickupEvent event) {
        if (event.getEntity() instanceof ServerPlayer serverPlayer) {
            checkInventoryForActiveMission(serverPlayer, event.getStack());
        }
    }

    @SubscribeEvent
    public void onPlayerTick(final TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer serverPlayer)) {
            return;
        }
        // Check inventory once every 20 ticks (1 second) so items collected early or via chests/mining
        // immediately count when their corresponding mission becomes the active mission.
        if (serverPlayer.tickCount % 20 == 0) {
            checkInventoryForActiveMission(serverPlayer, ItemStack.EMPTY);
        }
    }

    /**
     * Checks whether the player holds (or just crafted/picked up) the required item for their
     * current active mission, enforcing strict sequential order (1 -> 2 -> 3 -> 4 -> 5).
     */
    public static void checkInventoryForActiveMission(ServerPlayer player, ItemStack immediateStack) {
        if (player == null || player.server == null) {
            return;
        }
        int activeMission = getActiveMissionId(player);
        if (activeMission < 1 || activeMission > TOTAL_MISSIONS) {
            return;
        }

        Item requiredItem = getRequiredItemForMission(activeMission);
        if (requiredItem == null) {
            return;
        }

        if ((!immediateStack.isEmpty() && immediateStack.is(requiredItem))
                || hasItemInInventory(player.getInventory(), requiredItem)) {
            completeMission(player, activeMission);
        }
    }

    private static boolean hasItemInInventory(Inventory inv, Item target) {
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack stack = inv.getItem(i);
            if (!stack.isEmpty() && stack.is(target)) {
                return true;
            }
        }
        return false;
    }

    public static Item getRequiredItemForMission(int missionId) {
        return switch (missionId) {
            case MISSION_1_ECHO_CIRCUIT -> ModItems.ECHO_CIRCUIT.get();
            case MISSION_2_GLITCH_SHARD -> ModItems.GLITCH_SHARD.get();
            case MISSION_3_CORRUPTED_CORE -> ModItems.CORRUPTED_CORE.get();
            case MISSION_4_RED_CRYSTAL -> ModItems.RED_CRYSTAL.get();
            case MISSION_5_THE_REMOTE -> ModItems.THE_REMOTE.get();
            default -> null;
        };
    }

    /**
     * Returns the next mission ID (1..5) the player needs to complete based on their current phase
     * and completed mission set, or 0 if all 5 missions are complete.
     */
    public static int getActiveMissionId(ServerPlayer player) {
        EchoPhase phase = PhaseManager.getPhase(player);
        return switch (phase) {
            case CUTE -> MISSION_1_ECHO_CIRCUIT;
            case WEIRD -> MISSION_2_GLITCH_SHARD;
            case GLITCH -> MISSION_3_CORRUPTED_CORE;
            case CHAOS -> MISSION_4_RED_CRYSTAL;
            case RED -> MISSION_5_THE_REMOTE;
            case HORROR_FINAL -> 0;
        };
    }

    /**
     * Marks {@code missionId} (1..5) as completed (along with any prior prerequisite missions when
     * invoked via operator command `/echo mission complete <id>`), advances the player's EchoPhase,
     * and syncs mission progress to the client.
     */
    public static boolean completeMission(ServerPlayer player, int missionId) {
        if (player == null || player.server == null || missionId < 1 || missionId > TOTAL_MISSIONS) {
            return false;
        }

        PlayerMissionData data = PlayerMissionData.get(player.server);
        for (int m = 1; m <= missionId; m++) {
            data.markMissionCompleted(player.getUUID(), m);
        }

        if (EchoConfig.COMMON.debugMode.get()) {
            EchoCatMod.LOGGER.info("Player {} completed mission #{}",
                    player.getGameProfile().getName(), missionId);
        }

        EchoPhase current = PhaseManager.getPhase(player);
        EchoPhase targetPhase = EchoPhase.byId(missionId + 1);

        if (current.getId() < targetPhase.getId()) {
            PhaseManager.setPhase(player, targetPhase);
            String msgKey = switch (missionId) {
                case 1 -> "message.echocat.mission.shift_weird";
                case 2 -> "message.echocat.mission.shift_glitch";
                case 3 -> "message.echocat.mission.shift_chaos";
                case 4 -> "message.echocat.mission.shift_red";
                default -> "message.echocat.mission.shift_horror";
            };
            ChatFormatting color = switch (missionId) {
                case 1 -> ChatFormatting.DARK_PURPLE;
                case 2 -> ChatFormatting.AQUA;
                case 3 -> ChatFormatting.RED;
                case 4 -> ChatFormatting.DARK_RED;
                default -> ChatFormatting.GOLD;
            };
            player.sendSystemMessage(
                    Component.translatable(msgKey, targetPhase.getDisplayComponent()).withStyle(color)
            );
        }

        syncToClient(player);
        return true;
    }

    public static boolean isMissionCompleted(ServerPlayer player, int missionId) {
        if (player == null || player.server == null) {
            return false;
        }
        return PlayerMissionData.get(player.server).isMissionCompleted(player.getUUID(), missionId);
    }

    public static void resetMissions(ServerPlayer player) {
        if (player != null && player.server != null) {
            PlayerMissionData.get(player.server).clearMissions(player.getUUID());
            syncToClient(player);
        }
    }

    public static void syncToClient(ServerPlayer player) {
        if (player == null || player.server == null) {
            return;
        }
        Set<Integer> completed = PlayerMissionData.get(player.server).getCompletedMissions(player.getUUID());
        int mask = 0;
        for (int id : completed) {
            if (id >= 1 && id <= TOTAL_MISSIONS) {
                mask |= (1 << id);
            }
        }
        ModNetwork.CHANNEL.send(
                PacketDistributor.PLAYER.with(() -> player),
                new MissionSyncPacket(mask)
        );
    }

    public static void setClientCompletedMask(int mask) {
        clientCompletedMask = mask;
    }

    public static boolean isClientMissionCompleted(int missionId) {
        return (clientCompletedMask & (1 << missionId)) != 0;
    }

    public static int getClientActiveMissionId() {
        EchoPhase phase = PhaseManager.getClientCachedPhase();
        return switch (phase) {
            case CUTE -> 1;
            case WEIRD -> 2;
            case GLITCH -> 3;
            case CHAOS -> 4;
            case RED -> 5;
            case HORROR_FINAL -> 0;
        };
    }
}
