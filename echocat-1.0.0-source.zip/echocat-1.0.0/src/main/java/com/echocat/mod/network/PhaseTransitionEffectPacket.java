package com.echocat.mod.network;

import com.echocat.mod.client.ClientPacketHandlers;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Server -> Client packet sent when a player transitions into a horror phase (such as GLITCH or CHAOS),
 * triggering a short client screen overlay pulse that respects {@code photosensitiveMode}.
 */
public class PhaseTransitionEffectPacket {
    private final int newPhaseId;
    private final int durationTicks;

    public PhaseTransitionEffectPacket(int newPhaseId, int durationTicks) {
        this.newPhaseId = newPhaseId;
        this.durationTicks = durationTicks;
    }

    public int getNewPhaseId() {
        return this.newPhaseId;
    }

    public int getDurationTicks() {
        return this.durationTicks;
    }

    public static void encode(PhaseTransitionEffectPacket packet, FriendlyByteBuf buf) {
        buf.writeVarInt(packet.newPhaseId);
        buf.writeVarInt(packet.durationTicks);
    }

    public static PhaseTransitionEffectPacket decode(FriendlyByteBuf buf) {
        return new PhaseTransitionEffectPacket(buf.readVarInt(), buf.readVarInt());
    }

    public static void handle(PhaseTransitionEffectPacket packet, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPacketHandlers.handlePhaseTransitionEffect(packet))
        );
        context.setPacketHandled(true);
    }
}
