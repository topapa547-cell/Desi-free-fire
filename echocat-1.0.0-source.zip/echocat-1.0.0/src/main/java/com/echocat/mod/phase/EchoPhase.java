package com.echocat.mod.phase;

import com.echocat.mod.util.EchoConstants;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

/**
 * Represents the 6 horror evolution phases of Echo: The Talking Cat.
 */
public enum EchoPhase {
    CUTE(1, "Cute", "textures/entity/echo_cute.png"),
    WEIRD(2, "Weird", "textures/entity/echo_weird.png"),
    GLITCH(3, "Glitch", "textures/entity/echo_glitch.png"),
    CHAOS(4, "Chaos", "textures/entity/echo_chaos.png"),
    RED(5, "Red", "textures/entity/echo_red.png"),
    HORROR_FINAL(6, "Horror Final", "textures/entity/echo_horror.png");

    private static final EchoPhase[] VALUES = values();

    private final int id;
    private final String displayName;
    private final ResourceLocation textureLocation;

    EchoPhase(int id, String displayName, String texturePath) {
        this.id = id;
        this.displayName = displayName;
        this.textureLocation = EchoConstants.rl(texturePath);
    }

    /**
     * 1-based phase ID (1 to 6).
     */
    public int getId() {
        return this.id;
    }

    /**
     * Human-readable display name.
     */
    public String getDisplayName() {
        return this.displayName;
    }

    /**
     * Translatable component for UI/chat messages.
     */
    public Component getDisplayComponent() {
        return Component.translatable("phase.echocat." + this.name().toLowerCase());
    }

    /**
     * Entity texture ResourceLocation for this phase.
     */
    public ResourceLocation getTextureLocation() {
        return this.textureLocation;
    }

    /**
     * Returns the next phase, clamping at HORROR_FINAL.
     */
    public EchoPhase next() {
        int nextOrdinal = Math.min(this.ordinal() + 1, VALUES.length - 1);
        return VALUES[nextOrdinal];
    }

    /**
     * Returns the previous phase, clamping at CUTE.
     */
    public EchoPhase previous() {
        int prevOrdinal = Math.max(this.ordinal() - 1, 0);
        return VALUES[prevOrdinal];
    }

    /**
     * Resolves an EchoPhase from a 1-based ID (1..6), clamping out-of-range values safely.
     */
    public static EchoPhase byId(int id) {
        int clamped = Math.max(1, Math.min(VALUES.length, id));
        return VALUES[clamped - 1];
    }
}
