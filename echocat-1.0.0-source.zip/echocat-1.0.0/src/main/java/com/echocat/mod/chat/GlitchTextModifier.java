package com.echocat.mod.chat;

import java.util.Random;

/**
 * Corrupts Echo's repeated chat strings during Phase 3 (GLITCH) and higher:
 * - Syllabic stuttering on leading word characters (e.g. "hello" -> "he-he-hello").
 * - Random character leet/glitch substitutions (e.g. 'e' -> '3', 'o' -> '0', 'a' -> '4', 'i' -> '1', 's' -> '$').
 * - Occasional short obfuscated segment ("§k...§r") when chat formatting is permitted.
 */
public final class GlitchTextModifier {
    private GlitchTextModifier() {
    }

    /**
     * Applies deterministic or random glitch distortion to a clean message.
     *
     * @param cleanText        Sanitized plain message.
     * @param horrorIntensity  Intensity level (1..3).
     * @param allowObfuscation If true, may wrap a short middle slice in {@code §k...§r} for chat display.
     * @param random           Random source.
     */
    public static String glitchify(String cleanText, int horrorIntensity, boolean allowObfuscation, Random random) {
        if (cleanText == null || cleanText.isEmpty()) {
            return "";
        }

        double intensityScale = Math.max(1, Math.min(3, horrorIntensity)) / 2.0D;
        String[] words = cleanText.split("\\s+");
        StringBuilder out = new StringBuilder();

        for (int w = 0; w < words.length; w++) {
            if (w > 0) {
                out.append(' ');
            }
            String word = words[w];
            if (word.length() >= 3 && (w == 0 || random.nextDouble() < 0.28D * intensityScale)) {
                int prefixLen = Math.min(2, word.length());
                String prefix = word.substring(0, prefixLen);
                out.append(prefix).append('-').append(prefix).append('-');
            }

            if (allowObfuscation && word.length() >= 4 && w == words.length - 1 && random.nextDouble() < 0.45D * intensityScale) {
                int cut = word.length() / 2;
                out.append(swapChars(word.substring(0, cut), intensityScale, random));
                out.append("\u00A7k").append(word.substring(cut)).append("\u00A7r");
            } else {
                out.append(swapChars(word, intensityScale, random));
            }
        }

        String result = out.toString();
        if (result.length() > ChatRepeatHandler.MAX_MESSAGE_CHARS) {
            result = result.substring(0, ChatRepeatHandler.MAX_MESSAGE_CHARS).trim();
            if (result.contains("\u00A7k") && !result.endsWith("\u00A7r")) {
                result = result + "\u00A7r";
            }
        }
        return result;
    }

    private static String swapChars(String input, double intensityScale, Random random) {
        StringBuilder sb = new StringBuilder(input.length());
        double swapProb = 0.25D * intensityScale;
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (random.nextDouble() < swapProb) {
                sb.append(mapGlitchChar(c));
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    private static char mapGlitchChar(char c) {
        return switch (Character.toLowerCase(c)) {
            case 'e' -> '3';
            case 'o' -> '0';
            case 'a' -> '4';
            case 'i', 'l' -> '1';
            case 's' -> '$';
            case 't' -> '7';
            default -> c;
        };
    }
}
