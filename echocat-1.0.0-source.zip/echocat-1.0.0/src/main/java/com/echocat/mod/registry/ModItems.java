package com.echocat.mod.registry;

import com.echocat.mod.EchoCatMod;
import com.echocat.mod.item.EchoJournalItem;
import com.echocat.mod.item.EchoPlushSummonerItem;
import com.echocat.mod.item.LoreTooltipItem;
import com.echocat.mod.item.PurifiedEchoPlushItem;
import com.echocat.mod.item.TheRemoteItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, EchoCatMod.MOD_ID);

    public static final RegistryObject<Item> ECHO_PLUSH_SUMMONER = ITEMS.register(
            "echo_plush_summoner",
            () -> new EchoPlushSummonerItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE))
    );

    // Mission 1 item: Echo Circuit
    public static final RegistryObject<Item> ECHO_CIRCUIT = ITEMS.register(
            "echo_circuit",
            () -> new LoreTooltipItem(new Item.Properties().rarity(Rarity.UNCOMMON), "item.echocat.echo_circuit.desc")
    );

    // Mission 2 item: Glitch Shard (mined from Static Block)
    public static final RegistryObject<Item> GLITCH_SHARD = ITEMS.register(
            "glitch_shard",
            () -> new LoreTooltipItem(new Item.Properties().rarity(Rarity.UNCOMMON), "item.echocat.glitch_shard.desc")
    );

    // Mission 3 item: Corrupted Core (dropped by Corrupted mobs)
    public static final RegistryObject<Item> CORRUPTED_CORE = ITEMS.register(
            "corrupted_core",
            () -> new LoreTooltipItem(new Item.Properties().rarity(Rarity.RARE), "item.echocat.corrupted_core.desc")
    );

    // Mission 4 item: Red Crystal (mined from Red Crystal Ore below Y=0 or found in chests)
    public static final RegistryObject<Item> RED_CRYSTAL = ITEMS.register(
            "red_crystal",
            () -> new LoreTooltipItem(new Item.Properties().rarity(Rarity.RARE), "item.echocat.red_crystal.desc")
    );

    // Mission 5 component: Remote Casing
    public static final RegistryObject<Item> REMOTE_CASING = ITEMS.register(
            "remote_casing",
            () -> new LoreTooltipItem(new Item.Properties().rarity(Rarity.UNCOMMON), "item.echocat.remote_casing.desc")
    );

    // Mission 5 final crafted counter item: The Remote
    public static final RegistryObject<Item> THE_REMOTE = ITEMS.register(
            "the_remote",
            () -> new TheRemoteItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC))
    );

    // Mission UI item: Echo's Journal
    public static final RegistryObject<Item> ECHO_JOURNAL = ITEMS.register(
            "echo_journal",
            () -> new EchoJournalItem(new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON))
    );

    // Boss Defeat Rewards: Echo's Heart & Purified Echo Plush Summoner
    public static final RegistryObject<Item> ECHO_HEART = ITEMS.register(
            "echo_heart",
            () -> new LoreTooltipItem(new Item.Properties().stacksTo(16).rarity(Rarity.EPIC), "item.echocat.echo_heart.desc")
    );

    public static final RegistryObject<Item> PURIFIED_ECHO_PLUSH = ITEMS.register(
            "purified_echo_plush",
            () -> new PurifiedEchoPlushItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC))
    );

    // BlockItems for Static Block and Red Crystal Ore
    public static final RegistryObject<Item> STATIC_BLOCK_ITEM = ITEMS.register(
            "static_block",
            () -> new BlockItem(ModBlocks.STATIC_BLOCK.get(), new Item.Properties())
    );

    public static final RegistryObject<Item> RED_CRYSTAL_ORE_ITEM = ITEMS.register(
            "red_crystal_ore",
            () -> new BlockItem(ModBlocks.RED_CRYSTAL_ORE.get(), new Item.Properties())
    );

    private ModItems() {
    }

    public static void register(IEventBus eventBus) {
        ITEMS.register(eventBus);
    }
}
