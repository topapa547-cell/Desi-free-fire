package com.echocat.mod.registry;

import com.echocat.mod.EchoCatMod;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * Registers worldgen blocks required for Phase 4 missions:
 * - {@code static_block}: Overworld glitch ore dropping Glitch Shard (Mission 2).
 * - {@code red_crystal_ore}: Deep deepslate ore below Y=0 dropping Red Crystal (Mission 4).
 */
public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, EchoCatMod.MOD_ID);

    public static final RegistryObject<Block> STATIC_BLOCK = BLOCKS.register(
            "static_block",
            () -> new DropExperienceBlock(
                    BlockBehaviour.Properties.of()
                            .mapColor(MapColor.COLOR_CYAN)
                            .requiresCorrectToolForDrops()
                            .strength(3.0F, 6.0F)
                            .sound(SoundType.AMETHYST)
                            .lightLevel(state -> 4),
                    UniformInt.of(2, 5)
            )
    );

    public static final RegistryObject<Block> RED_CRYSTAL_ORE = BLOCKS.register(
            "red_crystal_ore",
            () -> new DropExperienceBlock(
                    BlockBehaviour.Properties.of()
                            .mapColor(MapColor.COLOR_RED)
                            .requiresCorrectToolForDrops()
                            .strength(4.5F, 6.0F)
                            .sound(SoundType.DEEPSLATE)
                            .lightLevel(state -> 5),
                    UniformInt.of(3, 7)
            )
    );

    private ModBlocks() {
    }

    public static void register(IEventBus eventBus) {
        BLOCKS.register(eventBus);
    }
}
