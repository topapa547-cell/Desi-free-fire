package com.echocat.mod.config;

import net.minecraftforge.common.ForgeConfigSpec;
import org.apache.commons.lang3.tuple.Pair;

import java.util.List;

/**
 * ForgeConfigSpec definitions for COMMON and CLIENT configurations (v1.0.0).
 * Security guarantee: apiKey and sttApiKey are NEVER logged, NEVER shipped inside the jar,
 * and NEVER transmitted to other clients.
 */
public final class EchoConfig {
    public static final Common COMMON;
    public static final ForgeConfigSpec COMMON_SPEC;

    public static final Client CLIENT;
    public static final ForgeConfigSpec CLIENT_SPEC;

    static {
        final Pair<Common, ForgeConfigSpec> commonPair = new ForgeConfigSpec.Builder().configure(Common::new);
        COMMON = commonPair.getLeft();
        COMMON_SPEC = commonPair.getRight();

        final Pair<Client, ForgeConfigSpec> clientPair = new ForgeConfigSpec.Builder().configure(Client::new);
        CLIENT = clientPair.getLeft();
        CLIENT_SPEC = clientPair.getRight();
    }

    private EchoConfig() {
    }

    public static String maskSecret(String secret) {
        if (secret == null || secret.isBlank()) {
            return "<empty>";
        }
        return "********";
    }

    public static class Common {
        public final ForgeConfigSpec.BooleanValue enableChat;
        public final ForgeConfigSpec.BooleanValue enableVoice;
        public final ForgeConfigSpec.ConfigValue<String> apiProvider;
        public final ForgeConfigSpec.ConfigValue<String> apiEndpoint;
        public final ForgeConfigSpec.ConfigValue<String> apiKey;
        public final ForgeConfigSpec.ConfigValue<String> apiModel;
        public final ForgeConfigSpec.DoubleValue phaseSpeedMultiplier;
        public final ForgeConfigSpec.IntValue maxAffectedMobs;
        public final ForgeConfigSpec.BooleanValue debugMode;
        public final ForgeConfigSpec.IntValue horrorIntensity;

        // Phase 2 additions
        public final ForgeConfigSpec.DoubleValue weirdCreepyChance;
        public final ForgeConfigSpec.IntValue chatCooldownMs;
        public final ForgeConfigSpec.IntValue maxAiRequestsPerDay;

        // Phase 3 Chaos & Corruption additions
        public final ForgeConfigSpec.ConfigValue<List<? extends String>> corruptionBlacklist;
        public final ForgeConfigSpec.IntValue maxCorruptionDurationSeconds;
        public final ForgeConfigSpec.BooleanValue allowMobDamageToPlayers;
        public final ForgeConfigSpec.DoubleValue corruptedDamageMultiplier;

        // Phase 4 Red Phase, Boss Fight & Missions additions
        public final ForgeConfigSpec.DoubleValue bossHealth;
        public final ForgeConfigSpec.DoubleValue bossDamage;
        public final ForgeConfigSpec.DoubleValue overloadDamage;
        public final ForgeConfigSpec.IntValue stunDuration;
        public final ForgeConfigSpec.IntValue remoteCooldown;
        public final ForgeConfigSpec.DoubleValue redPhaseDurationMinutes;
        public final ForgeConfigSpec.BooleanValue enablePurifiedPlush;
        public final ForgeConfigSpec.DoubleValue corruptedCoreDropChance;
        public final ForgeConfigSpec.IntValue bossPhase2OverloadInterval;

        // Phase 5 Release Polish & Performance addition
        public final ForgeConfigSpec.BooleanValue performanceMode;

        public Common(ForgeConfigSpec.Builder builder) {
            builder.comment("Echo: The Talking Cat - Common Configuration (v1.0.0)").push("general");

            this.enableChat = builder
                    .comment("Whether Echo listens to and repeats player text chat messages.")
                    .define("enableChat", true);

            this.enableVoice = builder
                    .comment("Whether Echo accepts transcribed player voice messages from push-to-talk.")
                    .define("enableVoice", true);

            this.apiProvider = builder
                    .comment("External AI dialogue provider ('none' = offline fallback only, 'openai' or 'custom' = HTTP chat completions).")
                    .define("apiProvider", "none");

            this.apiEndpoint = builder
                    .comment("HTTP endpoint URL for OpenAI-compatible chat completions.")
                    .define("apiEndpoint", "https://api.openai.com/v1/chat/completions");

            this.apiKey = builder
                    .comment("Secret API key for external AI provider. Leave empty for offline mode. WARNING: Do NOT share this config file publicly if you paste an API key here! NEVER logged or sent to clients.")
                    .define("apiKey", "");

            this.apiModel = builder
                    .comment("Model identifier to request when using an external AI provider.")
                    .define("apiModel", "gpt-4o-mini");

            this.phaseSpeedMultiplier = builder
                    .comment("Multiplier controlling how quickly Echo progresses through the 6 horror phases.")
                    .defineInRange("phaseSpeedMultiplier", 1.0D, 0.1D, 10.0D);

            this.maxAffectedMobs = builder
                    .comment("Maximum number of nearby mobs affected per Echo during Phase 4 (CHAOS). Default: 12.")
                    .defineInRange("maxAffectedMobs", 12, 1, 64);

            this.debugMode = builder
                    .comment("Enable verbose diagnostic logging for AI source, glitch events, mob corruption, and boss fight state (never logs API keys, audio, or private chat).")
                    .define("debugMode", false);

            this.horrorIntensity = builder
                    .comment("Controls overall horror intensity (1 = Mild, 2 = Standard, 3 = Extreme). Scales visual effects, sound volume, corruption strength, whisper frequency, and jumpscares.")
                    .defineInRange("horrorIntensity", 2, 1, 3);

            this.weirdCreepyChance = builder
                    .comment("Probability (0.0 to 1.0) in Phase 2+ that Echo appends an unprompted creepy line after repeating the player. Default: 0.35.")
                    .defineInRange("weirdCreepyChance", 0.35D, 0.0D, 1.0D);

            this.chatCooldownMs = builder
                    .comment("Per-player cooldown in milliseconds between Echo chat/voice repetitions to prevent spam. Default: 1500 ms.")
                    .defineInRange("chatCooldownMs", 1500, 250, 30000);

            this.maxAiRequestsPerDay = builder
                    .comment("Maximum external AI HTTP requests allowed per real-world day across the world before silently using LocalCreepyFallback. Default: 200.")
                    .defineInRange("maxAiRequestsPerDay", 200, 0, 100000);

            this.corruptionBlacklist = builder
                    .comment("List of entity resource locations immune to Phase 3/4 corruption.")
                    .defineListAllowEmpty(
                            List.of("corruptionBlacklist"),
                            () -> List.of("minecraft:ender_dragon", "minecraft:wither", "minecraft:warden", "minecraft:elder_guardian", "minecraft:villager", "minecraft:wandering_trader", "minecraft:iron_golem", "minecraft:allay"),
                            obj -> obj instanceof String s && s.contains(":")
                    );

            this.maxCorruptionDurationSeconds = builder
                    .comment("Maximum duration in seconds that a mob remains corrupted before being restored to normal. Default: 90 seconds.")
                    .defineInRange("maxCorruptionDurationSeconds", 90, 5, 600);

            this.allowMobDamageToPlayers = builder
                    .comment("Whether corrupted mobs are allowed to deal damage to players. Default: true.")
                    .define("allowMobDamageToPlayers", true);

            this.corruptedDamageMultiplier = builder
                    .comment("Damage multiplier applied when a corrupted mob hits a player. Default: 0.5 (50% damage).")
                    .defineInRange("corruptedDamageMultiplier", 0.5D, 0.0D, 5.0D);

            this.bossHealth = builder
                    .comment("Maximum health of Echo in Phase 6 (HORROR_FINAL) boss fight. Default: 300.0.")
                    .defineInRange("bossHealth", 300.0D, 40.0D, 2000.0D);

            this.bossDamage = builder
                    .comment("Base melee attack damage of Echo in Phase 6 (HORROR_FINAL) before difficulty scaling. Default: 6.0 (3 hearts).")
                    .defineInRange("bossDamage", 6.0D, 1.0D, 50.0D);

            this.overloadDamage = builder
                    .comment("Damage dealt by Echo's 5th-attack Overload burst if not countered with The Remote (capped so it never one-shots a full-health player on Normal). Default: 10.0 (5 hearts).")
                    .defineInRange("overloadDamage", 10.0D, 2.0D, 18.0D);

            this.stunDuration = builder
                    .comment("Duration in seconds that Echo is stunned and takes 3x damage after being countered by The Remote during Overload. Default: 12 seconds.")
                    .defineInRange("stunDuration", 12, 3, 60);

            this.remoteCooldown = builder
                    .comment("Cooldown in seconds applied to The Remote after a successful Overload counter. Default: 20 seconds.")
                    .defineInRange("remoteCooldown", 20, 1, 120);

            this.redPhaseDurationMinutes = builder
                    .comment("Base real-time duration in minutes for redProgress to climb from 0.0 to 1.0 during Phase 5 (RED), scaled by phaseSpeedMultiplier. Default: 10.0 minutes.")
                    .defineInRange("redPhaseDurationMinutes", 10.0D, 0.5D, 120.0D);

            this.enablePurifiedPlush = builder
                    .comment("Whether the Purified Echo Plush Summoner (dropped on defeating the Phase 6 boss) can summon a permanently CUTE, horror-free Echo companion. Default: true.")
                    .define("enablePurifiedPlush", true);

            this.corruptedCoreDropChance = builder
                    .comment("Probability (0.0 to 1.0) that killing a Corrupted mob drops a Corrupted Core for Mission 3. Default: 0.50 (50%).")
                    .defineInRange("corruptedCoreDropChance", 0.50D, 0.05D, 1.0D);

            this.bossPhase2OverloadInterval = builder
                    .comment("Number of attacks per Overload cycle when the Phase 6 boss drops below 50% HP (Phase 2 of the boss fight). Default: 4 (down from 5).")
                    .defineInRange("bossPhase2OverloadInterval", 4, 2, 10);

            this.performanceMode = builder
                    .comment("When true, lowers particle counts by 60%, disables the extra RGB-split ghost duplicate render passes, and reduces Chaos mob corruption scan frequency (every 40 ticks instead of 20 ticks).")
                    .define("performanceMode", false);

            builder.pop();
        }
    }

    public static class Client {
        public final ForgeConfigSpec.BooleanValue photosensitiveMode;
        public final ForgeConfigSpec.BooleanValue enableJumpscares;
        public final ForgeConfigSpec.BooleanValue showFirstLaunchWarning;

        // Phase 2 client voice & TTS additions
        public final ForgeConfigSpec.BooleanValue voiceConsentGiven;
        public final ForgeConfigSpec.ConfigValue<String> sttEndpoint;
        public final ForgeConfigSpec.ConfigValue<String> sttApiKey;
        public final ForgeConfigSpec.ConfigValue<String> sttModel;
        public final ForgeConfigSpec.BooleanValue enableTts;
        public final ForgeConfigSpec.ConfigValue<String> ttsEndpoint;
        public final ForgeConfigSpec.ConfigValue<String> ttsModel;
        public final ForgeConfigSpec.ConfigValue<String> ttsVoice;

        // Phase 4 Mission HUD addition
        public final ForgeConfigSpec.BooleanValue showMissionHud;

        public Client(ForgeConfigSpec.Builder builder) {
            builder.comment("Echo: The Talking Cat - Client Accessibility, Voice, TTS & HUD Configuration (v1.0.0)").push("client");

            this.photosensitiveMode = builder
                    .comment("Reduces rapid screen flashes, limits visual changes to <= 2 per second, lowers contrast, and disables strobing full-screen overlays.")
                    .define("photosensitiveMode", false);

            this.enableJumpscares = builder
                    .comment("Whether sudden jumpscare visuals and loud stingers are enabled when the Phase 6 boss first spots you.")
                    .define("enableJumpscares", true);

            this.showFirstLaunchWarning = builder
                    .comment("Displays a horror & photosensitivity content notice on first world join.")
                    .define("showFirstLaunchWarning", true);

            this.voiceConsentGiven = builder
                    .comment("Must be true before the microphone is ever accessed. Confirmed in-game via the one-time privacy notice. Set back to false at any time to revoke microphone consent.")
                    .define("voiceConsentGiven", false);

            this.sttEndpoint = builder
                    .comment("Speech-to-Text (STT) multipart upload endpoint (OpenAI-compatible audio transcriptions format).")
                    .define("sttEndpoint", "https://api.openai.com/v1/audio/transcriptions");

            this.sttApiKey = builder
                    .comment("Optional separate API key for STT/TTS on the client. If empty, falls back to EchoConfig.COMMON.apiKey in singleplayer. WARNING: Do NOT share this config file publicly if you paste an API key here! NEVER logged.")
                    .define("sttApiKey", "");

            this.sttModel = builder
                    .comment("Model name sent to the STT transcription endpoint.")
                    .define("sttModel", "whisper-1");

            this.enableTts = builder
                    .comment("If true, Echo's spoken lines are synthesized via ttsEndpoint and played back at a higher cat-like pitch (WAV/PCM format).")
                    .define("enableTts", false);

            this.ttsEndpoint = builder
                    .comment("Text-to-Speech (TTS) HTTP endpoint returning WAV audio.")
                    .define("ttsEndpoint", "https://api.openai.com/v1/audio/speech");

            this.ttsModel = builder
                    .comment("Model identifier sent to the TTS endpoint.")
                    .define("ttsModel", "tts-1");

            this.ttsVoice = builder
                    .comment("Voice identifier sent to the TTS endpoint.")
                    .define("ttsVoice", "alloy");

            this.showMissionHud = builder
                    .comment("Displays a compact active mission tracker line on the HUD. Set to false to hide it.")
                    .define("showMissionHud", true);

            builder.pop();
        }
    }
}
