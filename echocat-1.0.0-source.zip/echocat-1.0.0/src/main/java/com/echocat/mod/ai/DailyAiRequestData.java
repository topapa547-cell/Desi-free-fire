package com.echocat.mod.ai;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.time.LocalDate;
import java.time.ZoneOffset;

/**
 * World-level persistent SavedData tracking the number of external AI API calls
 * made during the current UTC calendar day (with `dataVersion` migration support).
 */
public class DailyAiRequestData extends SavedData {
    public static final int CURRENT_DATA_VERSION = 1;
    private static final String DATA_NAME = "echocat_daily_ai_requests";
    private static final String TAG_DATA_VERSION = "DataVersion";
    private static final String TAG_EPOCH_DAY = "EpochDay";
    private static final String TAG_COUNT = "RequestCount";

    private int dataVersion = CURRENT_DATA_VERSION;
    private long epochDay = LocalDate.now(ZoneOffset.UTC).toEpochDay();
    private int requestCount = 0;

    public DailyAiRequestData() {
    }

    public static DailyAiRequestData load(CompoundTag tag) {
        DailyAiRequestData data = new DailyAiRequestData();
        data.dataVersion = tag.contains(TAG_DATA_VERSION) ? tag.getInt(TAG_DATA_VERSION) : CURRENT_DATA_VERSION;
        data.epochDay = tag.getLong(TAG_EPOCH_DAY);
        data.requestCount = Math.max(0, tag.getInt(TAG_COUNT));
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putInt(TAG_DATA_VERSION, this.dataVersion);
        tag.putLong(TAG_EPOCH_DAY, this.epochDay);
        tag.putInt(TAG_COUNT, this.requestCount);
        return tag;
    }

    public boolean tryConsumeQuota(int maxPerDay) {
        if (maxPerDay <= 0) {
            return false;
        }
        long today = LocalDate.now(ZoneOffset.UTC).toEpochDay();
        if (this.epochDay != today) {
            this.epochDay = today;
            this.requestCount = 0;
        }
        if (this.requestCount >= maxPerDay) {
            return false;
        }
        this.requestCount++;
        this.setDirty();
        return true;
    }

    public static DailyAiRequestData get(MinecraftServer server) {
        ServerLevel overworld = server.overworld();
        return overworld.getDataStorage().computeIfAbsent(
                DailyAiRequestData::load,
                DailyAiRequestData::new,
                DATA_NAME
        );
    }
}
